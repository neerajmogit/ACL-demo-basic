package com.cybage.config;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.acls.domain.BasePermission;
import org.springframework.security.acls.domain.GrantedAuthoritySid;
import org.springframework.security.acls.domain.ObjectIdentityImpl;
import org.springframework.security.acls.domain.PrincipalSid;
import org.springframework.security.acls.model.MutableAcl;
import org.springframework.security.acls.model.MutableAclService;
import org.springframework.security.acls.model.ObjectIdentity;
import org.springframework.security.acls.model.Sid;
import org.springframework.stereotype.Component;

import com.cybage.domain.Document;
import com.cybage.repository.DocumentRepository;

@Component
public class TestDataInitializer implements CommandLineRunner {

    private final DocumentRepository documentRepository;
    private final MutableAclService aclService;

    @Autowired
    public TestDataInitializer(DocumentRepository documentRepository, MutableAclService aclService) {
        this.documentRepository = documentRepository;
        this.aclService = aclService;
    }

    @Override
    public void run(String... args) throws Exception {
        initTestData();
    }

    private void initTestData() {
        // Create test documents
        List<Document> documents = Arrays.asList(
            new Document("Admin Document", "This document is for admin only", "adminOwnerNm"),
            new Document("User Document", "This document is for regular users", "userOwnerNm"),
            new Document("Public Document", "This document is for everyone", "publicOwnerNm")
        );
        
        // Save documents to get IDs
        documentRepository.saveAll(documents);
        
        // Set up ACLs for each document
        documents.forEach(document -> {
            // Create object identity
            ObjectIdentity oi = new ObjectIdentityImpl(Document.class, document.getId());
            
            // Create ACL - first check if it exists
            MutableAcl acl;
            try {
                acl = (MutableAcl) aclService.readAclById(oi);
            } catch (Exception e) {
                // Create a new ACL if it doesn't exist
                acl = aclService.createAcl(oi);
            }
            
            // Make sure acl is not null before using it
            if (acl != null) {
                // Set owner
                Sid ownerSid = new PrincipalSid("admin");
                acl.setOwner(ownerSid);
                
                // Set permissions based on document type
                if (document.getName().contains("Admin")) {
                    // Admin document - only admin has access
                    acl.insertAce(acl.getEntries().size(), BasePermission.READ, ownerSid, true);
                } else if (document.getName().contains("User")) {
                    // User document - admin and users have access
                    acl.insertAce(acl.getEntries().size(), BasePermission.READ, ownerSid, true);
                    acl.insertAce(acl.getEntries().size(), BasePermission.READ, new GrantedAuthoritySid("ROLE_USER"), true);
                } else {
                    // Public document - everyone has access
                    acl.insertAce(acl.getEntries().size(), BasePermission.READ, ownerSid, true);
                    acl.insertAce(acl.getEntries().size(), BasePermission.READ, new GrantedAuthoritySid("ROLE_USER"), true);
                    acl.insertAce(acl.getEntries().size(), BasePermission.READ, new GrantedAuthoritySid("ROLE_ANONYMOUS"), true);
                }
                
                // Update the ACL
                aclService.updateAcl(acl);
            } else {
                System.err.println("Failed to create ACL for document: " + document.getName());
            }
        });
        
        System.out.println("Test data initialized with ACL permissions");
    }
}





//package com.cybage.config;
//
//import com.cybage.domain.Document;
//import com.cybage.repository.DocumentRepository;
//
//import java.util.Collections;
//
//import org.springframework.boot.CommandLineRunner;
//import org.springframework.boot.test.context.TestConfiguration;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Profile;
//import org.springframework.security.acls.domain.BasePermission;
//import org.springframework.security.acls.domain.ObjectIdentityImpl;
//import org.springframework.security.acls.domain.PrincipalSid;
//import org.springframework.security.acls.model.MutableAcl;
//import org.springframework.security.acls.model.MutableAclService;
//import org.springframework.security.acls.model.ObjectIdentity;
//import org.springframework.security.acls.model.Sid;
//
//import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
//import org.springframework.security.core.Authentication;
//import org.springframework.security.core.authority.SimpleGrantedAuthority;
//import org.springframework.security.core.context.SecurityContextHolder;
//
//
//@TestConfiguration
//@Profile("test")
//public class TestDataInitializer {
//
//    @Bean
//    public CommandLineRunner initTestData(DocumentRepository documentRepository, MutableAclService aclService) {
//        return args -> {
//            // Clear existing data
//            documentRepository.deleteAll();
//            
//            // Create test documents
//            Document adminDoc = new Document("Admin Document", "This is an admin document", "admin");
//            Document userDoc = new Document("User Document", "This is a user document", "cybUser1");
//            
//            // Save documents
//            adminDoc = documentRepository.save(adminDoc);
//            userDoc = documentRepository.save(userDoc);
//            
//            // Set up ACLs
//            // For admin document
//            ObjectIdentity adminOid = new ObjectIdentityImpl(Document.class, adminDoc.getId());
//            // -----------------------------------------------------------------------------------------------------
//            //  We have to set the Authentication object, for a PrincipalSid, before createAcl(...
//            //------------------------------------------------------------------------------------------------------
//            // Set authentication in the security context
//            Authentication authentication = new UsernamePasswordAuthenticationToken(
//												                "admin", 
//												                "password",
//												                Collections.singletonList(new SimpleGrantedAuthority("ROLE_ADMIN")
//									                								   			   )
//            										      );
//            SecurityContextHolder.getContext().setAuthentication(authentication);
//
//            try {     // Admin ACL Entries code ----------
//				        MutableAcl adminAcl = aclService.createAcl(adminOid);
//			            Sid adminSid = new PrincipalSid("admin");
//			            adminAcl.setOwner(adminSid);
//			            adminAcl.insertAce(0, BasePermission.READ, adminSid, true);
//			            adminAcl.insertAce(1, BasePermission.WRITE, adminSid, true);
//			            aclService.updateAcl(adminAcl);
//            } finally {
//            			SecurityContextHolder.clearContext();
//            }
//
//            
//            try {     // User ACL Entries code ----------
//			            ObjectIdentity userOid = new ObjectIdentityImpl(Document.class, userDoc.getId());
//			            MutableAcl userAcl = aclService.createAcl(userOid);
//			            Sid userSid = new PrincipalSid("cybUser1");
//			            userAcl.setOwner(userSid);
//			            userAcl.insertAce(0, BasePermission.READ, userSid, true);
//			            userAcl.insertAce(1, BasePermission.WRITE, userSid, true);
//			            aclService.updateAcl(userAcl);
//          } finally {
//        	  			SecurityContextHolder.clearContext();
//          }
//            
//            System.out.println("Test data initialized successfully");
//        };
//    }
//}
