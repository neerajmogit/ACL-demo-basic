package com.cybage.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.jdbc.datasource.init.ScriptUtils;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Connection;

@Component
@Profile("!test")
public class XTestDatabaseInitializer implements InitializingBean {

    private static final Logger logger = LoggerFactory.getLogger(XTestDatabaseInitializer.class);
    
    private final DataSource dataSource;

    @Autowired
    public XTestDatabaseInitializer(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        logger.info("Initializing test database...");
        
        try (Connection connection = dataSource.getConnection()) {
            // Execute schema script if it exists
            Resource schemaResource = new ClassPathResource("schema-test.sql");
            if (schemaResource.exists()) {
                logger.info("Executing schema-test.sql");
                ScriptUtils.executeSqlScript(connection, schemaResource);
            } else {
                logger.warn("schema-test.sql not found in classpath");
            }
            
            // Execute data script if it exists
            Resource dataResource = new ClassPathResource("data-test.sql");
            if (dataResource.exists()) {
                logger.info("Executing data-test.sql");
                ScriptUtils.executeSqlScript(connection, dataResource);
            } else {
                logger.warn("data-test.sql not found in classpath");
            }
        } catch (Exception e) {
            logger.error("Error initializing test database", e);
            throw e;
        }
    }
}
