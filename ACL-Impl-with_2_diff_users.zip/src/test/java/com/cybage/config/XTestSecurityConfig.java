package com.cybage.config;

import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@TestConfiguration
@EnableWebSecurity
//@EnableMethodSecurity
//@Profile("test")
public class XTestSecurityConfig {
	
	@Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
	        http
	            .csrf(csrf -> csrf.disable())
	            .authorizeHttpRequests(authorize -> authorize
		                .requestMatchers("/public/**", "/h2-console/**").permitAll()
		                .requestMatchers("/admin/**").hasRole("ADMIN")
		                .requestMatchers("/user/**").hasAnyRole("USER", "ADMIN")
		                .requestMatchers("/x-documents/**").authenticated()
		                .anyRequest().authenticated()
	            )
	            .formLogin(form -> form
		                .defaultSuccessUrl("/documents", true)
		                .permitAll()
	            )
	            .logout(logout -> logout
	            		.permitAll()
	            )
     			.headers(headers -> headers
     						  .frameOptions(frameOptions -> frameOptions.disable())
     		    );
        
        return http.build();
    }
	
//	 @Bean
//	    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
//		 // Spring Security 6.x: Ensure that lambda-based configuration is used:
//		 http
//         			.csrf(AbstractHttpConfigurer::disable)
//         			.authorizeHttpRequests(auth -> auth
//         												.anyRequest().permitAll()
//         											  )
//         			.headers(headers -> headers
//	                			     .frameOptions(frameOptions -> frameOptions.disable())
//	                             );
//	        
//	        return http.build();
//	    }
    
    @Bean
    public UserDetailsService userDetailsService() {
        InMemoryUserDetailsManager manager = new InMemoryUserDetailsManager();
        
        manager.createUser(User.withUsername("admin")
            .password("{noop}password")
            .roles("ADMIN")
            .build());
            
        manager.createUser(User.withUsername("cybUser1")
            .password("{noop}password")
            .roles("USER")
            .build());
            
        manager.createUser(User.withUsername("cybUser2")
            .password("{noop}password")
            .roles("USER")
            .build());
            
        manager.createUser(User.withUsername("cybManager1")
            .password("{noop}password")
            .roles("MANAGER")
            .build());
            
        return manager;
    }
    
    /**
     * Password encoder bean
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
