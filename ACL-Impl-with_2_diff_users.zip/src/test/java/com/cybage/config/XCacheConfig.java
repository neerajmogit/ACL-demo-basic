//package com.cybage.config;
//
//import org.ehcache.config.builders.CacheConfigurationBuilder;
//import org.ehcache.config.builders.ResourcePoolsBuilder;
//import org.ehcache.jsr107.Eh107Configuration;
//import org.springframework.cache.annotation.EnableCaching;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.core.io.ClassPathResource;
//
//import javax.cache.CacheManager;
//import javax.cache.Caching;
//import javax.cache.spi.CachingProvider;
//import java.io.IOException;
//import java.net.URI;
//
///** Error "URI nulll, therefore,  encountering is because the application can't find the ehcache.xml file.
// *  The error message indicates that the URL is null when trying to convert it to a URI in the jCacheManager method of your CacheConfig class.
// *  This updated version:--------------------------
//	Uses Spring's ClassPathResource to locate the ehcache.xml file
//	Checks if the file exists before trying to use it
//	Provides a fallback to create the cache programmatically if the file isn't found
//	Uses the resource's URI directly instead of trying to get a URL and then converting it
// *  ---> There is also another simpler version, pasted at the end of this file
// *  
// * @return
// * @throws Exception
// */
// 
//
//@Configuration
//@EnableCaching
//public class XCacheConfig {
//
//    @Bean
//    public CacheManager jCacheManager() throws Exception {
//        CachingProvider provider = Caching.getCachingProvider();
//        
//        // Try to load the ehcache.xml file from the classpath
//        ClassPathResource ehcacheConfig = new ClassPathResource("ehcache.xml");
//        
//        if (!ehcacheConfig.exists()) {
//            // If the file doesn't exist, create a cache manager programmatically
//            CacheManager cacheManager = provider.getCacheManager();
//            
//            // Create the aclCache programmatically if it doesn't exist
//            if (cacheManager.getCache("aclCache") == null) {
//                javax.cache.configuration.Configuration<Object, Object> configuration = 
//                    Eh107Configuration.fromEhcacheCacheConfiguration(
//                        CacheConfigurationBuilder.newCacheConfigurationBuilder(
//                            Object.class, Object.class,
//                            ResourcePoolsBuilder.heap(1000)
//                        )
//                    );
//                cacheManager.createCache("aclCache", configuration);
//            }
//            
//            return cacheManager;
//        } else {
//            // If the file exists, use it to configure the cache manager
//            URI uri = ehcacheConfig.getURI();
//            return provider.getCacheManager(uri, getClass().getClassLoader());
//        }
//    }
//}
//
///*
// Even simpler approach by creating the cache manager programmatically without relying on the XML file:
// package com.cybage.config;
//
//import org.ehcache.config.builders.CacheConfigurationBuilder;
//import org.ehcache.config.builders.CacheManagerBuilder;
//import org.ehcache.config.builders.ExpiryPolicyBuilder;
//import org.ehcache.config.builders.ResourcePoolsBuilder;
//import org.ehcache.jsr107.Eh107Configuration;
//import org.springframework.cache.annotation.EnableCaching;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//import javax.cache.CacheManager;
//import javax.cache.Caching;
//import javax.cache.spi.CachingProvider;
//import java.time.Duration;
//
//@Configuration
//@EnableCaching
//public class CacheConfig {
//
//    @Bean
//    public CacheManager jCacheManager() {
//        CachingProvider provider = Caching.getCachingProvider();
//        CacheManager cacheManager = provider.getCacheManager();
//        
//        // Create the aclCache programmatically
//        if (cacheManager.getCache("aclCache") == null) {
//                 javax.cache.configuration.Configuration<Object, Object> configuration = 
//                				Eh107Configuration
//                						.fromEhcacheCacheConfiguration( CacheConfigurationBuilder
//                																				.newCacheConfigurationBuilder( Object.class, Object.class, ResourcePoolsBuilder.heap(1000))
//                																				.withExpiry (ExpiryPolicyBuilder
//                																										.timeToLiveExpiration(Duration.ofSeconds(600)
//                																								                                       )
//                																								 )
//                                                                                        );
//            cacheManager.createCache("aclCache", configuration);
//        }
//        
//        return cacheManager;
//    }
//} // //Class CacheConfig, programmatic approach STARTs -- 
// */
//
//// A total programmatic approach of CacheConfig.java
///*//Class CacheConfig, programmatic approach STARTs --
// package com.cybage.config;
//
//import org.ehcache.config.builders.CacheConfigurationBuilder;
//import org.ehcache.config.builders.ExpiryPolicyBuilder;
//import org.ehcache.config.builders.ResourcePoolsBuilder;
//import org.ehcache.jsr107.Eh107Configuration;
//import org.springframework.cache.annotation.EnableCaching;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//import javax.cache.CacheManager;
//import javax.cache.Caching;
//import javax.cache.spi.CachingProvider;
//import java.time.Duration;
//
//@Configuration
//@EnableCaching
//public class CacheConfig {
//
//    @Bean
//    public CacheManager jCacheManager() {
//        CachingProvider provider = Caching.getCachingProvider();
//        CacheManager cacheManager = provider.getCacheManager();
//        
//        // Create cache configuration
//        javax.cache.configuration.Configuration<Object, Object> cacheConfig = 
//            Eh107Configuration.fromEhcacheCacheConfiguration(
//                CacheConfigurationBuilder.newCacheConfigurationBuilder(
//                    Object.class, Object.class,
//                    ResourcePoolsBuilder.heap(1000)
//                ).withExpiry(ExpiryPolicyBuilder.timeToLiveExpiration(Duration.ofSeconds(600)))
//            );
//        
//        // Create all required caches
//        createCacheIfNotExists(cacheManager, "aclCache", cacheConfig);
//        createCacheIfNotExists(cacheManager, "com.cybage.domain.Document", cacheConfig);
//        createCacheIfNotExists(cacheManager, "com.cybage.domain.Document.permissions", cacheConfig);
//        createCacheIfNotExists(cacheManager, "springSecurityAclCache", cacheConfig);
//        
//        return cacheManager;
//    }
//    
//    private void createCacheIfNotExists(CacheManager cacheManager, String cacheName, 
//                                       javax.cache.configuration.Configuration<Object, Object> config) {
//        if (cacheManager.getCache(cacheName) == null) {
//            cacheManager.createCache(cacheName, config);
//        }
//    }
//} //Class CacheConfig, programmatic approach ENDs --
//
// */ 
//
//
//
