//package com.cybage.service;
//
//import com.cybage.domain.Document;
//import com.cybage.repository.DocumentRepository;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.security.acls.domain.BasePermission;
//import org.springframework.security.acls.model.MutableAclService;
//import org.springframework.security.test.context.support.WithMockUser;
//import org.springframework.test.context.ActiveProfiles;
//import org.springframework.transaction.annotation.Transactional;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//
//@SpringBootTest
//@ActiveProfiles("test")
//@Transactional
//public class DocumentServiceImplTest1 {
//
//    @Autowired
//    private DocumentService documentService;
//
//    @Autowired
//    private DocumentRepository documentRepository;
//
//    @Autowired
//    private MutableAclService mutableAclService;
//
//    @Test
//    @WithMockUser(username = "cybUser1")
//    public void testCreateDocument() {
//        // Create a document as USER1
//        Document document = new Document("Test Document", "Test Content", "cybUser1");
//        Document savedDocument = documentService.createDocument(document);
//        
//        assertNotNull(savedDocument.getId());
//        assertEquals("Test Document", savedDocument.getName());
//        assertEquals("Test Content", savedDocument.getContent());
//        assertEquals("cybUser1", savedDocument.getOwner());
//    }
//
//    @Test
//    @WithMockUser(username = "admin", roles = {"ADMIN"})
//    public void testAdminCanAccessAllDocuments() {
//        // Simple test to verify admin can access documents
//        Document document = documentService.createDocument(
//            new Document("Admin Test Doc", "Admin Content", "admin"));
//        
//        assertEquals(1, documentService.findByOwner("admin").size());
//    }
//}
package com;


