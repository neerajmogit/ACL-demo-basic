package com.cybage.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cybage.domain.Document;
import com.cybage.domain.XPermission;
import com.cybage.repository.XPermissionRepository;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@ExtendWith(MockitoExtension.class)
public class AclServiceImplTest {

    @Mock
    private XPermissionRepository permissionRepository;
    
    @InjectMocks
    private AclServiceImpl aclService;
    
    private Document document;
    private XPermission readPermission;
    private XPermission writePermission;
    
    @BeforeEach
    public void setup() {
        document = new Document(1L, "Test Document", "Test Content", "owner");
        readPermission = new XPermission(1L, document, "user1", 1);
        writePermission = new XPermission(2L, document, "user1", 2);
    }
    
    @Test
    public void testHasPermission_Owner_Read() {
        boolean result = aclService.hasPermission(document, "owner", 1);
        
        assertTrue(result);
        verify(permissionRepository, never()).findByDocumentAndUsernameAndPermission(any(), anyString(), anyInt());
    }
    
    @Test
    public void testHasPermission_Owner_Write() {
        boolean result = aclService.hasPermission(document, "owner", 2);
        
        assertTrue(result);
        verify(permissionRepository, never()).findByDocumentAndUsernameAndPermission(any(), anyString(), anyInt());
    }
    
    @Test
    public void testHasPermission_User_HasReadPermission() {
        when(permissionRepository.findByDocumentAndUsernameAndPermission(document, "user1", 1))
            .thenReturn(Optional.of(readPermission));
        
        boolean result = aclService.hasPermission(document, "user1", 1);
        
        assertTrue(result);
        verify(permissionRepository, times(1)).findByDocumentAndUsernameAndPermission(document, "user1", 1);
    }
    
    @Test
    public void testHasPermission_User_HasWritePermission() {
        when(permissionRepository.findByDocumentAndUsernameAndPermission(document, "user1", 2))
            .thenReturn(Optional.of(writePermission));
        
        boolean result = aclService.hasPermission(document, "user1", 2);
        
        assertTrue(result);
        verify(permissionRepository, times(1)).findByDocumentAndUsernameAndPermission(document, "user1", 2);
    }
    
    @Test
    public void testHasPermission_User_NoPermission() {
        when(permissionRepository.findByDocumentAndUsernameAndPermission(document, "user2", 1))
            .thenReturn(Optional.empty());
        
        boolean result = aclService.hasPermission(document, "user2", 1);
        
        assertFalse(result);
        verify(permissionRepository, times(1)).findByDocumentAndUsernameAndPermission(document, "user2", 1);
    }
    
    @Test
    public void testAddPermission() {
        when(permissionRepository.findByDocumentAndUsernameAndPermission(document, "user2", 1))
            .thenReturn(Optional.empty());
        
        aclService.addPermission(document, "user2", 1);
        
        verify(permissionRepository, times(1)).findByDocumentAndUsernameAndPermission(document, "user2", 1);
        verify(permissionRepository, times(1)).save(any(XPermission.class));
    }
    
    @Test
    public void testAddPermission_AlreadyExists() {
        XPermission existingPermission = new XPermission(3L, document, "user2", 1);
        when(permissionRepository.findByDocumentAndUsernameAndPermission(document, "user2", 1))
            .thenReturn(Optional.of(existingPermission));
        
        aclService.addPermission(document, "user2", 1);
        
        verify(permissionRepository, times(1)).findByDocumentAndUsernameAndPermission(document, "user2", 1);
        verify(permissionRepository, never()).save(any(XPermission.class));
    }
    
    @Test
    public void testRemovePermission_Exists() {
        XPermission existingPermission = new XPermission(3L, document, "user2", 1);
        when(permissionRepository.findByDocumentAndUsernameAndPermission(document, "user2", 1))
            .thenReturn(Optional.of(existingPermission));
        
        aclService.removePermission(document, "user2", 1);
        
        verify(permissionRepository, times(1)).findByDocumentAndUsernameAndPermission(document, "user2", 1);
        verify(permissionRepository, times(1)).delete(existingPermission);
    }
    
    @Test
    public void testRemovePermission_NotExists() {
        when(permissionRepository.findByDocumentAndUsernameAndPermission(document, "user2", 1))
            .thenReturn(Optional.empty());
        
        aclService.removePermission(document, "user2", 1);
        
        verify(permissionRepository, times(1)).findByDocumentAndUsernameAndPermission(document, "user2", 1);
        verify(permissionRepository, never()).delete(any(XPermission.class));
    }
    
    @Test
    public void testGetDocumentPermissions() {
        List<XPermission> permissions = Arrays.asList(readPermission, writePermission);
        when(permissionRepository.findByDocument(document)).thenReturn(permissions);
        
        List<XPermission> result = aclService.getDocumentPermissions(document);
        
        assertEquals(2, result.size());
        assertEquals("user1", result.get(0).getUsername());
        assertEquals(1, result.get(0).getPermission());
        assertEquals("user1", result.get(1).getUsername());
        assertEquals(2, result.get(1).getPermission());
        
        verify(permissionRepository, times(1)).findByDocument(document);
    }
}




//package com.cybage.service;
//
//import com.cybage.domain.Document;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.junit.jupiter.MockitoExtension;
//import org.springframework.security.acls.domain.BasePermission;
//import org.springframework.security.acls.domain.ObjectIdentityImpl;
//import org.springframework.security.acls.domain.PrincipalSid;
//import org.springframework.security.acls.model.*;
//
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.List;
//
//import static org.junit.jupiter.api.Assertions.*;
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.Mockito.*;
//
//@ExtendWith(MockitoExtension.class)
//public class AclServiceImplTest {
//
//    @Mock
//    private MutableAclService mutableAclService;
//
//    @InjectMocks
//    private AclServiceImpl aclService;
//
//    private Document document;
//    private ObjectIdentity objectIdentity;
//    private Sid sid;
//    private MutableAcl mutableAcl;
//
//    @BeforeEach
//    public void setup() {
//        document = new Document(1L, "Test Document", "Test Content", "owner");
//        objectIdentity = new ObjectIdentityImpl(Document.class, document.getId());
//        sid = new PrincipalSid("testuser");
//        
//        mutableAcl = mock(MutableAcl.class);
//    }
//
//    @Test
//    public void testAddPermission_ExistingAcl() throws Exception {
//        // Setup
//        when(mutableAclService.readAclById(objectIdentity)).thenReturn(mutableAcl);
//        when(mutableAcl.getEntries()).thenReturn(new ArrayList<>());
//        
//        // Execute
//        aclService.addPermission(document, "testuser", 1);
//        
//        // Verify
//        verify(mutableAclService).readAclById(objectIdentity);
//        verify(mutableAcl).insertAce(eq(0), any(Permission.class), any(Sid.class), eq(true));
//        verify(mutableAclService).updateAcl(mutableAcl);
//    }
//
//    @Test
//    public void testAddPermission_NewAcl() throws Exception {
//        // Setup
//        when(mutableAclService.readAclById(objectIdentity)).thenThrow(NotFoundException.class);
//        when(mutableAclService.createAcl(objectIdentity)).thenReturn(mutableAcl);
//        when(mutableAcl.getEntries()).thenReturn(new ArrayList<>());
//        
//        // Execute
//        aclService.addPermission(document, "testuser", 1);
//        
//        // Verify
//        verify(mutableAclService).readAclById(objectIdentity);
//        verify(mutableAclService).createAcl(objectIdentity);
//        verify(mutableAcl).insertAce(eq(0), any(Permission.class), any(Sid.class), eq(true));
//        verify(mutableAclService).updateAcl(mutableAcl);
//    }
//
//    @Test
//    public void testRemovePermission_Success() throws Exception {
//        // Setup
//        AccessControlEntry ace = mock(AccessControlEntry.class);
//        when(ace.getSid()).thenReturn(new PrincipalSid("testuser"));
//        when(ace.getPermission()).thenReturn(BasePermission.READ);
//        
//        List<AccessControlEntry> entries = new ArrayList<>();
//        entries.add(ace);
//        
//        when(mutableAclService.readAclById(objectIdentity)).thenReturn(mutableAcl);
//        when(mutableAcl.getEntries()).thenReturn(entries);
//        
//        // Execute
//        aclService.removePermission(document, "testuser", 1);
//        
//        // Verify
//        verify(mutableAclService).readAclById(objectIdentity);
//        verify(mutableAcl).deleteAce(0);
//        verify(mutableAclService).updateAcl(mutableAcl);
//    }
//
//    @Test
//    public void testRemovePermission_NoMatchingPermission() throws Exception {
//        // Setup
//        AccessControlEntry ace = mock(AccessControlEntry.class);
//        when(ace.getSid()).thenReturn(new PrincipalSid("otheruser"));
//        when(ace.getPermission()).thenReturn(BasePermission.READ);
//        
//        List<AccessControlEntry> entries = new ArrayList<>();
//        entries.add(ace);
//        
//        when(mutableAclService.readAclById(objectIdentity)).thenReturn(mutableAcl);
//        when(mutableAcl.getEntries()).thenReturn(entries);
//        
//        // Execute
//        aclService.removePermission(document, "testuser", 1);
//        
//        // Verify
//        verify(mutableAclService).readAclById(objectIdentity);
//        verify(mutableAcl, never()).deleteAce(anyInt());
//        verify(mutableAclService).updateAcl(mutableAcl);
//    }
//
//    @Test
//    public void testRemovePermission_AclNotFound() {
//        // Setup
//        when(mutableAclService.readAclById(objectIdentity)).thenThrow(NotFoundException.class);
//        
//        // Execute & Verify
//        assertThrows(RuntimeException.class, () -> {
//            aclService.removePermission(document, "testuser", 1);
//        });
//        
//        verify(mutableAclService).readAclById(objectIdentity);
//        verify(mutableAclService, never()).updateAcl(any(MutableAcl.class));
//    }
//
//    @Test
//    public void testHasPermission_True() throws Exception {
//        // Setup
//        Acl acl = mock(Acl.class);
//        when(mutableAclService.readAclById(objectIdentity)).thenReturn(acl);
//        when(acl.isGranted(any(List.class), any(List.class), eq(true))).thenReturn(true);
//        
//        // Execute
//        boolean result = aclService.hasPermission(document, "testuser", 1);
//        
//        // Verify
//        assertTrue(result);
//        verify(mutableAclService).readAclById(objectIdentity);
//        verify(acl).isGranted(any(List.class), any(List.class), eq(true));
//    }
//
//    @Test
//    public void testHasPermission_False() throws Exception {
//        // Setup
//        Acl acl = mock(Acl.class);
//        when(mutableAclService.readAclById(objectIdentity)).thenReturn(acl);
//        when(acl.isGranted(any(List.class), any(List.class), eq(true))).thenReturn(false);
//        
//        // Execute
//        boolean result = aclService.hasPermission(document, "testuser", 1);
//        
//        // Verify
//        assertFalse(result);
//        verify(mutableAclService).readAclById(objectIdentity);
//        verify(acl).isGranted(any(List.class), any(List.class), eq(true));
//    }
//
//    @Test
//    public void testHasPermission_AclNotFound() throws Exception {
//        // Setup
//        when(mutableAclService.readAclById(objectIdentity)).thenThrow(NotFoundException.class);
//        
//        // Execute
//        boolean result = aclService.hasPermission(document, "testuser", 1);
//        
//        // Verify
//        assertFalse(result);
//        verify(mutableAclService).readAclById(objectIdentity);
//    }
//}
//
//
//
//
////package com.cybage.service;
////
////import com.cybage.domain.Document;
////import org.junit.jupiter.api.BeforeEach;
////import org.junit.jupiter.api.Test;
////import org.springframework.beans.factory.annotation.Autowired;
////import org.springframework.boot.test.context.SpringBootTest;
////import org.springframework.security.acls.domain.BasePermission;
////import org.springframework.security.acls.model.MutableAclService;
////import org.springframework.security.test.context.support.WithMockUser;
////import org.springframework.test.context.jdbc.Sql;
////import org.springframework.transaction.annotation.Transactional;
////
////import static org.junit.jupiter.api.Assertions.*;
////
////@SpringBootTest
////@Transactional
////@Sql({"classpath:schema-test.sql", "classpath:data-test.sql"})
////public class AclServiceImplTest {
////
////    @Autowired
////    private AclService aclService;
////
////    @Autowired
////    private DocumentService documentService;
////
////    private Document testDocument;
////
////    @BeforeEach
////    public void setup() {
////        // Create a test document
////        testDocument = new Document("Test ACL Document", "Test content for ACL", "testuser");
////        testDocument = documentService.saveDocument(testDocument);
////    }
////
////    @Test
////    @WithMockUser(username = "testuser")
////    public void testAddAndCheckPermission() {
////        // Add READ permission
////        aclService.addPermission(testDocument, "user1", BasePermission.READ.getMask());
////        
////        // Check if permission was added
////        assertTrue(aclService.hasPermission(testDocument, "user1", BasePermission.READ.getMask()));
////        assertFalse(aclService.hasPermission(testDocument, "user1", BasePermission.WRITE.getMask()));
////        
////        // Add WRITE permission
////        aclService.addPermission(testDocument, "user1", BasePermission.WRITE.getMask());
////        
////        // Check if both permissions exist
////        assertTrue(aclService.hasPermission(testDocument, "user1", BasePermission.READ.getMask()));
////        assertTrue(aclService.hasPermission(testDocument, "user1", BasePermission.WRITE.getMask()));
////    }
////
////    @Test
////    @WithMockUser(username = "testuser")
////    public void testRemovePermission() {
////        // Add permissions
////        aclService.addPermission(testDocument, "user2", BasePermission.READ.getMask());
////        aclService.addPermission(testDocument, "user2", BasePermission.WRITE.getMask());
////        
////        // Verify permissions exist
////        assertTrue(aclService.hasPermission(testDocument, "user2", BasePermission.READ.getMask()));
////        assertTrue(aclService.hasPermission(testDocument, "user2", BasePermission.WRITE.getMask()));
////        
////        // Remove READ permission
////        aclService.removePermission(testDocument, "user2", BasePermission.READ.getMask());
////        
////        // Verify READ is gone but WRITE remains
////        assertFalse(aclService.hasPermission(testDocument, "user2", BasePermission.READ.getMask()));
////        assertTrue(aclService.hasPermission(testDocument, "user2", BasePermission.WRITE.getMask()));
////    }
////
////    @Test
////    @WithMockUser(username = "testuser")
////    public void testHasPermissionForNonExistentUser() {
////        // Should return false for a user with no permissions
////        assertFalse(aclService.hasPermission(testDocument, "nonexistentuser", BasePermission.READ.getMask()));
////    }
////}
