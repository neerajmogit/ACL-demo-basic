package com.cybage.service;

import com.cybage.domain.Document;
import com.cybage.exception.DocumentNotFoundException;
import com.cybage.repository.DocumentRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class DocumentServiceImplTest {

    @Mock
    private DocumentRepository documentRepository;

    @InjectMocks
    private DocumentServiceImpl documentService;

    private Document document1;
    private Document document2;

    @BeforeEach
    public void setup() {
        document1 = new Document(1L, "Test Document 1", "Content 1", "user1");
        document2 = new Document(2L, "Test Document 2", "Content 2", "user2");
    }

    @Test
    public void testSaveDocument() {
        when(documentRepository.save(any(Document.class))).thenReturn(document1);

        Document savedDocument = documentService.saveDocument(document1);

        assertNotNull(savedDocument);
        assertEquals(1L, savedDocument.getId());
        assertEquals("Test Document 1", savedDocument.getName());
        verify(documentRepository, times(1)).save(document1);
    }

    @Test
    public void testFindById_Success() {
        when(documentRepository.findById(1L)).thenReturn(Optional.of(document1));

        Document foundDocument = documentService.findById(1L);

        assertNotNull(foundDocument);
        assertEquals(1L, foundDocument.getId());
        assertEquals("Test Document 1", foundDocument.getName());
        verify(documentRepository, times(1)).findById(1L);
    }

    @Test
    public void testFindById_NotFound() {
        when(documentRepository.findById(3L)).thenReturn(Optional.empty());

        assertThrows(DocumentNotFoundException.class, () -> {
            documentService.findById(3L);
        });
        
        verify(documentRepository, times(1)).findById(3L);
    }

    @Test
    public void testFindAll() {
        List<Document> documents = Arrays.asList(document1, document2);
        when(documentRepository.findAll()).thenReturn(documents);

        List<Document> foundDocuments = documentService.findAll();

        assertNotNull(foundDocuments);
        assertEquals(2, foundDocuments.size());
        assertEquals("Test Document 1", foundDocuments.get(0).getName());
        assertEquals("Test Document 2", foundDocuments.get(1).getName());
        verify(documentRepository, times(1)).findAll();
    }

    @Test
    public void testUpdateDocument_Success() {
        Document updatedDocument = new Document(1L, "Updated Document", "Updated Content", "user1");
        
        when(documentRepository.findById(1L)).thenReturn(Optional.of(document1));
        when(documentRepository.save(any(Document.class))).thenReturn(updatedDocument);

        Document result = documentService.updateDocument(updatedDocument);

        assertNotNull(result);
        assertEquals("Updated Document", result.getName());
        assertEquals("Updated Content", result.getContent());
        verify(documentRepository, times(1)).findById(1L);
        verify(documentRepository, times(1)).save(updatedDocument);
    }

//    @Test
//    public void testUpdateDocument_NotFound() {
//
//        Document nonExistentDocument = new Document(3L, "Non-existent", "Content", "user3");
//        when(documentRepository.findById(3L)).thenReturn(Optional.empty());
//        assertThrows(DocumentNotFoundException.class, () -> {   documentService.updateDocument(nonExistentDocument);
//        																			});
//        verify(documentRepository, times(1)).findById(3L);
//        verify(documentRepository, never()).save(any(Document.class));
//    }

    @Test // ???????????????
    public void testUpdatedDocument_NotFound() {
    	// Given
        Document updatedDocument = new Document(3L, "Updated Document", "Updated Document", "user3");
        when(documentRepository.findById(3L)).thenReturn(Optional.empty());
        // When & Then
        assertThrows(DocumentNotFoundException.class, () -> {   documentService.updateDocument(updatedDocument);
        																				  });
        verify(documentRepository, times(1)).findById(3L);
        verify(documentRepository, never()).save(any(Document.class));
    }
    
    @Test
    public void  testDelete_Success() {
        when(documentRepository.existsById(1L)).thenReturn(true);
        doNothing().when(documentRepository).deleteById(1L);

        documentService.deleteDocument(1L);

        verify(documentRepository, times(1)).existsById(1L);
        verify(documentRepository, times(1)).deleteById(1L);
    }

    @Test
    public void testDeleteDocument_NotFound() {
        when(documentRepository.existsById(3L)).thenReturn(false);

        assertThrows(DocumentNotFoundException.class, () -> {
            documentService.deleteDocument(3L);
        });
        
        verify(documentRepository, times(1)).existsById(3L);
        verify(documentRepository, never()).deleteById(anyLong());
    }

    @Test
    public void testFindByOwner_Success() {
        List<Document> userDocuments = Collections.singletonList(document1);
        when(documentRepository.findByOwner("user1")).thenReturn(userDocuments);

        List<Document> foundDocuments = documentService.findByOwner("user1");

        assertNotNull(foundDocuments);
        assertEquals(1, foundDocuments.size());
        assertEquals("Test Document 1", foundDocuments.get(0).getName());
        verify(documentRepository, times(1)).findByOwner("user1");
    }

    @Test
    public void testFindByOwner_NotFound() {
        when(documentRepository.findByOwner("nonexistent")).thenReturn(Collections.emptyList());

        assertThrows(DocumentNotFoundException.class, () -> {
            documentService.findByOwner("nonexistent");
        });
        
        verify(documentRepository, times(1)).findByOwner("nonexistent");
    }

    @Test
    public void testFindByNameContaining_Success() {
        List<Document> matchingDocuments = Arrays.asList(document1, document2);
        when(documentRepository.searchDocuments("Test")).thenReturn(matchingDocuments);
        List<Document> foundDocuments = documentService.findByNameContaining("Test");
        
        assertNotNull(foundDocuments);
        assertEquals(2, foundDocuments.size());
        verify(documentRepository, times(1)).searchDocuments("Test");
    }

//    @Test
//    public void testFindByNameContaining_NotFound() {
////        when(documentRepository.findByNameContaining("NonExistent")).thenReturn(Collections.emptyList());
//    	when(documentRepository.fin("NonExistent")).thenReturn(Collections.emptyList());
//        assertThrows(DocumentNotFoundException.class, () -> {
//            documentService.findByNameContaining("NonExistent");
//        });
//        
//        verify(documentRepository, times(1)).findByNameContaining("NonExistent");
//    }

    @Test
    public void testClearCache() {
        // This method doesn't interact with the repository, it just has the @CacheEvict annotation
        // So we just verify it doesn't throw an exception
        assertDoesNotThrow(() -> documentService.clearCache());
    }
}





//package com.cybage.service;
//
//import com.cybage.domain.Document;
//import com.cybage.exception.DocumentNotFoundException;
//import com.cybage.repository.DocumentRepository;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.junit.jupiter.MockitoExtension;
//
//import java.util.Arrays;
//import java.util.Collections;
//import java.util.List;
//import java.util.Optional;
//
//import static org.junit.jupiter.api.Assertions.*;
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.Mockito.*;
//
//@ExtendWith(MockitoExtension.class)
//public class DocumentServiceImplTest {
//
//    @Mock
//    private DocumentRepository documentRepository;
//
//    @InjectMocks
//    private DocumentServiceImpl documentService;
//
//    private Document document1;
//    private Document document2;
//
//    @BeforeEach
//    public void setup() {
//        document1 = new Document(1L, "Test Document 1", "Content 1", "user1");
//        document2 = new Document(2L, "Test Document 2", "Content 2", "user2");
//    }
//
//    @Test
//    public void testSaveDocument() {
//        when(documentRepository.save(any(Document.class))).thenReturn(document1);
//
//        Document savedDocument = documentService.saveDocument(document1);
//
//        assertNotNull(savedDocument);
//        assertEquals(1L, savedDocument.getId());
//        assertEquals("Test Document 1", savedDocument.getName());
//        verify(documentRepository, times(1)).save(document1);
//    }
//
//    @Test
//    public void testFindById_Success() {
//        when(documentRepository.findById(1L)).thenReturn(Optional.of(document1));
//
//        Document foundDocument = documentService.findById(1L);
//
//        assertNotNull(foundDocument);
//        assertEquals(1L, foundDocument.getId());
//        assertEquals("Test Document 1", foundDocument.getName());
//        verify(documentRepository, times(1)).findById(1L);
//    }
//
//    @Test
//    public void testFindById_NotFound() {
//        when(documentRepository.findById(3L)).thenReturn(Optional.empty());
//
//        assertThrows(DocumentNotFoundException.class, () -> {
//            documentService.findById(3L);
//        });
//        
//        verify(documentRepository, times(1)).findById(3L);
//    }
//
//    @Test
//    public void testFindAll() {
//        List<Document> documents = Arrays.asList(document1, document2);
//        when(documentRepository.findAll()).thenReturn(documents);
//
//        List<Document> foundDocuments = documentService.findAll();
//
//        assertNotNull(foundDocuments);
//        assertEquals(2, foundDocuments.size());
//        assertEquals("Test Document 1", foundDocuments.get(0).getName());
//        assertEquals("Test Document 2", foundDocuments.get(1).getName());
//        verify(documentRepository, times(1)).findAll();
//    }
//
//    @Test
//    public void testUpdateDocument_Success() {
//        Document updatedDocument = new Document(1L, "Updated Document", "Updated Content", "user1");
//        
//        when(documentRepository.findById(1L)).thenReturn(Optional.of(document1));
//        when(documentRepository.save(any(Document.class))).thenReturn(updatedDocument);
//
//        Document result = documentService.updateDocument(updatedDocument);
//
//        assertNotNull(result);
//        assertEquals("Updated Document", result.getName());
//        assertEquals("Updated Content", result.getContent());
//        verify(documentRepository, times(1)).findById(1L);
//        verify(documentRepository, times(1)).save(updatedDocument);
//    }
//
//    @Test
//    public void testUpdateDocument_NotFound() {
//        Document nonExistentDocument = new Document(3L, "Non-existent", "Content", "user3");
//        
//        when(documentRepository.findById(3L)).thenReturn(Optional.empty());
//
//        assertThrows(DocumentNotFoundException.class, () -> {
//            documentService.updateDocument(nonExistentDocument);
//        });
//        
//        verify(documentRepository, times(1)).findById(3L);
//        verify(documentRepository, never()).save(any(Document.class));
//    }
//
//    @Test
//    public void testDeleteDocument_Success() {
//        when(documentRepository.existsById(1L)).thenReturn(true);
//        doNothing().when(documentRepository).deleteById(1L);
//
//        documentService.deleteDocument(1L);
//
//        verify(documentRepository, times(1)).existsById(1L);
//        verify(documentRepository, times(1)).deleteById(1L);
//    }
//
//    @Test
//    public void testDeleteDocument_NotFound() {
//        when(documentRepository.existsById(3L)).thenReturn(false);
//
//        assertThrows(DocumentNotFoundException.class, () -> {
//            documentService.deleteDocument(3L);
//        });
//        
//        verify(documentRepository, times(1)).existsById(3L);
//        verify(documentRepository, never()).deleteById(anyLong());
//    }
//
//    @Test
//    public void testFindByOwner_Success() {
//        List<Document> userDocuments = Collections.singletonList(document1);
//        when(documentRepository.findByOwner("user1")).thenReturn(userDocuments);
//
//        List<Document> foundDocuments = documentService.findByOwner("user1");
//
//        assertNotNull(foundDocuments);
//        assertEquals(1, foundDocuments.size());
//        assertEquals("Test Document 1", foundDocuments.get(0).getName());
//        verify(documentRepository, times(1)).findByOwner("user1");
//    }
//
//    @Test
//    public void testFindByOwner_NotFound() {
//        when(documentRepository.findByOwner("nonexistent")).thenReturn(Collections.emptyList());
//
//        assertThrows(DocumentNotFoundException.class, () -> {
//            documentService.findByOwner("nonexistent");
//        });
//        
//        verify(documentRepository, times(1)).findByOwner("nonexistent");
//    }
//
//    @Test
//    public void testFindByNameContaining_Success() {
//        List<Document> matchingDocuments = Arrays.asList(document1, document2);
//        when(documentRepository.findByNameContaining("Test")).thenReturn(matchingDocuments);
//
//        List<Document> foundDocuments = documentService.findByNameContaining("Test");
//
//        assertNotNull(foundDocuments);
//        assertEquals(2, foundDocuments.size());
//        verify(documentRepository, times(1)).findByNameContaining("Test");
//    }
//
//    @Test
//    public void testFindByNameContaining_NotFound() {
//        when(documentRepository.findByNameContaining("NonExistent")).thenReturn(Collections.emptyList());
//
//        assertThrows(DocumentNotFoundException.class, () -> {
//            documentService.findByNameContaining("NonExistent");
//        });
//        
//        verify(documentRepository, times(1)).findByNameContaining("NonExistent");
//    }
//
//    @Test
//    public void testClearCache() {
//        // This method doesn't interact with the repository, it just has the @CacheEvict annotation
//        // So we just verify it doesn't throw an exception
//        assertDoesNotThrow(() -> documentService.clearCache());
//    }
//}





//package com.cybage.service;
//
//import static org.junit.jupiter.api.Assertions.*;
//import static org.mockito.Mockito.*;
//
//import java.util.List;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.jdbc.Sql;
//import org.springframework.transaction.annotation.Transactional;
//
//import com.cybage.domain.Document;
//import com.cybage.repository.DocumentRepository;
//
///*   It tests all the CRUD operations (Create, Read, Update, Delete) as well as the custom findByOwner method.
//
//Key features of this test class:
//
//			@SpringBootTest: Loads the full application context for integration testing
//			@Transactional: Ensures each test runs in its own transaction that is "rolled back after the test completes"
//			@Sql: Loads the test schema and data before running the tests from our data-test.sql file
//		   Integration Tests: All tests interact with the actual database using the test data we defined
//
//
// */
//
//@SpringBootTest
//@Transactional
//@Sql({"classpath:schema-test.sql", "classpath:data-test.sql"})
//public class DocumentServiceImplTest {
//
//    @Autowired
//    private DocumentService documentService;
//
//    // For integration tests with real database
//    @Test
//    public void testCreateDocument_Integration() {
//
//        // Create a test document using the available constructor
////        Document document = new Document(null, "Integration Test Document", "Integration Test Content", "testuser");
//        
//        // Alternatively, if you have a constructor that takes name, content, owner:
//         Document document = new Document("Integration Test Document", "Integration Test Content", "testuser");
//
//        // Save the document
//        Document savedDocument = documentService.saveDocument(document);
//
//        // Verify the document was saved correctly
//        assertNotNull(savedDocument.getId());
//        assertEquals("Integration Test Document", savedDocument.getName());
//        assertEquals("Integration Test Content", savedDocument.getContent());    }
//
//    @Test
//    public void testFindDocumentById_Integration() {
//        // Test finding an existing document from our test data
//        Document document = documentService.findById(1L);
//        
//        assertNotNull(document);
//        assertEquals("Sample Document 1", document.getName());
//        assertEquals("This is the content of sample document 1", document.getContent());
//        assertEquals("user1", document.getOwner());
//    }
//
//    @Test
//    public void testFindDocumentById_NotFound_Integration() {
//        // Test finding a non-existent document
//        Exception exception = assertThrows(RuntimeException.class, () -> {
//            documentService.findById(999L);
//        });
//        
//        assertTrue(exception.getMessage().contains("Document not found with id: 999"));
//    }
//
//    @Test
//    public void testFindAll_Integration() {
//        // Test finding all documents
//        List<Document> documents = documentService.findAll();
//        
//        // We should have at least the 3 documents from our test data
//        assertTrue(documents.size() >= 3);
//        
//        // Verify some of the documents
//        boolean foundDoc1 = false;
//        boolean foundDoc2 = false;
//        
//        for (Document doc : documents) {
//            if (doc.getId() == 1L) {
//                assertEquals("Sample Document 1", doc.getName());
//                foundDoc1 = true;
//            } else if (doc.getId() == 2L) {
//                assertEquals("Sample Document 2", doc.getName());
//                foundDoc2 = true;
//            }
//        }
//        
//        assertTrue(foundDoc1 && foundDoc2, "Should have found documents 1 and 2");
//    }
//
//    @Test
//    public void testUpdateDocument_Integration() {
//        // Get an existing document
//        Document document = documentService.findById(1L);
//        
//        // Update it
//        document.setName("Updated Document 1");
//        document.setContent("Updated content for document 1");
//        
//        // Save the updates
//        Document updatedDocument = documentService.updateDocument(document);
//        
//        // Verify the updates
//        assertEquals(1L, updatedDocument.getId());
//        assertEquals("Updated Document 1", updatedDocument.getName());
//        assertEquals("Updated content for document 1", updatedDocument.getContent());
//        assertEquals("user1", updatedDocument.getOwner());
//        
//        // Verify by retrieving it again
//        Document retrievedDocument = documentService.findById(1L);
//        assertEquals("Updated Document 1", retrievedDocument.getName());
//    }
//
//    @Test
//    public void testDeleteDocument_Integration() {
//        // First verify the document exists
//        Document document = documentService.findById(3L);
//        assertNotNull(document);
//        
//        // Delete it
//        documentService.deleteDocument(3L);
//        
//        // Verify it's gone
//        Exception exception = assertThrows(RuntimeException.class, () -> {
//            documentService.findById(3L);
//        });
//        
//        assertTrue(exception.getMessage().contains("Document not found with id: 3"));
//    }
//
//    @Test
//    public void testFindByOwner_Integration() {
//        // Find documents by owner
//        List<Document> user1Documents = documentService.findByOwner("user1");
//        
//        // Should have at least 2 documents (from our test data)
//        assertTrue(user1Documents.size() >= 2);
//        
//        // All documents should be owned by user1
//        for (Document doc : user1Documents) {
//            assertEquals("user1", doc.getOwner());
//        }
//        
//        // Find documents for another owner
//        List<Document> user2Documents = documentService.findByOwner("user2");
//        
//        // Should have at least 1 document (from our test data)
//        assertTrue(user2Documents.size() >= 1);
//        
//        // All documents should be owned by user2
//        for (Document doc : user2Documents) {
//            assertEquals("user2", doc.getOwner());
//        }
//    }
//
//    // Additional test for non-existent owner
//    @Test
//    public void testFindByOwner_NoResults_Integration() {
//        List<Document> documents = documentService.findByOwner("nonexistentuser");
//        assertTrue(documents.isEmpty());
//    }
//}





														//package com.cybage.service;
														//
														//import org.junit.jupiter.api.Test;
														//import org.springframework.beans.factory.annotation.Autowired;
														//import org.springframework.boot.test.context.SpringBootTest;
														//import org.springframework.test.context.jdbc.Sql;
														//
														//import com.cybage.domain.Document;
														//
														//import static org.junit.jupiter.api.Assertions.assertEquals;
														//import static org.junit.jupiter.api.Assertions.assertNotNull;
														//
														//@SpringBootTest
														//@Sql({"classpath:schema-test.sql", "classpath:data-test.sql"})
														//public class DocumentServiceImplTest {
														//
														//    @Autowired
														//    private DocumentService documentService;
														//
														//    @Test
														//    public void testCreateDocument() {
														////      // Create a test document
														//      Document document = new Document();
														//      document.setName("Test Document");
														//      document.setContent("Test Content");
														//      document.setOwner("Test Owner");
														//
														//      // Save the document
														//      Document savedDocument = documentService.saveDocument(document);
														//
														//      // Verify the document was saved correctly
														//      assertNotNull(savedDocument.getId());
														//      assertEquals("Test Document", savedDocument.getName());
														//      assertEquals("Test Content", savedDocument.getContent());
														//      assertEquals("Test Owner", savedDocument.getOwner());
														//    }
														//    
														//    @Test
														//    public void testFindDocumentById() {
														//      // Test finding an existing document from our test data
														//      Document document = documentService.findById(1L);
														//      
														//      assertNotNull(document);
														//      assertEquals("Sample Document 1", document.getName());
														//      assertEquals("This is the content of sample document 1", document.getContent());
														//      assertEquals("user1", document.getOwner());
														//    }
														//}




						//package com.cybage.service;
						//
						//import com.cybage.domain.Document;
						//import com.cybage.repository.DocumentRepository;
						//import org.springframework.beans.factory.annotation.Autowired;
						//import org.springframework.stereotype.Service;
						//import org.springframework.transaction.annotation.Transactional;
						//
						//import org.junit.jupiter.api.Test;
						//import org.springframework.boot.test.context.SpringBootTest;
						//import org.springframework.test.context.jdbc.Sql;
						//
						//import static org.junit.jupiter.api.Assertions.assertEquals;
						//import static org.junit.jupiter.api.Assertions.assertNotNull;
						//
						//import java.util.List;
						//
						//@Service
						//@Transactional
						//public class DocumentServiceImplTest implements DocumentService {
						//
						//    private final DocumentRepository documentRepository;
						//
						//    @Autowired
						//    public DocumentServiceImpl(DocumentRepository documentRepository) {
						//        this.documentRepository = documentRepository;
						//    }
						//
						//    @Override
						//    public Document saveDocument(Document document) {
						//        return documentRepository.save(document);
						//    }
						//
						//    @Override
						//    @Transactional(readOnly = true)
						//    public Document findById(Long id) {
						//        return documentRepository.findById(id)
						//                .orElseThrow(() -> new RuntimeException("Document not found with id: " + id));
						//    }
						//
						//    @Override
						//    @Transactional(readOnly = true)
						//    public List<Document> findAll() {
						//        return documentRepository.findAll();
						//    }
						//
						//    @Override
						//    public Document updateDocument(Document document) {
						//        // Check if document exists
						//        if (document.getId() != null) {
						//            documentRepository.findById(document.getId())
						//                    .orElseThrow(() -> new RuntimeException("Document not found with id: " + document.getId()));
						//        }
						//        return documentRepository.save(document);
						//    }
						//
						//    @Override
						//    public void deleteDocument(Long id) {
						//        documentRepository.deleteById(id);
						//    }
						//
						//    @Override
						//    @Transactional(readOnly = true)
						//    public List<Document> findByOwner(String owner) {
						//        return documentRepository.findByOwner(owner);
						//    }
						//}










//package com.cybage.service;
//
//import com.cybage.domain.Document;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.jdbc.Sql;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//
//@SpringBootTest
//@Sql({"classpath:schema-test.sql", "classpath:data-test.sql"})
//public class DocumentServiceImplTest {
//
//    @Autowired
//    private DocumentService documentService;
//
//    @Test
//    public void testCreateDocument() {
//        // Create a test document
//        Document document = new Document();
//        document.setName("Test Document");
//        document.setContent("Test Content");
//        document.setOwner("Test Owner");
//
//        // Save the document
//        Document savedDocument = documentService.saveDocument(document);
//
//        // Verify the document was saved correctly
//        assertNotNull(savedDocument.getId());
//        assertEquals("Test Document", savedDocument.getName());
//        assertEquals("Test Content", savedDocument.getContent());
//        assertEquals("Test Owner", savedDocument.getOwner());
//    }
//    
//    @Test
//    public void testFindDocumentById() {
//        // Test finding an existing document from our test data
//        Document document = documentService.findById(1L);
//        
//        assertNotNull(document);
//        assertEquals("Sample Document 1", document.getName());
//        assertEquals("This is the content of sample document 1", document.getContent());
//        assertEquals("user1", document.getOwner());
//    }
//}
//
//
//
//
//
//
////package com.cybage.service;
////
////import com.cybage.domain.Document;
////import com.cybage.repository.DocumentRepository;
////import org.junit.jupiter.api.Test;
////import org.springframework.beans.factory.annotation.Autowired;
////import org.springframework.boot.test.context.SpringBootTest;
////import org.springframework.security.acls.model.MutableAclService;
////import org.springframework.security.test.context.support.WithMockUser;
////import org.springframework.test.context.ActiveProfiles;
////import org.springframework.transaction.annotation.Transactional;
////
////import static org.junit.jupiter.api.Assertions.assertEquals;
////import static org.junit.jupiter.api.Assertions.assertNotNull;
////
////@SpringBootTest
////@ActiveProfiles("test")
////@Transactional
////public class DocumentServiceImplTest {
////
////    @Autowired
////    private DocumentService documentService;
////
////    @Autowired
////    private DocumentRepository documentRepository;
////
////    @Autowired
////    private MutableAclService mutableAclService;
////
////    @Test
////    @WithMockUser(username = "cybUser1")
////    public void testCreateDocument() {
////        // Create a document as USER1
////        Document document = new Document("Test Document", "Test Content", "cybUser1");
////        Document savedDocument = documentService.createDocument(document);
////        
////        assertNotNull(savedDocument.getId());
////        assertEquals("Test Document", savedDocument.getName());
////        assertEquals("Test Content", savedDocument.getContent());
////        assertEquals("cybUser1", savedDocument.getOwner());
////    }
////}
