package com.cybage.config;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.authentication.configurers.provisioning.InMemoryUserDetailsManagerConfigurer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
//--------------------- new ones
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
//import org.springframework.security.web.SecurityFilterChain;
//import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import com.cybage.service.UserDetailsServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Spring Security Configuration
 Explanation:
	@Configuration, @EnableWebSecurity, @EnableMethodSecurity, @Profile("!test"): These annotations mark this class as a Spring Security configuration 
	class, enable web security, enable method-level security (for @PreAuthorize, etc.), and exclude this configuration from the "test" profile.
	logger: A logger for debugging.
	localhostPort: added explicit port
	@Autowired UserDetailsServiceImpl userDetailsService: Injects your custom UserDetailsService (which should load user data from your database). Important: You have a UserDetailsServiceImpl, which is good, but the userDetailsService() bean at the end of this class overrides it with an in-memory user. You should remove the @Bean annotated userDetailsService() method near the end of this class to use your custom implementation.
	@Autowired JwtAuthenticationFilter jwtAuthFilter: Injects a custom JWT filter. This is commented out, so it's not currently being used.
	authenticationProvider(): Configures the DaoAuthenticationProvider, which performs authentication based on a UserDetailsService and a PasswordEncoder.
	authenticationManager(): Gets the AuthenticationManager from Spring Security.
	filterChain(): Configures the security filter chain:
	.cors(): 		Configures Cross-Origin Resource Sharing (CORS) to allow requests from http://localhost:9192.
	.csrf(): 		Disables Cross-Site Request Forgery (CSRF) protection (you might need to enable this in a production application).
	.sessionManagement(): 		Sets the session creation policy to STATELESS (this is common for REST APIs).
	.authorizeHttpRequests():  Configures authorization rules:
	.requestMatchers("/index.html").permitAll(): 		Allows unauthenticated access to index.html.
	.requestMatchers("/static/**").permitAll(): 		Allows unauthenticated access to all files in the /static/ directory (CSS, JS, images, etc.).
	.requestMatchers("/my_login.html").permitAll(): Allows unauthenticated access to custom login page.
	.requestMatchers("/login").permitAll(): 			Allows unauthenticated access to the /login endpoint.
	.requestMatchers("/x-documents/user").permitAll(): 			Allows unauthenticated access to "/x-documents/user".
	.requestMatchers("/x-documents/cDoc").authenticated(): Requires authentication for "/x-documents/cDoc".
	.requestMatchers("/document-list.html").permitAll(): 			Allows unauthenticated access to "document-list.html".
	.requestMatchers("/document-detail.html").permitAll(): 		Allows unauthenticated access to "document-detail.html".
	.requestMatchers("/permission-management.html").permitAll(): Allows unauthenticated access to "permission-management.html".
	.requestMatchers("/api/public/**").permitAll():  	 Allows unauthenticated access to paths starting with /api/public/.
	.requestMatchers("/api/auth/**").permitAll():  	 Allows unauthenticated access to paths starting with /api/auth/.
	.requestMatchers("/h2-console/**").permitAll(): Allows unauthenticated access to the H2 console (for the in-memory database).  Important: You should only enable this for development; it's a security risk in production.
	.anyRequest().authenticated():   Requires authentication for any other request.
	.formLogin(): 								Configures form-based login:
	.loginPage("/my_login.html"): 		Specifies your custom login page.
	.loginProcessingUrl("/login"): 		Specifies the URL where the login form should submit the credentials.
	.defaultSuccessUrl("/"): 				Specifies the URL to redirect to after successful login.
	.permitAll(): 	Allows unauthenticated access to the login page.
	.logout(): 		Configures logout:
	.logoutRequestMatcher(new AntPathRequestMatcher("/logout")): Specifies the URL that triggers logout.
	.logoutSuccessUrl("/"): 				Specifies the URL to redirect to after successful logout.
	.invalidateHttpSession(true):       Invalidates the user's session.
	.clearAuthentication(true): 			Clears the authentication information.
	.deleteCookies("JSESSIONID"): delete the session cookie.
	 .headers(headers -> headers.frameOptions(frameOptions -> frameOptions.disable())): Disables frame options to allow the H2 console to be displayed in a frame. 
	 				Important: Only disable frame options if you need to use the H2 console; it can make your application vulnerable to clickjacking attacks.
// http.authenticationProvider(authenticationProvider()); // Commented out: You don't need to explicitly set the authentication provider here; Spring Security will use it automatically.
// http.addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class); // Commented Out: This line adds a JWT filter. If you're not using JWT authentication, you can leave it commented out.
	corsConfigurationSource(): Configures CORS to allow requests from http://localhost:9192.
	userDetailsService(): 			Important: This method defines an in-memory user. You should remove this method to use your UserDetailsServiceImpl (which loads users from the database). Having this method here will override your database-backed user details service.
	passwordEncoder(): 			Configures the PasswordEncoder (BCrypt) for encoding passwords. 
 
 */
@Configuration
@EnableWebSecurity
@EnableMethodSecurity
@Profile("!test")  // Active in all profiles except test
public class SecurityConfig {

  private static final Logger logger = LoggerFactory.getLogger(SecurityConfig.class);	
   private static final int localhostPort =9192;
   
    @Autowired
    private UserDetailsServiceImpl userDetailsService;

    @Autowired
    private JwtAuthenticationFilter jwtAuthFilter;
    
    
    /**
     * Authentication provider bean
     */
    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
        authProvider.setUserDetailsService(userDetailsService);
        authProvider.setPasswordEncoder(passwordEncoder());
        return authProvider;
    }

    /**
     * Authentication manager bean
     */
    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authConfig) throws Exception {
        return authConfig.getAuthenticationManager();
    }

    /**
     * Security filter chain configuration
     */
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
    	
    	logger.debug("Configuring HttpSecurity");
        http
            .cors(cors -> cors.configurationSource(corsConfigurationSource()))
            .csrf(csrf -> csrf.disable())
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED/*STATELESS*/))
            .authorizeHttpRequests( 
            						auth ->  {
            				                    logger.debug("Configuring authorization rules");
            				                    auth 
							            	        .requestMatchers("/index.html").permitAll()
							            	        .requestMatchers("/static/**").permitAll() 			// Allow access to all files in /static/
							            	        .requestMatchers("/my_login.html").permitAll() // Allow access to the static\custom  login page
							            	        .requestMatchers("/login").permitAll()    		 	// Allow access to /login (for form submission to the standard Spring Boot login)
							            	        .requestMatchers("/x-documents/user").permitAll() // Add this line.
							            	        .requestMatchers("/create-document.html").permitAll()
							            	        .requestMatchers("/x-documents/cDoc").authenticated()
							            	        .requestMatchers("/document-list.html").permitAll()
							            	        .requestMatchers("/document-detail.html").permitAll()
							            	        .requestMatchers("/permission-management.html").permitAll()
							             
							            	        .requestMatchers("/css/**").permitAll()
							            	        .requestMatchers("/js/**").permitAll()
							            	        .requestMatchers("/api/public/**").permitAll()
							            	        .requestMatchers("/api/auth/**").permitAll()
							            	        .requestMatchers("/h2-console/**").permitAll()
							            	        .anyRequest().authenticated();
            						})
									            .formLogin( form -> {
									            								logger.debug("Configuring form login");
												                     form  //  Enable form-based login
													            		.loginPage("/my_login.html") //  Updated name
													            		.loginProcessingUrl("/login")  //  Even this needs to go in! 
					//									                    .defaultSuccessUrl("/")         //  Redirect to / (which should serve index.html)
													                    .defaultSuccessUrl("/create-document.html", true) // Redirect to "/create-document.html", which should serve this 
					                    								// authenticated user, with create doc page) The true argument for defaultSuccessUrl indicates that the user should 
					                    							    // always be redirected to this URL after successful authentication, regardless of the originally requested URL.
													                    .permitAll();
									            })
									            .logout(logout -> logout
									                    .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
									                    .logoutSuccessUrl("/")
									                    .invalidateHttpSession(true)
									                    .clearAuthentication(true)
									                    .deleteCookies("JSESSIONID")
									            );
        // ------ For H2 Console
        http.headers(headers -> headers.frameOptions(frameOptions -> frameOptions.disable()));
        	//  ------- We don't expect any JWT token filters to be used , at the moment, so commenting out:
        	//           http.authenticationProvider(authenticationProvider());
			//           Add JWT filter before UsernamePasswordAuthenticationFilter
			//           http.addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class);
        
        return http.build();
    }
    
    //For localhost testing added the following method:
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
    	
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOrigins(Arrays.asList("http://localhost:"+localhostPort)); // Allow requests from localhost:localhostPort
        configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        configuration.setAllowedHeaders(Arrays.asList("*"));
        configuration.setAllowCredentials(true);
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }

    @Bean
    public UserDetailsService userDetailsService() {
        UserDetails user =
                User.withUsername("createuser")
                        .password(passwordEncoder().encode("pass")) // Use encoded password
                        .roles("USER")
                        .build();
        return new InMemoryUserDetailsManager(user);
    }

    @Bean
    public PasswordEncoder passwordEncoder() { 
        logger.debug("Creating PasswordEncoder bean (BCrypt)");
        return new BCryptPasswordEncoder();
    }

}
