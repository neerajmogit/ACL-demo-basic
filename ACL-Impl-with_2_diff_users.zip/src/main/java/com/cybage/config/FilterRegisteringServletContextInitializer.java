package com.cybage.config;

import org.springframework.boot.web.servlet.ServletContextInitializer;
import org.springframework.stereotype.Component;

import jakarta.servlet.DispatcherType;
import jakarta.servlet.FilterRegistration;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;

@Component
public class FilterRegisteringServletContextInitializer implements ServletContextInitializer {

    @Override
    public void onStartup(ServletContext servletContext) throws ServletException {
        // Get the names of all currently registered filters
        java.util.Collection<? extends FilterRegistration> filterRegistrations = servletContext.getFilterRegistrations().values();

        System.out.println("\n***********Currently registered filters:****\n");
        for (FilterRegistration filterRegistration : filterRegistrations) 
            System.out.println("  " + filterRegistration.getName() +    ", Class: " + filterRegistration.getClassName());
        
        /* Output was:
         ***********Currently registered filters:****

				  requestContextFilter, Class: org.springframework.boot.web.servlet.filter.OrderedRequestContextFilter
				  jwtAuthenticationFilter, Class: com.cybage.config.JwtAuthenticationFilter
				  characterEncodingFilter, Class: org.springframework.boot.web.servlet.filter.OrderedCharacterEncodingFilter
				  springSecurityFilterChain, Class: org.springframework.boot.web.servlet.DelegatingFilterProxyRegistrationBean$1
				  formContentFilter, Class: org.springframework.boot.web.servlet.filter.OrderedFormContentFilter
         */

        // Example of registering a new filter (if needed -  this is just an example)
        //  FilterRegistrationBean<MyFilter> registration = new FilterRegistrationBean<>();
        //  registration.setFilter(new MyFilter());
        //  registration.addUrlPatterns("/*");  // Apply to all URLs
        //  registration.setName("MyFilter");
        //  registration.setOrder(1); // Set the order of execution (optional)
        //  registration.setDispatcherTypes(EnumSet.of(DispatcherType.REQUEST, DispatcherType.FORWARD)); //when the filter should be applied
        //  registration.setEnabled(true);
        //  registration.

        //  servletContext.addFilter(registration.getName(), registration.getFilter()); //NO need to register again.
        // Log all filters registered at the end.
        filterRegistrations = servletContext.getFilterRegistrations().values();
        System.out.println("\n========================\n  All filters registered after custom registration:");
        for (FilterRegistration filterRegistration : filterRegistrations) 
            System.out.println("  " + filterRegistration.getName() + ", Class: " + filterRegistration.getClassName());
        
        /*		========================
		  	    All filters registered after custom registration:
					  requestContextFilter, Class: org.springframework.boot.web.servlet.filter.OrderedRequestContextFilter
					  jwtAuthenticationFilter, Class: com.cybage.config.JwtAuthenticationFilter
					  characterEncodingFilter, Class: org.springframework.boot.web.servlet.filter.OrderedCharacterEncodingFilter
					  springSecurityFilterChain, Class: org.springframework.boot.web.servlet.DelegatingFilterProxyRegistrationBean$1
					  formContentFilter, Class: org.springframework.boot.web.servlet.filter.OrderedFormContentFilter
		*/
    }

}
/*
Explanation:
1.  @Component: This annotation makes Spring manage this class as a bean, so it's automatically detected and used.
2.  ServletContextInitializer: This is a Spring Boot interface that allows you to work with the ServletContext directly during application startup.
3.  onStartup(): This method is called by Spring Boot when the ServletContext is ready.
4.  servletContext.getFilterRegistrations(): This is the core method.  It returns a map (as a Collection of values) of all FilterRegistration objects.  
	 Each FilterRegistration contains information about a registered filter.
5.  Logging the Filters: The code iterates through the FilterRegistration objects and prints out the name and class name of each filter.  This 
								  will show you all the filters that are registered in your application,	including those registered by Spring Boot itself,
								  and any that you've registered.
6.  Example of Registering a Filter (Commented Out): The commented-out code shows how you might register a custom filter.  This is not needed 
								to just *list* the filters, but it's included for completeness.  If you had a filter you wanted to add programmatically, this is 
								how you'd do it.  Key parts of this are:
								    * FilterRegistrationBean:  A spring boot class to register filters.
								    * addUrlPatterns:  The URL patterns to which the filter applies
								    * setOrder:  The order in which the filter is executed.
								    * setDispatcherTypes:  When the filter is applied (e.g., only on initial request, or also on forwards).
								    * setEnabled:  Whether the filter is enabled.
7. Log all filters: Finally, the code logs all the filters, including the ones registered by Spring and the custom ones.

*/
