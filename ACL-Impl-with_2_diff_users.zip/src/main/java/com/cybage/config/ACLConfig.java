package com.cybage.config;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.acls.AclPermissionEvaluator;
import org.springframework.security.acls.domain.*;
import org.springframework.security.acls.jdbc.BasicLookupStrategy;
import org.springframework.security.acls.jdbc.JdbcMutableAclService;
import org.springframework.security.acls.jdbc.LookupStrategy;
import org.springframework.security.acls.model.AclCache;
import org.springframework.security.acls.model.MutableAclService;
import org.springframework.security.acls.model.PermissionGrantingStrategy;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import javax.sql.DataSource;

/*
 Explanation:
@Configuration, @Profile("!test"): Marks this class as a Spring configuration class and excludes it from the "test" profile.
dataSource, cacheManager: These are injected dependencies. The DataSource is used to connect to the database, and the CacheManager is used for caching ACL information (to improve performance).
aclCache(): Configures the ACL cache. Caching ACL entries can significantly improve performance, especially in applications with many ACL-protected objects.
permissionGrantingStrategy(): Defines how permissions are granted. The ConsoleAuditLogger logs permission granting/denial events.
aclAuthorizationStrategy(): Defines which authorities are required to modify ACLs. In this case, only ROLE_ADMIN can modify ACLs.
lookupStrategy(): Defines how ACL entries are retrieved from the database. BasicLookupStrategy is a common implementation that uses JDBC.
aclService(): Configures the JdbcMutableAclService, which is the core class for managing ACLs in a database. It provides methods for creating, reading, updating, and deleting ACL entries.
setClassIdentityQuery and setSidIdentityQuery: These queries are database-specific and are crucial for retrieving the IDs of newly created ACL class and SID (Security Identity) entries. The @@IDENTITY syntax is for Microsoft SQL Server. For other databases (like MySQL, PostgreSQL, or H2), you'll need to use the appropriate syntax (e.g., LAST_INSERT_ID() for MySQL, currval(pg_get_serial_sequence(...)) for PostgreSQL, or CALL IDENTITY() for H2). The code has been updated to use generic @@IDENTITY.
permissionEvaluator(): Configures the AclPermissionEvaluator, which is used to evaluate ACL permissions in @PreAuthorize and @PostAuthorize annotations.

When is ACLConfig Used?
   This ACLConfig class is used by Spring Security when you've enabled ACL, "AND", are using @PreAuthorize or @PostAuthorize annotations to protect your methods.
   Spring Security will use the beans defined in this class (e.g., aclService, permissionEvaluator) to:
	   Retrieve ACL information from the database.
	   Evaluate whether a user has the required permissions to access a specific resource.
	   Enforce the ACL rules defined for your domain objects.
In summary, Spring Security uses this configuration to manage and enforce fine-grained access control based on ACLs.
 */

@Configuration
@Profile("!test")
public class ACLConfig {

    private final DataSource dataSource;
    private final CacheManager cacheManager;

    @Autowired
    public ACLConfig(DataSource dataSource, CacheManager cacheManager) {
        this.dataSource = dataSource;
        this.cacheManager = cacheManager;
    }

    @Bean
    public AclCache aclCache() {
        return new SpringCacheBasedAclCache(
                cacheManager.getCache("aclCache"),
                permissionGrantingStrategy(),
                aclAuthorizationStrategy()
        );
    }

    @Bean
    public PermissionGrantingStrategy permissionGrantingStrategy() {
        return new DefaultPermissionGrantingStrategy(new ConsoleAuditLogger());
    }

    @Bean
    public AclAuthorizationStrategy aclAuthorizationStrategy() {
        return new AclAuthorizationStrategyImpl(
                new SimpleGrantedAuthority("ROLE_ADMIN"),
                new SimpleGrantedAuthority("ROLE_ADMIN"),
                new SimpleGrantedAuthority("ROLE_ADMIN")
        );
    }

    @Bean
    public LookupStrategy lookupStrategy() {
        return new BasicLookupStrategy(
                dataSource,
                aclCache(),
                aclAuthorizationStrategy(),
                permissionGrantingStrategy()
        );
    }

    @Bean
    public MutableAclService aclService() {
        JdbcMutableAclService jdbcMutableAclService = new JdbcMutableAclService(
                dataSource,
                lookupStrategy(),
                aclCache()
        );
        
													        // Customize the queries if needed for specific database compatibility
													// Explicitly set the identity queries (should be default for H2 2.1.210)
													//   jdbcMutableAclService.setSidIdentityQuery("call identity()");
													//   jdbcMutableAclService.setClassIdentityQuery("call identity()");
													        // try this:
													//        jdbcMutableAclService.setSidIdentityQuery("SELECT MAX(ID) FROM ACL_CLASS");
													   // Or, try this:
													//        jdbcMutableAclService.setSidIdentityQuery("SELECT IDENTITY()");
													//        jdbcMutableAclService.setClassIdentityQuery("SELECT IDENTITY()");
													        // Or, try this:        
        jdbcMutableAclService.setSidIdentityQuery("SELECT MAX(ID) FROM ACL_SID");
        jdbcMutableAclService.setClassIdentityQuery("SELECT MAX(ID) FROM ACL_CLASS");

//        jdbcMutableAclService.setClassIdentityQuery("SELECT @@IDENTITY"); // This is MS SQLServer specific SQL syntax, will fail for other DB Vendors
//        jdbcMutableAclService.setSidIdentityQuery("SELECT @@IDENTITY"); // This is MS SQLServer specific SQL syntax, will fail for other DB Vendors
       
												        /*  												          
												          //   Some suggestion also was:  // Customize if needed
														        jdbcMutableAclService.setClassIdentityQuery("SELECT CURRVAL('acl_class_id_seq')");
														        jdbcMutableAclService.setSidIdentityQuery("SELECT CURRVAL('acl_sid_id_seq')");
														   
													    * */
        return jdbcMutableAclService;
    }

    @Bean
    public AclPermissionEvaluator permissionEvaluator() {
        return new AclPermissionEvaluator(aclService());
    }

    /*  AI suggestion: We ensure that these identity queries are set on the JdbcMutableAclService bean after it has been fully initialized, which might resolve 
     *  the issue of the configuration not being applied early enough. After making these changes, remember to clean and rebuild your project and then 
     *  restart your Spring Boot application. 
     *  Then, test if you can now create documents, without the "bad SQL grammar" error.*/
    @Bean
    public InitializingBean aclInitializer(MutableAclService aclService) {
        return () -> {
            ((JdbcMutableAclService) aclService).setSidIdentityQuery("SELECT MAX(ID) FROM ACL_SID");
            ((JdbcMutableAclService) aclService).setClassIdentityQuery("SELECT MAX(ID) FROM ACL_CLASS");
        };
    }
}

// AI suggested ACLConfig:
						//package com.cybage.config;
						//
						//import org.springframework.cache.ehcache.EhCacheFactoryBean;
						//import org.springframework.cache.ehcache.EhCacheManagerFactoryBean;
						//import org.springframework.context.annotation.Bean;
						//import org.springframework.context.annotation.Configuration;
						//import org.springframework.security.access.expression.method.DefaultMethodSecurityExpressionHandler;
						//import org.springframework.security.access.expression.method.MethodSecurityExpressionHandler;
						//import org.springframework.security.acls.AclPermissionEvaluator;
						//import org.springframework.security.acls.domain.*;
						//import org.springframework.security.acls.jdbc.BasicLookupStrategy;
						//import org.springframework.security.acls.jdbc.JdbcMutableAclService;
						//import org.springframework.security.acls.jdbc.LookupStrategy;
						//import org.springframework.security.acls.model.PermissionGrantingStrategy;
						//import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
						//import org.springframework.security.core.authority.SimpleGrantedAuthority;
						//
						//import javax.sql.DataSource;
						//import java.util.Objects;
						//
						//@Configuration
						//@EnableMethodSecurity
						//public class ACLConfig {
						//
						//    private final DataSource dataSource;
						//
						//    public ACLConfig(DataSource dataSource) {
						//        this.dataSource = dataSource;
						//    }
						//
						//    @Bean
						//    public EhCacheManagerFactoryBean aclCacheManager() {
						//        return new EhCacheManagerFactoryBean();
						//    }
						//
						//    @Bean
						//    public EhCacheFactoryBean aclEhCacheFactoryBean() {
						//        EhCacheFactoryBean ehCacheFactoryBean = new EhCacheFactoryBean();
						//        ehCacheFactoryBean.setCacheManager(Objects.requireNonNull(aclCacheManager().getObject()));
						//        ehCacheFactoryBean.setCacheName("aclCache");
						//        return ehCacheFactoryBean;
						//    }
						//
						//    @Bean
						//    public PermissionGrantingStrategy permissionGrantingStrategy() {
						//        return new DefaultPermissionGrantingStrategy(new ConsoleAuditLogger());
						//    }
						//
						//    @Bean
						//    public AclAuthorizationStrategy aclAuthorizationStrategy() {
						//        return new AclAuthorizationStrategyImpl(
						//                new SimpleGrantedAuthority("ROLE_ADMIN"),
						//                new SimpleGrantedAuthority("ROLE_ADMIN"),
						//                new SimpleGrantedAuthority("ROLE_ADMIN")
						//        );
						//    }
						//
						//    @Bean
						//    public EhCacheBasedAclCache aclCache() {
						//        return new EhCacheBasedAclCache(
						//                Objects.requireNonNull(aclEhCacheFactoryBean().getObject()),
						//                permissionGrantingStrategy(),
						//                aclAuthorizationStrategy()
						//        );
						//    }
						//
						//    @Bean
						//    public LookupStrategy lookupStrategy() {
						//        return new BasicLookupStrategy(
						//                dataSource,
						//                aclCache(),
						//                aclAuthorizationStrategy(),
						//                new ConsoleAuditLogger()
						//        );
						//    }
						//
						//    @Bean
						//    public JdbcMutableAclService aclService() {
						//        JdbcMutableAclService jdbcMutableAclService = new JdbcMutableAclService(
						//                dataSource,
						//                lookupStrategy(),
						//                aclCache()
						//        );
						//        
						//        // Use PostgreSQL-specific SQL
						//        jdbcMutableAclService.setClassIdentityQuery("SELECT currval(pg_get_serial_sequence('acl_class', 'id'))");
						//        jdbcMutableAclService.setSidIdentityQuery("SELECT currval(pg_get_serial_sequence('acl_sid', 'id'))");
						//        
						//        return jdbcMutableAclService;
						//    }
						//
						//    @Bean
						//    public MethodSecurityExpressionHandler defaultMethodSecurityExpressionHandler() {
						//        DefaultMethodSecurityExpressionHandler expressionHandler = new DefaultMethodSecurityExpressionHandler();
						//        AclPermissionEvaluator permissionEvaluator = new AclPermissionEvaluator(aclService());
						//        expressionHandler.setPermissionEvaluator(permissionEvaluator);
						//        return expressionHandler;
						//    }
						//}
