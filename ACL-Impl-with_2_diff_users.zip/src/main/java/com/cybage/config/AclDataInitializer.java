//package com.cybage.config;
//
//import org.springframework.boot.context.event.ApplicationReadyEvent;
//import org.springframework.context.event.EventListener;
//import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.stereotype.Component;
//
///*
// Okay, I understand the error you're encountering. It seems like Spring Boot is trying to insert data into the acl_class table before the table itself has been created. This often happens due to the order in which Spring Boot initializes different parts of the application.
//
//Here's a breakdown of the problem and how to fix it:
//
//The Problem
//
//Initialization Order: Spring Boot has a specific order in which it initializes components. It appears that, in your case, data.sql (which contains the INSERT statement) is being executed before Spring Security's ACL schema initialization (which creates the acl_class table).
//data.sql vs. schema.sql:
//schema.sql is meant for creating the database schema (tables, constraints, etc.).
//data.sql is meant for inserting initial data into the tables.
//The Error: The error message "Failed to execute SQL script statement #1 of class path resource [data.sql]: INSERT INTO acl_class..." indicates that Spring Boot is trying to execute an INSERT statement in data.sql for the acl_class table, but that table doesn't exist yet because it hasn't been created by Spring Security.
//The Solution:---------------------------
//  The key is to ensure that the ACL tables are created before any data is inserted into them. 
//   Here are the steps to resolve this:
//  a. Remove ACL Data from data.sql: 
//  b. Move any INSERT statements related to the ACL tables (like the one for acl_class) from data.sql to a different location.  data.sql should only contain 
//  data for your application-specific tables (users, document, and any other tables besides the ACL tables).
//  c. Let Spring Security Initialize the Schema: Since you've set spring.security.acl.jdbc.initialize-schema=true, Spring Security will create the ACL tables.  
//     You don't need to do anything else to trigger this, but make sure the property is correctly set.
//
//Create a Separate Initialization for ACL Data (If Needed):
//If you need to insert initial data into the ACL tables (which is less common, but sometimes necessary), you have a couple of options:
//@EventListener: The most robust way is to use a Spring @EventListener to execute your ACL data insertion after Spring Security has initialized the schema.
//A Separate SQL File: You could create a separate SQL file (e.g., acl_data.sql) and use a @Bean to run it after the ACL schema is initialized.
//   Example using @EventListener (Recommended):
//    --------------------------------------------------------------
//    Here's how to use an @EventListener to insert ACL data after the schema is created:
//
//@Component:        Marks this class as a Spring component, making it available for dependency injection.
//	      JdbcTemplate: Injects Spring's JdbcTemplate, which is a convenient way to execute SQL queries.
//@EventListener(ApplicationReadyEvent.class):   This annotation tells Spring to call the initializeAclData() method after the ApplicationReadyEvent is published
//. This event is published very late in the application startup process, "after the database schema has been initialized".
//initializeAclData(): This method contains the SQL INSERT statements for your ACL data. It's safe to execute them here because the ACL tables are guaranteed to exist.
// * */
//@Component
//public class AclDataInitializer {
//
//    private final JdbcTemplate jdbcTemplate;
//
//    public AclDataInitializer(JdbcTemplate jdbcTemplate) {
//        this.jdbcTemplate = jdbcTemplate;
//    }
//
//    @EventListener(ApplicationReadyEvent.class)
//    public void initializeAclData() {
//        // This method will be called after the application is ready, which means Spring Security has initialized the ACL schema.
//
//        // Now you can safely insert data into the ACL tables.
//        try {
//            jdbcTemplate.update("INSERT INTO acl_class (id, class) VALUES (1, 'com.cybage.domain.Document')");
//            // Add other INSERT statements for ACL data here...
//        } catch (Exception e) {
//            // Handle any errors (e.g., log them)
//            System.err.println("Error initializing ACL data: " + e.getMessage());
//        }
//    }
//}

/*
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
public class DatabaseInitializer {

    private final JdbcTemplate jdbcTemplate;

    public DatabaseInitializer(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @EventListener(ApplicationReadyEvent.class)
    @Transactional
    public void initializeDatabase() {
        // Create tables
        jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS users (id BIGINT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(255) NOT NULL UNIQUE, password VARCHAR(255) NOT NULL, email VARCHAR(255) NOT NULL, first_name VARCHAR(255), last_name VARCHAR(255), role VARCHAR(255) NOT NULL, created_at DATETIME, updated_at DATETIME, last_login DATETIME, account_locked BOOLEAN DEFAULT FALSE, account_expired BOOLEAN DEFAULT FALSE, credentials_expired BOOLEAN DEFAULT FALSE, account_enabled BOOLEAN DEFAULT TRUE)");
        jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS document (id INT PRIMARY KEY, title VARCHAR(255))");

        // Create ACL tables (if needed)
        jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS acl_class (id BIGINT NOT NULL PRIMARY KEY, class_name VARCHAR(100) NOT NULL, UNIQUE(class_name))");
        jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS acl_sid (id BIGINT NOT NULL PRIMARY KEY, principal BOOLEAN NOT NULL, sid VARCHAR(100) NOT NULL, UNIQUE(sid,principal))");
        jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS acl_object_identity (id BIGINT NOT NULL PRIMARY KEY, object_id_class BIGINT NOT NULL, object_id_identity BIGINT NOT NULL, parent_object BIGINT, owner_sid BIGINT, entries_inheriting BOOLEAN NOT NULL, UNIQUE(object_id_class,object_id_identity))");
        jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS acl_entry (id BIGINT NOT NULL PRIMARY KEY, acl_object_identity BIGINT NOT NULL, ace_order INTEGER NOT NULL, sid BIGINT NOT NULL, mask INTEGER NOT NULL, granting BOOLEAN NOT NULL, audit_success BOOLEAN NOT NULL, audit_failure BOOLEAN NOT NULL, UNIQUE(acl_object_identity,ace_order))");

        jdbcTemplate.execute("ALTER TABLE acl_object_identity ADD FOREIGN KEY (object_id_class) REFERENCES acl_class(id)");
        jdbcTemplate.execute("ALTER TABLE acl_object_identity ADD FOREIGN KEY (owner_sid) REFERENCES acl_sid(id)");
        jdbcTemplate.execute("ALTER TABLE acl_entry ADD FOREIGN KEY (acl_object_identity) REFERENCES acl_object_identity(id)");
        jdbcTemplate.execute("ALTER TABLE acl_entry ADD FOREIGN KEY (sid) REFERENCES acl_sid(id)");
        jdbcTemplate.execute("ALTER TABLE acl_object_identity ADD FOREIGN KEY (parent_object) REFERENCES acl_object_identity(id)");

        // Insert initial data
        jdbcTemplate.update("INSERT INTO users (username, password, email, role, created_at, updated_at) VALUES ('john.doe', '$2a$10$exampleHashedPassword', 'john.doe@example.com', 'ROLE_USER', NOW(), NOW())");
        jdbcTemplate.update("INSERT INTO document (id, title) VALUES (1, 'Document 1')");

        // Insert ACL data (if needed)
        // jdbcTemplate.update("INSERT INTO acl_class (id, class_name) VALUES (1, 'com.cybage.domain.Document')");
    }
}
  */
 