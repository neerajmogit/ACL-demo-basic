//package com.cybage.config;
//
//import org.ehcache.config.builders.CacheConfigurationBuilder;
//import org.ehcache.config.builders.ResourcePoolsBuilder;
//import org.ehcache.jsr107.Eh107Configuration;
//import org.springframework.cache.annotation.EnableCaching;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//import javax.cache.CacheManager;
//import javax.cache.Caching;
//import javax.cache.spi.CachingProvider;
//import java.net.URI;
//import java.net.URL;
//
//@Configuration
//@EnableCaching
//public class XXCacheConfig {
//
//    @Bean
//    public CacheManager jCacheManager() throws Exception {
//        CachingProvider provider = Caching.getCachingProvider();
//        URL url = getClass().getResource("/ehcache.xml");
//        CacheManager cacheManager = provider.getCacheManager(
//                URI.create(url.toURI().toString()),
//                getClass().getClassLoader());
//        
//        // Ensure the aclCache is created if not defined in XML
//        if (cacheManager.getCache("aclCache") == null) {
//            javax.cache.configuration.Configuration<Object, Object> configuration = 
//                Eh107Configuration.fromEhcacheCacheConfiguration(
//                    CacheConfigurationBuilder.newCacheConfigurationBuilder(
//                        Object.class, Object.class,
//                        ResourcePoolsBuilder.heap(1000)
//                    )
//                );
//            cacheManager.createCache("aclCache", configuration);
//        }
//        
//        return cacheManager;
//    }
//}
//
//
//
//
//
//
//
//
//
//// AI suggested CacheConfig
//				//package com.cybage.config;
//				//
//				//import org.springframework.cache.annotation.EnableCaching;
//				//import org.springframework.context.annotation.Configuration;
//				//
//				//@Configuration
//				//@EnableCaching
//				//public class CacheConfig {
//				//    // Spring Boot will auto-configure the cache based on the dependencies
//				//    // and properties in application.properties
//				//}
