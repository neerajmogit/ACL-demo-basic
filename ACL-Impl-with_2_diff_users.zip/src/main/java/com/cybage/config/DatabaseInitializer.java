//--------------------------------------------------------------------------
//AI suggested Code STARTs.   
//--------------------------------------------------------------------------      

package com.cybage.config;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Lazy;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.acls.model.MutableAclService;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.acls.domain.ObjectIdentityImpl;
import org.springframework.security.acls.model.ObjectIdentity;
import org.springframework.security.acls.model.Sid;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.acls.domain.PrincipalSid;
import org.springframework.security.acls.model.MutableAcl;
import org.springframework.security.acls.model.NotFoundException;
import org.springframework.security.acls.model.AlreadyExistsException;
import org.springframework.security.acls.model.Permission;
import org.springframework.security.acls.domain.BasePermission;
import com.cybage.repository.UserRepository;
import com.cybage.service.AclService;
import com.cybage.service.UserService;

@Component
public class DatabaseInitializer implements ApplicationRunner {

	private final UserRepository userRepository;
    private AclService aclService;
    private final MutableAclService mutableAclService;
    private final JdbcTemplate jdbcTemplate;
    private final PasswordEncoder passwordEncoder;
    private static final String USER_ADMIN ="userAdmin",   USER_READER1="userReader1",
    									   ADMIN_PASS ="adminPass1",USER_PASS ="userPass1",
    										ROLE_ADMIN="ADMIN", ROLE_READ ="READ"; 
    
    @Autowired
    public DatabaseInitializer(UserRepository userRepository, PasswordEncoder passwordEncoder, 
    										MutableAclService mutableAclService, JdbcTemplate jdbcTemplate) { // Added JdbcTemplate
    	this.userRepository = userRepository;
		this.jdbcTemplate = jdbcTemplate/*new JdbcTemplate()*/;
        this.passwordEncoder = passwordEncoder;
        this.mutableAclService = mutableAclService; 
    }

    
    @Override
    @Transactional
    public void run(ApplicationArguments args) throws Exception {
        int _i=0;
        String temp= "\n+["+_i++ +"]              ^^^^^^^^^^^^^^= = = = = = = = =^^^^^^^^^^^^==============    ";
        // Create initial users directly using userRepository
        com.cybage.domain.User adminUser;
        Optional<com.cybage.domain.User> optionalAdminUser = userRepository.findByUsername(USER_ADMIN);
        System.out.println(temp+"  run(App ..)  ");
        if (optionalAdminUser.isPresent()) { System.out.println(temp+"  if ...run(App ..)  ");
            adminUser = optionalAdminUser.get();
        } else { System.out.println(temp+"  else 1 run(App ..)  ");
            adminUser = new com.cybage.domain.User();
            adminUser.setUsername(USER_ADMIN);
            adminUser.setPassword(passwordEncoder.encode(ADMIN_PASS));
            adminUser.setEmail("userAdmin@cybage.com");
            adminUser.setFirstName("AdminFn");
            adminUser.setLastName("AdminLn");
            adminUser.setRole(ROLE_ADMIN); System.out.println(temp+"  else 2 run(App ..)  ");
            userRepository.save(adminUser); System.out.println(temp+"  else 3 run(App ..)  after userRep.save");
        }

        com.cybage.domain.User reader1User;
        Optional<com.cybage.domain.User> optionalReader1User = userRepository.findByUsername(USER_READER1);
        if (optionalReader1User.isPresent()) { System.out.println(temp+"  if readUsr1 run(App ..)  ");
            reader1User = optionalReader1User.get();
        } else {  System.out.println(temp+"  els readUsr1 run(App ..)  ");
            reader1User = new com.cybage.domain.User();
            reader1User.setUsername(USER_READER1);
            reader1User.setPassword(passwordEncoder.encode(USER_PASS));
            reader1User.setEmail("userReader1@cybage.com");
            reader1User.setFirstName("User1Fn");
            reader1User.setLastName("User2Ln");
            reader1User.setRole(ROLE_READ); System.out.println(temp+"  els readUsr1 before .save run(App ..)  ");
            userRepository.save(reader1User); System.out.println(temp+"  els readUsr1 after .save run(App ..)  ");
        }
        // Set up initial ACL (using aclService)
        // Check if the ACL entry already exists.  A simple check is to see if the document exists.
        final int documentId = 1; // Assuming you are setting ACL for document with ID 1
        String checkSql = "SELECT count(*) FROM ACL_OBJECT_IDENTITY WHERE OBJECT_ID_IDENTITY = ? AND OBJECT_ID_CLASS = (SELECT ID FROM ACL_CLASS WHERE CLASS = ?)";
        int count = jdbcTemplate.queryForObject(checkSql, Integer.class, documentId, com.cybage.domain.Document.class.getName());
        System.out.println(temp+"  jdbcTemplate executed run(App ..)  count= "+count);
        if (count == 0) { // Only set up ACL if it doesn't exist
	        // 1. Create an Authentication object
	        UserDetails userDetails = org.springframework.security.core.userdetails.User.withUsername(adminUser.getUsername())
	                .password(adminUser.getPassword()) // Use the encoded password
	                .roles(adminUser.getRole())
	                .build();
	        UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(
	                userDetails, userDetails.getPassword(), userDetails.getAuthorities());
	
	        // 2. Set the SecurityContext
	        SecurityContextHolder.getContext().setAuthentication(authentication);
	        try { System.out.println(temp+"  try block run(App ..)  ");
	            // Initialize aclService *explicitly*
	            this.aclService = new AclService(mutableAclService); System.out.println(temp+"  try block acl obj run(App ..)  ");
	            aclService.grantReadPermission(1L, USER_READER1); System.out.println(temp+"  try block acl.grantPerm() run(App ..)  ");
	        }catch(Exception any) {
	        	System.out.println(temp+"  XCPN: block acl obj run(App ..) \n"+any) ;
	        } finally {  System.out.println(temp+"  finally block acl obj run(App ..)  ");
	            // 3. Clear the SecurityContext
	            SecurityContextHolder.getContext().setAuthentication(null);
	        }
      }  
    }
 } 
//--------------------------------------------------------------------------
//AI suggested Code ENDs.   
//--------------------------------------------------------------------------      
      
//--------------------------------------------------------------------------
//      The working piece.   
//--------------------------------------------------------------------------      
//package com.cybage.config;
//
//import org.springframework.boot.context.event.ApplicationReadyEvent;
//import org.springframework.context.event.EventListener;
//import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.stereotype.Component;
//import org.springframework.security.acls.model.MutableAclService;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.transaction.annotation.Transactional;
//
//import com.cybage.service.AclService;
//
//@Component
//public class DatabaseInitializer {
//
//    private final JdbcTemplate jdbcTemplate;
//    private final BCryptPasswordEncoder passwordEncoder; // Inject BCryptPasswordEncoder
//    
//	public DatabaseInitializer(JdbcTemplate jdbcTemplate){
//        this.jdbcTemplate = jdbcTemplate;
//		this.passwordEncoder = new BCryptPasswordEncoder();
//    }
//        
///*  H2 console SQLs:
//			  SELECT TABLE_NAME, COLUMN_NAME, IS_IDENTITY
//				FROM INFORMATION_SCHEMA.COLUMNS
//					WHERE TABLE_NAME = 'DOCUMENTS' AND COLUMN_NAME = 'ID';
//			  Gives IS_IDENTITY = YES
//  
// */
//    @EventListener(ApplicationReadyEvent.class)
//    @Transactional
//    public void initializeDatabase() {
//																																															        // Create tables
//																																															//        jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS users (id BIGINT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(255) NOT NULL UNIQUE, password VARCHAR(255) NOT NULL, email VARCHAR(255) NOT NULL, first_name VARCHAR(255), last_name VARCHAR(255), role VARCHAR(255) NOT NULL, created_at DATETIME, updated_at DATETIME, last_login DATETIME, account_locked BOOLEAN DEFAULT FALSE, account_expired BOOLEAN DEFAULT FALSE, credentials_expired BOOLEAN DEFAULT FALSE, account_enabled BOOLEAN DEFAULT TRUE)");
//																																															//        jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS documents (\r\n"
//																																															//        		+ "   id INT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,\r\n"
//																																															//        		+ "    content VARCHAR(255) NOT NULL,\r\n"
//																																															//        		+ "    name VARCHAR(255) NOT NULL,\r\n"
//																																															//        		+ "    owner VARCHAR(255),\r\n"
//																																															//        		+ "    created_at DATETIME,\r\n"
//																																															//        		+ "    updated_at DATETIME\r\n"
//																																															//        		+ ");");
//																																															
//																																															        // Create ACL tables (if needed)
//																																															//        jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS acl_class (id BIGINT NOT NULL PRIMARY KEY, class VARCHAR(100) NOT NULL, UNIQUE(class))");
//																																															//        jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS acl_sid (id BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY, principal BOOLEAN NOT NULL, sid VARCHAR(100) NOT NULL, UNIQUE(sid,principal))");
//																																															//        jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS acl_object_identity (id BIGINT NOT NULL PRIMARY KEY, object_id_class BIGINT NOT NULL, object_id_identity BIGINT NOT NULL, parent_object BIGINT, owner_sid BIGINT, entries_inheriting BOOLEAN NOT NULL, UNIQUE(object_id_class,object_id_identity))");
//																																															//        jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS acl_entry (id BIGINT NOT NULL PRIMARY KEY, acl_object_identity BIGINT NOT NULL, ace_order INTEGER NOT NULL, sid BIGINT NOT NULL, mask INTEGER NOT NULL, granting BOOLEAN NOT NULL, audit_success BOOLEAN NOT NULL, audit_failure BOOLEAN NOT NULL, UNIQUE(acl_object_identity,ace_order))");
//																																															//
//																																															//        jdbcTemplate.execute("ALTER TABLE acl_object_identity ADD FOREIGN KEY (object_id_class) REFERENCES acl_class(id)");
//																																															//        jdbcTemplate.execute("ALTER TABLE acl_object_identity ADD FOREIGN KEY (owner_sid) REFERENCES acl_sid(id)");
//																																															//        jdbcTemplate.execute("ALTER TABLE acl_entry ADD FOREIGN KEY (acl_object_identity) REFERENCES acl_object_identity(id)");
//																																															//        jdbcTemplate.execute("ALTER TABLE acl_entry ADD FOREIGN KEY (sid) REFERENCES acl_sid(id)");
//																																															//        jdbcTemplate.execute("ALTER TABLE acl_object_identity ADD FOREIGN KEY (parent_object) REFERENCES acl_object_identity(id)");
//																																															
//																																															 // Insert initial data
//																																															//        jdbcTemplate.update("INSERT INTO users (username, password, email, role, created_at, updated_at) VALUES ('john.doe', '$2a$10$exampleHashedPassword', 'john.doe@example.com', 'ROLE_USER', NOW(), NOW())");
//																																															//        jdbcTemplate.update("INSERT INTO users (username, password, enabled) VALUES ('john', 'pass', true)");
//        
//        // Hash the password using BCrypt
//        String hashedPassword = passwordEncoder.encode("pass");
//        
//        jdbcTemplate.update(
//        	    "INSERT INTO users (username, password, email, first_name, last_name, role, created_at, updated_at, last_login, account_locked, account_expired, credentials_expired, account_enabled) " +
//        	    "VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW(), NOW(), ?, ?, ?, ?)",
//        	    "user1",
//        	    hashedPassword, //  IMPORTANT: Should always be a real hashed password.
//        	    "user1@example.com",
//        	    "userFn",
//        	    "userLn",
//        	    "ROLE_USER",
//        	    false, // account_locked
//        	    false, // account_expired
//        	    false, // credentials_expired
//        	    true    // account_enabled
//        	);
//    }
//}