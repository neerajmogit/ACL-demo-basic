package com.cybage.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception thrown when a user attempts to access a resource without proper authorization
 * 
   This UnauthorizedException class:

		Extends RuntimeException to make it an unchecked exception
		Is annotated with @ResponseStatus(HttpStatus.UNAUTHORIZED) to automatically map to HTTP 401 responses
		Includes constructors for creating the exception with a message and optionally a cause
		Provides a serialVersionUID for serialization compatibility
		The exception is used in the UserService class when authentication fails, such as when a user provides incorrect credentials. 
		When thrown, Spring will automatically convert it to an HTTP 401 Unauthorized response.

      Now the UserService class should be able to import and use this exception class without any issues.

 */
@ResponseStatus(HttpStatus.UNAUTHORIZED)
public class UnauthorizedException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    /**
     * Constructs a new unauthorized exception with the specified detail message.
     *
     * @param message the detail message
     */
    public UnauthorizedException(String message) {
        super(message);
    }

    /**
     * Constructs a new unauthorized exception with the specified detail message and cause.
     *
     * @param message the detail message
     * @param cause the cause of the exception
     */
    public UnauthorizedException(String message, Throwable cause) {
        super(message, cause);
    }
}
