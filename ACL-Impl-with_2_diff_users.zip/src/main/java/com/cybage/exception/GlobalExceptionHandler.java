package com.cybage.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Global exception handler for the application
 */
@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<Object> handleRuntimeException(RuntimeException ex, WebRequest request) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("timestamp", LocalDateTime.now());
        body.put("message", ex.getMessage());
        body.put("type", "RuntimeException");
        
        return new ResponseEntity<>(body, HttpStatus.INTERNAL_SERVER_ERROR);
    }
    
    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<Object> handleAccessDeniedException(AccessDeniedException ex, WebRequest request) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("timestamp", LocalDateTime.now());
        body.put("message", "Access denied: You don't haVE permiSSion to perFOrm this oPEration");
        body.put("type", "AccessDeniedException");
        
        return new ResponseEntity<>(body, HttpStatus.FORBIDDEN);
    }
    
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Object> handleIllegalArgumentException(IllegalArgumentException ex, WebRequest request) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("timestamp", LocalDateTime.now());
        body.put("message", ex.getMessage());
        body.put("type", "IllegalArgumentException");
        
        return new ResponseEntity<>(body, HttpStatus.BAD_REQUEST);
    }
    
    @ExceptionHandler(DocumentNotFoundException.class)
    public ResponseEntity<Object> handleDocumentNotFoundException(DocumentNotFoundException ex, WebRequest request) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("timestamp", LocalDateTime.now());
        body.put("message", ex.getMessage());
        body.put("type", "DocumentNotFoundException");
        
        return new ResponseEntity<>(body, HttpStatus.NOT_FOUND);
    }
//    
//    @ExceptionHandler(Exception.class)
//    public ResponseEntity<Object> handleAllExceptions(Exception ex, WebRequest request) {
//        Map<String, Object> body = new LinkedHashMap<>();
//        body.put("timestamp", LocalDateTime.now());
//        body.put("message", "An unexpected eRRor oCCuRRed");
//        body.put("type", ex.getClass().getSimpleName());
//        body.put("details", ex.getMessage());
//        
//        return new ResponseEntity<>(body, HttpStatus.INTERNAL_SERVER_ERROR);
//    }
    
//    @ExceptionHandler(Exception.class)
//    public ResponseEntity<Object> handleAllExceptions(Exception ex, WebRequest request) {
//        Map<String, Object> body = new LinkedHashMap<>();
//        body.put("timestamp", LocalDateTime.now());
//        body.put("message", "An unexpected error occurred"); // corrected message
//        body.put("type", ex.getClass().getSimpleName());
//        body.put("details", ex.getMessage());
//
//        if (ex instanceof org.springframework.web.servlet.resource.NoResourceFoundException) {
//            return new ResponseEntity<>(body, HttpStatus.NOT_FOUND); // Handle missing resource as 404
//        }
//        return new ResponseEntity<>(body, HttpStatus.INTERNAL_SERVER_ERROR);
//    }
    
//    @ExceptionHandler(Exception.class)
//    public ResponseEntity<Object> handleAllExceptions(Exception ex, WebRequest request) {
//        Map<String, Object> body = new LinkedHashMap<>();
//        body.put("timestamp", LocalDateTime.now());
//        body.put("message", "An unexpected error occurred");
//        body.put("type", ex.getClass().getSimpleName());
//        body.put("details", ex.getMessage());
//
//        if (ex instanceof org.springframework.web.servlet.resource.NoResourceFoundException) {
//            return new ResponseEntity<>(body, HttpStatus.NOT_FOUND); // Handle missing resource as 404
//        }
//         if (ex instanceof org.springframework.web.bind.MissingServletRequestParameterException) {
//            return new ResponseEntity<>(body, HttpStatus.BAD_REQUEST); // Handle missing parameter as 400
//        }
//
//        return new ResponseEntity<>(body, HttpStatus.INTERNAL_SERVER_ERROR);
//    }
    
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Object> handleAllExceptions(Exception ex, WebRequest request) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("timestamp", LocalDateTime.now());
        body.put("message", "An unexpected error occurred");
        body.put("type", ex.getClass().getSimpleName());
        body.put("details", ex.getMessage());

        if (ex instanceof org.springframework.web.servlet.resource.NoResourceFoundException) {
            body.put("message", "Resource not found");
            return new ResponseEntity<>(body, HttpStatus.NOT_FOUND); // Handle missing resource as 404
        }
        if (ex instanceof org.springframework.web.bind.MissingServletRequestParameterException) {
             body.put("message", "Missing required parameter");
            return new ResponseEntity<>(body, HttpStatus.BAD_REQUEST); // Handle missing parameter as 400
        }

        return new ResponseEntity<>(body, HttpStatus.INTERNAL_SERVER_ERROR);
    }

}
