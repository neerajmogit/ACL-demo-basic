//package com.cybage.Xsecurity;
//
//import com.cybage.domain.Document;
//import com.cybage.service.DocumentService;
////import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.core.Authentication;
//import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.stereotype.Component;
//
///**
// * Custom evaluator to check if the current user is the owner of a document
// */
//@Component("documentOwnershipEvaluator")
//public class DocumentOwnershipEvaluator {
//
//    private final DocumentService documentService;
//
////    @Autowired
//    public DocumentOwnershipEvaluator(DocumentService documentService) {
//        this.documentService = documentService;
//    }
//
//    /**
//     * Check if the current authenticated user is the owner of the document
//     */
//    public boolean isOwner(Long documentId) {
//        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
//        if (authentication == null) {
//            return false;
//        }
//
//        try {
//            Document document = documentService.findById(documentId);
//            return document.getOwner().equals(authentication.getName());
//        } catch (RuntimeException e) {
//            return false;
//        }
//    }
//}
