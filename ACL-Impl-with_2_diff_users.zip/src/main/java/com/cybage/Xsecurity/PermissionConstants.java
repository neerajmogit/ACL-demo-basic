//package com.cybage.Xsecurity;
//
///**
// * Constants for ACL permissions
// */
//public class PermissionConstants {
//    public static final int READ = 1;
//    public static final int WRITE = 2;
//    public static final int CREATE = 4;
//    public static final int DELETE = 8;
//    public static final int ADMINISTRATION = 16;
//    
//    private PermissionConstants() {
//        // Private constructor to prevent instantiation
//    }
//}
