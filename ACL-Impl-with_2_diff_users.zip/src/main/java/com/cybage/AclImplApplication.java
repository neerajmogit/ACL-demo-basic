package com.cybage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@SpringBootApplication
@ComponentScan(basePackages = { "com.cybage",
		 "com.cybage.service", "com.cybage.utils" })
@EnableJpaRepositories("com.cybage.repository")
@EnableCaching
@EnableMethodSecurity(prePostEnabled = true, securedEnabled = true)
public class AclImplApplication {
	private static final Logger logger = LoggerFactory.getLogger(AclImplApplication.class);
    public static void main(String[] args) {
        SpringApplication.run(AclImplApplication.class, args);
        logger.info("\n*************************************************************************************\nApplication started! (Explicit Check)"); 
    }
}
