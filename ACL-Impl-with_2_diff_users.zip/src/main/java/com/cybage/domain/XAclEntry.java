//package com.cybage.domain;
//
//import jakarta.persistence.Entity;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
//import jakarta.persistence.Id;
//import jakarta.persistence.Table;
//
//@Entity
//@Table(name = "acl_entries")
//public class XAclEntry {
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long id;
//
//    private Long documentId; // Foreign key to the Document
//
//    private String principal; // Identifier for the user or group
//
//    private int permission; // The permission code (e.g., 1=READ, 2=WRITE)
//
//    private boolean granting; // True if permission is granted, false if denied
//
//    // Default constructor
//    public XAclEntry() {
//    }
//
//    public XAclEntry(Long documentId, String principal, int permission, boolean granting) {
//        this.documentId = documentId;
//        this.principal = principal;
//        this.permission = permission;
//        this.granting = granting;
//    }
//
//    // Getters
//    public Long getId() {
//        return id;
//    }
//
//    public Long getDocumentId() {
//        return documentId;
//    }
//
//    public String getPrincipal() {
//        return principal;
//    }
//
//    public int getPermission() {
//        return permission;
//    }
//
//    public boolean isGranting() {
//        return granting;
//    }
//
//    // Setters
//    public void setId(Long id) {
//        this.id = id;
//    }
//
//    public void setDocumentId(Long documentId) {
//        this.documentId = documentId;
//    }
//
//    public void setPrincipal(String principal) {
//        this.principal = principal;
//    }
//
//    public void setPermission(int permission) {
//        this.permission = permission;
//    }
//
//    public void setGranting(boolean granting) {
//        this.granting = granting;
//    }
//
//    @Override
//    public String toString() {
//        return "AclEntry{" +
//               "id=" + id +
//               ", documentId=" + documentId +
//               ", principal='" + principal + '\'' +
//               ", permission=" + permission +
//               ", granting=" + granting +
//               '}';
//    }
//}