package com.cybage.service;

import org.springframework.web.servlet.handler.WebRequestHandlerInterceptorAdapter;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * For any class that needs to handle HttpRequest Object's metadata, we can possibly use this one.
 * Eg: Bearer Token
 */
public class BearerTokenInterceptor extends WebRequestHandlerInterceptorAdapter {

	  private BearerTokenWrapper tokenWrapper;

	  public BearerTokenInterceptor(BearerTokenWrapper tokenWrapper) {
		  //this.tokenWrapper = tokenWrapper;
		  super(tokenWrapper);
	  }

	  @Override
	  public boolean preHandle(HttpServletRequest request,
	          								  HttpServletResponse response, Object handler) throws Exception {
	    final String authorizationHeaderValue = request.getHeader("Authorization");
	    if (authorizationHeaderValue != null && authorizationHeaderValue.startsWith("Bearer")) {
	      String token = authorizationHeaderValue.substring(7, authorizationHeaderValue.length());
	      tokenWrapper.setToken(token);
	    }
	    
	    return true;
	  }
	}