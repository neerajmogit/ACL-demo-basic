package com.cybage.service;

import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cybage.domain.User;
import com.cybage.exception.UnauthorizedException;
import com.cybage.repository.UserRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Service for managing user operations
 */
@Service
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    /**
     * Find a user by username
     * 
     * @param username the username to search for
     * @return the user if found
     */
    public Optional<User> findByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    /**
     * Check if a username already exists
     * 
     * @param username the username to check
     * @return true if the username exists, false otherwise
     */
    public boolean existsByUsername(String username) {
        return userRepository.existsByUsername(username);
    }

    /**
     * Register a new user
     * 
     * @param user the user to register
     * @return the registered user
     */
    @Transactional
    public User registerUser(User user) {
        if (existsByUsername(user.getUsername())) {
            throw new IllegalArgumentException("Username already exists");
        }
        
        // Encode the password before saving
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        
        // Set default role if not specified
        if (user.getRole() == null || user.getRole().isEmpty()) {
            user.setRole("ROLE_USER");
        }
        
        return userRepository.save(user);
    }

    /**
     * Get all users
     * 
     * @return list of all users
     */
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Transactional
    public com.cybage.domain.User createUser(String username, String password, String email, String firstName, String lastName, String roleName) {
        if (userRepository.findByUsername(username).isPresent()) {
            return null;  //Change to Exception
        }

        //  Create a new com.cybage.domain.User object, adapting to your constructor.
        com.cybage.domain.User user = new com.cybage.domain.User(); //  Use your existing constructor
        user.setUsername(username);
        user.setPassword(password); //  Store encoded password
        user.setEmail(email);
        user.setFirstName(firstName);
        user.setLastName(lastName);
        //  Adapt the roleName to whatever your User class expects.
        user.setRole(roleName); //  Assuming your User class has a setRole(String role)
        user.setCreatedAt(LocalDateTime.now());
        user.setUpdatedAt(LocalDateTime.now());
        return userRepository.save(user);
    }
    
    /**
     * Update a user
     * 
     * @param user the user to update
     * @return the updated user
     */
    @Transactional
    public User updateUser(User user) {
        Optional<User> existingUser = userRepository.findById(user.getId());
        
        if (!existingUser.isPresent()) {
            throw new IllegalArgumentException("User not found");
        }
        
        User updatedUser = existingUser.get();
        
        // Update fields
        updatedUser.setEmail(user.getEmail());
        updatedUser.setFirstName(user.getFirstName());
        updatedUser.setLastName(user.getLastName());
        
        // Only update password if provided
        if (user.getPassword() != null && !user.getPassword().isEmpty()) {
            updatedUser.setPassword(passwordEncoder.encode(user.getPassword()));
        }
        
        return userRepository.save(updatedUser);
    }

    /**
     * Delete a user by ID
     * 
     * @param id the ID of the user to delete
     */
    @Transactional
    public void deleteUser(Long id) {
        if (!userRepository.existsById(id)) {
            throw new IllegalArgumentException("User not found");
        }
        userRepository.deleteById(id);
    }

    /**
     * Authenticate a user with username and password
     * 
     * @param username the username
     * @param password the raw password
     * @return the authenticated user
     * @throws UnauthorizedException if authentication fails
     */
    public User authenticateUser(String username, String password) {
        Optional<User> userOpt = userRepository.findByUsername(username);
        
        if (!userOpt.isPresent()) {
            throw new UnauthorizedException("Invalid username or password");
        }
        
        User user = userOpt.get();
        
        if (!passwordEncoder.matches(password, user.getPassword())) {
            throw new UnauthorizedException("Invalid username or password");
        }
        
        return user;
    }

    /**
     * Change a user's role
     * 
     * @param username the username
     * @param newRole the new role
     * @return the updated user
     */
    @Transactional
    public User changeUserRole(String username, String newRole) {
        Optional<User> userOpt = userRepository.findByUsername(username);
        
        if (!userOpt.isPresent()) {
            throw new IllegalArgumentException("User not found");
        }
        
        User user = userOpt.get();
        user.setRole(newRole);
        
        return userRepository.save(user);
    }

    /**
     * Get user count
     * 
     * @return the number of users
     */
    public long getUserCount() {
        return userRepository.count();
    }
}
