package com.cybage.config;

import org.mockito.Mockito;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.security.acls.model.MutableAclService;

import com.cybage.service.DocumentAclService;
import com.cybage.service.DocumentService;
import com.cybage.repository.XPermissionRepository;

@TestConfiguration
public class TestConfig {

    @Bean
    @Primary
    public DocumentService documentService() {
        return Mockito.mock(DocumentService.class);
    }

    @Bean
    @Primary
    public DocumentAclService aclService() {
        return Mockito.mock(DocumentAclService.class);
    }
    
    @Bean
    @Primary
    public XPermissionRepository permissionRepository() {
        return Mockito.mock(XPermissionRepository.class);
    }
    
    @Bean
    @Primary
    public MutableAclService mutableAclService() {
        return Mockito.mock(MutableAclService.class);
    }
}




//package com.cybage.config;
//
//import org.mockito.Mockito;
//import org.springframework.boot.test.context.TestConfiguration;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Primary;
//import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
//import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
//import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;
//import org.springframework.orm.jpa.JpaTransactionManager;
//import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
//import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
//import org.springframework.transaction.PlatformTransactionManager;
//import org.springframework.transaction.annotation.EnableTransactionManagement;
//
//import javax.sql.DataSource;
//import java.util.Properties;
//
//import com.cybage.service.AclService;
//import com.cybage.service.DocumentService;
//import com.cybage.repository.PermissionRepository;
//
//@TestConfiguration
//@EnableJpaRepositories(basePackages = "com.cybage.repository")
//@EnableTransactionManagement
//public class TestConfig {
//
//    // JPA Configuration
//    @Bean
//    public DataSource dataSource() {
//        return new EmbeddedDatabaseBuilder()
//                .setType(EmbeddedDatabaseType.H2)
//                .build();
//    }
//
//    @Bean
//    public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
//        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
//        vendorAdapter.setGenerateDdl(true);
//        
//        Properties jpaProperties = new Properties();
//        jpaProperties.setProperty("hibernate.hbm2ddl.auto", "create-drop");
//        jpaProperties.setProperty("hibernate.dialect", "org.hibernate.dialect.H2Dialect");
//        jpaProperties.setProperty("hibernate.show_sql", "true");
//        
//        LocalContainerEntityManagerFactoryBean factory = new LocalContainerEntityManagerFactoryBean();
//        factory.setJpaVendorAdapter(vendorAdapter);
//        factory.setPackagesToScan("com.cybage.model");
//        factory.setDataSource(dataSource());
//        factory.setJpaProperties(jpaProperties);
//        
//        return factory;
//    }
//
//    @Bean
//    public PlatformTransactionManager transactionManager() {
//        JpaTransactionManager txManager = new JpaTransactionManager();
//        txManager.setEntityManagerFactory(entityManagerFactory().getObject());
//        return txManager;
//    }
//
//    // Service Mocks
//    @Bean
//    @Primary
//    public DocumentService documentService() {
//        return Mockito.mock(DocumentService.class);
//    }
//
//    @Bean
//    @Primary
//    public AclService aclService() {
//        return Mockito.mock(AclService.class);
//    }
//    
//    // Repository Mocks (if needed)
//    @Bean
//    @Primary
//    public PermissionRepository permissionRepository() {
//        return Mockito.mock(PermissionRepository.class);
//    }
//}





//package com.cybage.config;
//
//import javax.sql.DataSource;
//
//import org.mockito.Mockito;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.context.annotation.Primary;
//import org.springframework.context.annotation.Profile;
//import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
//import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;
//
//import com.cybage.service.DocumentService;
//import com.cybage.service.AclService;
//import com.cybage.repository.PermissionRepository;	
//
//@Configuration
//@Profile("test")
//public class TestConfig {
//
//    @Bean
//    @Primary
//    public DocumentService documentService() {
//        return Mockito.mock(DocumentService.class);
//    }
//
//    @Bean
//    @Primary
//    public AclService aclService() {
//        return Mockito.mock(AclService.class);
//    }
// 
//    @Bean
//    @Primary
//    public PermissionRepository permissionRepository() {
//        return Mockito.mock(PermissionRepository.class);
//    }
//          
//    @Bean
//    @Primary
//    public DataSource dataSource() {
//        return new EmbeddedDatabaseBuilder()
//            .setType(EmbeddedDatabaseType.H2)
//            .addScript("classpath:Schema.sql") // Add this if you have ACL schema SQL
//            .build();
//    }
//
//}





//  package com.cybage.config;
//
////import org.springframework.boot.test.context.TestConfiguration;
////import org.springframework.boot.test.context.Configuration;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Profile;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.security.test.context.support.WithSecurityContextTestExecutionListener;
//import org.springframework.test.context.TestExecutionListener;
//
//							//@TestConfiguration
//@Configuration
//@Profile("!test") // ---> This ensures that this will not be executed for the SPring profile "test".
//public class TestConfig {
//    	
//    @Bean
//    public TestExecutionListener withSecurityContextTestExecutionListener() {
//        return new WithSecurityContextTestExecutionListener();
//    }
//    
//}





