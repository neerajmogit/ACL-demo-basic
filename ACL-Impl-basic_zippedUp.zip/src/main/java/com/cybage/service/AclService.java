package com.cybage.service;

import org.springframework.security.acls.model.MutableAclService;
import org.springframework.security.acls.domain.ObjectIdentityImpl;
import org.springframework.security.acls.model.ObjectIdentity;
import org.springframework.security.acls.model.Sid;
import org.springframework.security.acls.domain.PrincipalSid;
import org.springframework.security.acls.model.MutableAcl;
import org.springframework.security.acls.model.NotFoundException;
import org.springframework.security.acls.model.AlreadyExistsException;
import org.springframework.security.acls.model.Permission;
import org.springframework.security.acls.domain.BasePermission;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

// Dedicated service for ACL management (Standalone Class)
@Service
public class AclService {

    private final MutableAclService mutableAclService;

    public AclService(MutableAclService mutableAclService) {
        this.mutableAclService = mutableAclService;
    }

    @Transactional
    public void grantReadPermission(Long documentId, String username) throws NotFoundException,  AlreadyExistsException {
        ObjectIdentity oid = new ObjectIdentityImpl(com.cybage.domain.Document.class, documentId);
        MutableAcl acl;
        int _i=0;
        String temp= "\n+["+_i++ +"]**************==============************==============";
        System.out.println("grantReadPermission for ObjectIdentity: {}"+ oid);
        try {//System.out.println(temp+_i++ +"  grantReadPermission "+oid);
            System.out.println("Trying to read ACL for ObjectIdentity: {}"+ oid);
        	acl = (MutableAcl) mutableAclService.readAclById(oid);
        	System.out.println("ACL found for ObjectIdentity: {}"+ oid);
//            System.out.println(temp+_i++ +"grantReadPermission (null==acll) "+(null==acl));
        } catch (NotFoundException nfe) { 
        	System.out.println(temp+_i++ +"  grantReadPermission XCPN ???????????????????????????????????+\n\n"+nfe+"\n  ???????????????????????????????????");
            acl = mutableAclService.createAcl(oid);
        }
//        System.out.println(temp+_i++ +"  grantReadPermission ");
        Sid sid = new PrincipalSid(username);
        acl.insertAce(acl.getEntries().size(), BasePermission.READ, sid, true);
        mutableAclService.updateAcl(acl);
    }
    // Add other methods as needed (e.g., grantWritePermission, revokePermission)
}