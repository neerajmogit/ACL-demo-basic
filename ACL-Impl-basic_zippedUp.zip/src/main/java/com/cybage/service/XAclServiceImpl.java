//package com.cybage.service;
//
//import com.cybage.domain.XAclEntry;
//import com.cybage.domain.Document;
//import com.cybage.repository.XAclEntryRepository;
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
//
//import java.util.List;
//import java.util.stream.Collectors;
//
//@Service
//public class AclServiceImpl implements DocumentAclService {
//
//    private final XAclEntryRepository aclEntryRepository;
//
//    public AclServiceImpl(XAclEntryRepository aclEntryRepository) {
//        this.aclEntryRepository = aclEntryRepository;
//    }
//
//    @Transactional
//    public void grantPermission(Document document, String principal, int permission) {
//        XAclEntry aclEntry = new XAclEntry();
//        aclEntry.setDocumentId(document.getId());
//        aclEntry.setPrincipal(principal);
//        aclEntry.setPermission(permission);
//        aclEntry.setGranting(true);
//        aclEntryRepository.save(aclEntry);
//    }
//
//    @Transactional
//    public void revokePermission(Document document, String principal, int permission) {
//        XAclEntry aclEntryToDelete = aclEntryRepository.findByDocumentIdAndPrincipalAndPermission(document.getId(), principal, permission);
//        if (aclEntryToDelete != null) {
//            aclEntryRepository.delete(aclEntryToDelete);
//        }
//    }
//
//    @Transactional
//    public void denyPermission(Document document, String principal, int permission) {
//        XAclEntry aclEntry = new XAclEntry();
//        aclEntry.setDocumentId(document.getId());
//        aclEntry.setPrincipal(principal);
//        aclEntry.setPermission(permission);
//        aclEntry.setGranting(false);
//        aclEntryRepository.save(aclEntry);
//    }
//
//    
//    public boolean hasPermissionGranted(Document document, String principal, int permission) {
//        return isPermissionGranted(document,principal, permission);
//    }
//    
//    public boolean isPermissionGranted(Document document, String principal, int permission) {
//        XAclEntry aclEntry = aclEntryRepository.findByDocumentIdAndPrincipalAndPermission(document.getId(), principal, permission);
//        return aclEntry != null && aclEntry.isGranting();
//    }
//
//    public List<Integer> getPermissionsForDocument(Long documentId) {
//        List<XAclEntry> aclEntries = aclEntryRepository.findByDocumentId(documentId);
//        return aclEntries.stream()
//                .filter(XAclEntry::isGranting)
//                .map(XAclEntry::getPermission)
//                .distinct()
//                .collect(Collectors.toList());
//    }
//
//    public List<String> getPrincipalsWithPermission(Long documentId, int permission) {
//        List<XAclEntry> aclEntries = aclEntryRepository.findByDocumentIdAndPermission(documentId, permission);
//        return aclEntries.stream()
//                .filter(XAclEntry::isGranting)
//                .map(XAclEntry::getPrincipal)
//                .distinct()
//                .collect(Collectors.toList());
//    }
//
//    public List<XAclEntry> getAclEntriesForDocument(Long documentId) {
//        return aclEntryRepository.findByDocumentId(documentId);
//    }
//
//    public List<XAclEntry> getAclEntriesForPrincipal(String principal) {
//        return aclEntryRepository.findByPrincipal(principal);
//    }
//}



