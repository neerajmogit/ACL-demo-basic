//  // AI code suggest class STARTs
//package com.cybage.service;
//
//import com.cybage.domain.Document;
//import com.cybage.domain.User;
//import com.cybage.repository.DocumentRepository;
//import com.cybage.repository.UserRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.DependsOn;
//import org.springframework.security.access.prepost.PreAuthorize;
//import org.springframework.security.acls.domain.BasePermission;
//import org.springframework.security.acls.domain.ObjectIdentityImpl;
//import org.springframework.security.acls.domain.PrincipalSid;
//import org.springframework.security.acls.model.MutableAcl;
//import org.springframework.security.acls.model.MutableAclService;
//import org.springframework.security.acls.model.NotFoundException;
//import org.springframework.security.acls.model.ObjectIdentity;
//import org.springframework.security.acls.model.Sid;
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
//
//import org.springframework.security.acls.model.AlreadyExistsException; // Import this
//import org.springframework.security.acls.model.NotFoundException;
//
//import java.time.LocalDateTime;
//import java.util.List;
//import java.util.Optional;
//
//@Service
//@DependsOn("aclService")  //  <---  Initialize aclService first
//public class DocumentServiceImpl implements DocumentService {
//
//	private final DocumentRepository documentRepository;
//    private final AclService aclService;
//    private final UserRepository userRepository; // Added for user retrieval
//
//    @Autowired
//    public DocumentServiceImpl(DocumentRepository documentRepository, AclService aclService, UserRepository userRepository) { // Added UserRepository
//        this.documentRepository = documentRepository;
//        this.aclService = aclService;
//        this.userRepository = userRepository;
//    }
//
//    @Override
//    @Transactional // Added to ensure transaction
//    public Document createDocument( String content, String name) {
//      String username = org.springframework.security.core.context.SecurityContextHolder.getContext().getAuthentication().getName();
//      User user = userRepository.findByUsername(username).orElseThrow(() -> new RuntimeException("User not found"));
//
//    	System.out.println("Creating document with title: {}, content: {}, username: {}"+  content +" username: "+ name);
//	      Document document = new Document();
//	      document.setName(name);
//	      document.setContent(content);
//	      document.setOwner(username);
//	      document.setCreatedAt(LocalDateTime.now());
//	      document.setUpdatedAt(LocalDateTime.now());
//	      Document savedDocument = documentRepository.save(document);
//
//      // ... set other document properties ...
//        System.out.println("Document saved with ID: {}"+ savedDocument.getId());
//
//        // Grant read permission to the creator
//        try {
//            System.out.println("Calling aclService.grantReadPermission with documentId: {}, username: {}" + savedDocument.getId()+" username "+ username);
//            aclService.grantReadPermission(savedDocument.getId(), username);
//            System.out.println("aclService.grantReadPermission completed successfully.");
//        } catch (NotFoundException | AlreadyExistsException e) {
//        	System.out.println("Failed to grant ACL permissions: {}"+ e.getMessage()+" "+ e);
//            throw new RuntimeException("Failed to grant ACL permissions: " + e.getMessage(), e); // Wrap and rethrow
//        }
//        return savedDocument;
//    }
//
//    @Override
//    @PreAuthorize("hasRole('ROLE_ADMIN') or hasPermission(#document.id, 'com.cybage.domain.Document', 'write')")
//    public Document updateDocument(Document document) {       // ... your update logic ...
//        return documentRepository.save(document); //Added this to compile 
//        }
//
//    @Override
//    @PreAuthorize("hasRole('ROLE_ADMIN') or hasPermission(#id, 'com.cybage.domain.Document', 'delete')")
//    public void deleteDocument(Long id) { // ... your delete logic ...
//         documentRepository.deleteById(id); //Added this to compile
//    }
//
//    @Override
//    public List<Document> findByOwner(String owner) {        return documentRepository.findByOwner(owner);   }
//
//    @Override
//    @PreAuthorize("hasRole('ROLE_ADMIN') or hasPermission(#id, 'com.cybage.domain.Document', 'read')")
//    public Optional<Document> findById(Long id) {      return documentRepository.findById(id);   }
//
//    @Override
//    public List<Document> findAllDocuments() {       return documentRepository.findAll();   }
//
//}  // AI code suggest class ENDs

//--------------------------------------------------------------------------
//      The working piece. STARTs   
//--------------------------------------------------------------------------      
package com.cybage.service;

import com.cybage.domain.Document;
import com.cybage.domain.User;
import com.cybage.repository.DocumentRepository;
import com.cybage.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.acls.domain.BasePermission;
import org.springframework.security.acls.domain.ObjectIdentityImpl;
import org.springframework.security.acls.domain.PrincipalSid;
import org.springframework.security.acls.model.MutableAcl;
import org.springframework.security.acls.model.MutableAclService;
import org.springframework.security.acls.model.ObjectIdentity;
import org.springframework.security.acls.model.Sid;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class DocumentServiceImpl implements DocumentService {

    @Autowired
    private DocumentRepository documentRepository;
    @Autowired
    private MutableAclService aclService; // Inject MutableAclService
    @Autowired
    private UserRepository userRepository;
    
    private static final String ROLE_ADMIN = "ROLE_ADMIN";
    private static final String WRITE_PERMISSION = "write";
    private static final String DELETE_PERMISSION = "delete";
    private static final String READ_PERMISSION = "read";
    private static final String DOCUMENT_CLASS = "com.cybage.domain.Document"; 

    @Override
    @Transactional
    public Document createDocument(String name, String content) {
        String username = org.springframework.security.core.context.SecurityContextHolder.getContext().getAuthentication().getName();
        User user = userRepository.findByUsername(username).orElseThrow(() -> new RuntimeException("User not found"));

        Document document = new Document();
        document.setName(name);
        document.setContent(content);
        document.setOwner(username);
        document.setCreatedAt(LocalDateTime.now());
        document.setUpdatedAt(LocalDateTime.now());
        Document savedDocument = documentRepository.save(document);

        // Set up ACL for the new document
        ObjectIdentity oid = new ObjectIdentityImpl(Document.class, savedDocument.getId());
        MutableAcl acl = aclService.createAcl(oid);

        // Grant the owner all permissions
        Sid ownerSid = new PrincipalSid(username);
        acl.insertAce(acl.getEntries().size(), BasePermission.ADMINISTRATION, ownerSid, true);
        acl.insertAce(acl.getEntries().size(), BasePermission.READ, ownerSid, true);
        acl.insertAce(acl.getEntries().size(), BasePermission.WRITE, ownerSid, true);
        aclService.updateAcl(acl);

        return savedDocument;
    }

    @Override
    public List<Document> findByOwner(String owner) {
        return documentRepository.findByOwner(owner);
    }

    @Override
    @PreAuthorize("hasRole('" + ROLE_ADMIN + "') or hasPermission(#id, '" + DOCUMENT_CLASS + "', '" + READ_PERMISSION + "')")
       public Optional<Document> findById(Long id) {
        return documentRepository.findById(id);
    }

    @Override
    @PreAuthorize("hasRole('" + ROLE_ADMIN + "') or hasPermission(#id, '" + DOCUMENT_CLASS + "', '" + READ_PERMISSION + "')")
    public List<Document> findAllDocuments() {
        return documentRepository.findAll();
    }

    @Override
//  @PreAuthorize("hasRole('ROLE_ADMIN') or hasPermission(#document.id, 'com.cybage.domain.Document', 'write')")
    @PreAuthorize("hasRole('" + ROLE_ADMIN + "') or hasPermission(#document.id, '" + DOCUMENT_CLASS + "', '" + WRITE_PERMISSION + "')")
    public Document updateDocument(Document document) {
        Document existingDocument = documentRepository.findById(document.getId()).orElseThrow(() -> new RuntimeException("Document not found"));
        existingDocument.setName(document.getName());
        existingDocument.setContent(document.getContent());
        existingDocument.setUpdatedAt(LocalDateTime.now());
        return documentRepository.save(existingDocument);
    }

    @Override
//  @PreAuthorize("hasRole('ROLE_ADMIN') or hasPermission(#id, 'com.cybage.domain.Document', 'delete')")
    @PreAuthorize("hasRole('" + ROLE_ADMIN + "') or hasPermission(#id, '" + DOCUMENT_CLASS + "', '" + DELETE_PERMISSION + "')")
        public void deleteDocument(Long id) {
        documentRepository.deleteById(id);
        ObjectIdentity oid = new ObjectIdentityImpl(Document.class, id);
        aclService.deleteAcl(oid, true);
    }
}//--------------------------------------------------------------------------
 //      The working piece. ENDs   
 //--------------------------------------------------------------------------      



//    package com.cybage.service;
//
//    import com.cybage.domain.Document;
//    import com.cybage.domain.User; // Import your User entity
//    import com.cybage.repository.DocumentRepository;
//    import com.cybage.repository.UserRepository; // Import your UserRepository
//    import org.springframework.beans.factory.annotation.Autowired;
//    import org.springframework.security.access.prepost.PreAuthorize;
//    import org.springframework.security.acls.domain.BasePermission;
//    import org.springframework.security.acls.domain.ObjectIdentityImpl;
//    import org.springframework.security.acls.domain.PrincipalSid;
//    import org.springframework.security.acls.model.MutableAcl;
//    import org.springframework.security.acls.model.MutableAclService;
//    import org.springframework.security.acls.model.NotFoundException;
//    import org.springframework.security.acls.model.ObjectIdentity;
//    import org.springframework.security.acls.model.Sid;
//    import org.springframework.stereotype.Service;
//    import org.springframework.transaction.annotation.Transactional;
//    import java.time.LocalDateTime;
//    import java.util.List;
//    import java.util.Optional;
//
//    @Service
//    public class DocumentServiceImpl implements DocumentService {
//
//        @Autowired
//        private DocumentRepository documentRepository;
//        @Autowired
//        private MutableAclService aclService;
//        @Autowired
//        private UserRepository userRepository;
//
//
//        @Override
//        @Transactional
//        public Document createDocument(String name, String content) {
//            // Get the current user.
//            String username = org.springframework.security.core.context.SecurityContextHolder.getContext().getAuthentication().getName();
//            User user = userRepository.findByUsername(username).orElseThrow(() -> new RuntimeException("User not found"));
//
//            Document document = new Document();
//            document.setName(name);
//            document.setContent(content);
//            document.setOwner(username);
//            document.setCreatedAt(LocalDateTime.now());
//            document.setUpdatedAt(LocalDateTime.now());
//            Document savedDocument = documentRepository.save(document);
//
//            // Set up ACL for the new document
//            ObjectIdentity oid = new ObjectIdentityImpl(Document.class, savedDocument.getId());
////            MutableAcl acl = null;
////            try {     acl = (MutableAcl) aclService.readAclById(oid);
////            }  catch (NotFoundException nfe) {          acl = aclService.createAcl(oid);}
//
//            MutableAcl acl = aclService.createAcl(oid); // Use createAcl directly
//            
//            // Grant the owner all permissions
//            Sid ownerSid = new PrincipalSid(username);
//            acl.insertAce(acl.getEntries().size(), BasePermission.ADMINISTRATION, ownerSid, true);
//            acl.insertAce(acl.getEntries().size(), BasePermission.READ, ownerSid, true);
//            acl.insertAce(acl.getEntries().size(), BasePermission.WRITE, ownerSid, true);
//            aclService.updateAcl(acl);
//
//            return savedDocument;
//        }
//
//        @Override
//        public List<Document> findByOwner(String owner) {
//            return documentRepository.findByOwner(owner);
//        }
//
//        @Override
//        public Optional<Document> findById(Long id) {
//            return documentRepository.findById(id);
//        }
//
//        @Override
//        public List<Document> findAllDocuments() {
//            return documentRepository.findAll();
//        }
//
//        @Override
//        @PreAuthorize("hasRole('ROLE_ADMIN') or hasPermission(#document.id, 'com.cybage.domain.Document', 'write')")
//        public Document updateDocument(Document document) {
//            Document existingDocument = documentRepository.findById(document.getId()).orElseThrow(() -> new RuntimeException("Document not found"));
//            existingDocument.setName(document.getName());
//            existingDocument.setContent(document.getContent());
//            existingDocument.setUpdatedAt(LocalDateTime.now());
//            return documentRepository.save(existingDocument);
//        }
//
//
//
//        @Override
//        @PreAuthorize("hasRole('ROLE_ADMIN') or hasPermission(#id, 'com.cybage.domain.Document', 'delete')")
//        public void deleteDocument(Long id) {
//            documentRepository.deleteById(id);
//            ObjectIdentity oid = new ObjectIdentityImpl(Document.class, id);
//            aclService.deleteAcl(oid, true); // true: delete children's ACLs too
//        }
//    }
