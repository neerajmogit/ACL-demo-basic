package com.cybage.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cybage.domain.User;

/**
 * Repository interface for User entity operations.
 * 
 		The repository is annotated with @Repository to indicate that it's a Spring Data repository component. 
		The interface leverages Spring Data JPA's query derivation mechanism for simple queries,
		 and uses custom JPQL queries with the @Query annotation for more complex operations. 
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    
    /**
     * Find a user by username
     * 
     * @param username the username to search for
     * @return an Optional containing the user if found
     */
    Optional<User> findByUsername(String username);
    
    /**
     * Check if a user with the given username exists
     * 
     * @param username the username to check
     * @return true if the username exists, false otherwise
     */
    boolean existsByUsername(String username);
    
    /**
     * Find a user by email
     * 
     * @param email the email to search for
     * @return an Optional containing the user if found
     */
    Optional<User> findByEmail(String email);
    
    /**
     * Find users by role
     * 
     * @param role the role to search for
     * @return a list of users with the specified role
     */
    List<User> findByRole(String role);
    
    /**
     * Find users by enabled status
     * 
     * @param enabled the enabled status to search for
     * @return a list of users with the specified enabled status
     */
    List<User> findByEnabled(boolean enabled);
    
    /**
     * Find users by first name containing the given string (case insensitive)
     * 
     * @param firstName the first name pattern to search for
     * @return a list of matching users
     */
   
    @Query("SELECT u FROM User u WHERE LOWER(u.firstName) LIKE LOWER(CONCAT('%', :firstName, '%'))") // Changed to u.firstName
    
    List<User> findByFirstNameContainingIgnoreCase(@Param("firstName") String firstName);
    
    /**
     * Find users by last name containing the given string (case insensitive)
     * 
     * @param lastName the last name pattern to search for
     * @return a list of matching users
     */
    @Query("SELECT u FROM User u WHERE LOWER(u.lastName) LIKE LOWER(CONCAT('%', :lastName, '%'))")    
    List<User> findByLastNameContainingIgnoreCase(@Param("lastName") String lastName);
    
    /**
     * Update the last login timestamp for a user
     * 
     * @param username the username of the user to update
     */
    @Modifying // Important for UPDATE queries
    @Transactional // Add this for transactional operations
    @Query("UPDATE User u SET u.lastLogin = CURRENT_TIMESTAMP WHERE u.username = :username")
    void updateLastLogin(@Param("username") String username);
    
    /**
     * Lock or unlock a user account
     * 
     * @param username the username of the user to update
     * @param locked the new locked status
     */
    @Modifying
    @Query("UPDATE User u SET u.accountLocked = :locked WHERE u.username = :username")
    void updateAccountLocked(@Param("username") String username, @Param("locked") boolean locked);
    
    /**
     * Enable or disable a user account
     * 
     * @param username the username of the user to update
     * @param enabled the new enabled status
     */
    @Modifying
    @Query("UPDATE User u SET u.enabled = :enabled WHERE u.username = :username")
    void updateEnabled(@Param("username") String username, @Param("enabled") boolean enabled);
    
    /**
     * Count users by role
     * 
     * @param role the role to count
     * @return the number of users with the specified role
     */
    long countByRole(String role);
    
    /**
     * Find users created after a certain date
     * 
     * @param date the date to compare against
     * @return a list of users created after the specified date
     */
    @Query("SELECT u FROM User u WHERE u.createdAt >= :date")
    List<User> findByCreatedAtAfter(@Param("date") java.time.LocalDateTime date);
    
    /**
     * Search users by username, first name, or last name
     * 
     * @param searchTerm the search term
     * @return a list of matching users
     */
    @Query("SELECT u FROM User u WHERE " +
		            "LOWER(u.username) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
		            "LOWER(u.firstName) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
		            "LOWER(u.lastName) LIKE LOWER(CONCAT('%', :searchTerm, '%'))")
    List<User> searchUsers(@Param("searchTerm") String searchTerm);
}
