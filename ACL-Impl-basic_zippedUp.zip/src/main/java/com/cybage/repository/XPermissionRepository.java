//package com.cybage.repository;
//
//import java.util.List;
//import java.util.Optional;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Modifying;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.data.repository.query.Param;
//import org.springframework.stereotype.Repository;
//
//import com.cybage.domain.Document;
//import com.cybage.domain.XPermission;
//
///**
// * Repository interface for Permission entity operations
// */
//@Repository
//public interface XPermissionRepository extends JpaRepository<XPermission, Long> {
//    
//    /**
//     * Find a permission by document, username, and permission type
//     * 
//     * @param document the document
//     * @param username the username
//     * @param permission the permission type
//     * @return an Optional containing the permission if found
//     */
//    Optional<XPermission> findByDocumentAndUsernameAndPermission(Document document, String username, int permission);
//    
//    /**
//     * Find all permissions for a document
//     * 
//     * @param document the document
//     * @return a list of permissions for the document
//     */
//    List<XPermission> findByDocument(Document document);
//    
//    /**
//     * Find all permissions for a username
//     * 
//     * @param username the username
//     * @return a list of permissions for the username
//     */
//    List<XPermission> findByUsername(String username);
//    
//    /**
//     * Find all permissions of a specific type for a username
//     * 
//     * @param username the username
//     * @param permission the permission type
//     * @return a list of permissions
//     */
//    List<XPermission> findByUsernameAndPermission(String username, int permission);
//    
//    /**
//     * Delete all permissions for a document
//     * 
//     * @param document the document
//     */
//    void deleteByDocument(Document document);
//    
//    /**
//     * Delete a specific permission for a document and username
//     * 
//     * @param document the document
//     * @param username the username
//     * @param permission the permission type
//     */
//    void deleteByDocumentAndUsernameAndPermission(Document document, String username, int permission);
//    
//    /**
//     * Check if a permission exists
//     * 
//     * @param document the document
//     * @param username the username
//     * @param permission the permission type
//     * @return true if the permission exists, false otherwise
//     */
//    boolean existsByDocumentAndUsernameAndPermission(Document document, String username, int permission);
//    
//    /**
//     * Count permissions by document
//     * 
//     * @param document the document
//     * @return the number of permissions for the document
//     */
//    long countByDocument(Document document);
//    
//    /**
//     * Find documents that a user has a specific permission for
//     * 
//     * @param username the username
//     * @param permission the permission type
//     * @return a list of document IDs
//     */
//    @Query("SELECT p.document.id FROM Permission p WHERE p.username = :username AND p.permission = :permission")
//    List<Long> findDocumentIdsByUsernameAndPermission(@Param("username") String username, @Param("permission") int permission);
//    
//    /**
//     * Find usernames that have a specific permission for a document
//     * 
//     * @param document the document
//     * @param permission the permission type
//     * @return a list of usernames
//     */
//    @Query("SELECT p.username FROM Permission p WHERE p.document = :document AND p.permission = :permission")
//    List<String> findUsernamesByDocumentAndPermission(@Param("document") Document document, @Param("permission") int permission);
//
//}
