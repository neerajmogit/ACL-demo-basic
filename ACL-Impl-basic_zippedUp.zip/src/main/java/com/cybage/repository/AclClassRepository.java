//package com.cybage.repository;
//
//import java.util.Optional;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//
//import com.cybage.domain.AclClass;
//
///**
// * Repository interface for AclClass entity operations
// */
//@Repository
//public interface AclClassRepository extends JpaRepository<AclClass, Long> {
//    
//    /**
//     * Find an ACL class by its class name
//     * 
//     * @param className the class name
//     * @return an Optional containing the ACL class if found
//     */
//    Optional<AclClass> findByClassName(String className);
//}
