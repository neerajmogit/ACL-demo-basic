//package com.cybage.domain;
//
//import java.io.Serializable;
//import java.util.Objects;
//
//import jakarta.persistence.Column;
//import jakarta.persistence.Entity;
//import jakarta.persistence.FetchType;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
//import jakarta.persistence.Id;
//import jakarta.persistence.JoinColumn;
//import jakarta.persistence.ManyToOne;
//import jakarta.persistence.Table;
//import jakarta.persistence.UniqueConstraint;
//import jakarta.validation.constraints.NotBlank;
//import jakarta.validation.constraints.NotNull;
//
///**
// * Entity representing an access control permission
//
//This Permission class:
//
//	Represents an access control permission in the system
//	Maps to the "permissions" table in the database
//	Has a many-to-one relationship with the Document entity
//	Includes a unique constraint to prevent duplicate permissions
//	Uses permission integers (1 for READ, 2 for WRITE) to define access levels
//	Provides proper equals, hashCode, and toString methods
//	Includes appropriate constructors and getters/setters
//	The class uses Jakarta Persistence annotations for ORM mapping and includes validation constraints to 
//	ensure data integrity. 
//	
//	The <many-to-one> relationship with <Document> is set to eager fetching to ensure that 
//	the document is always loaded with the permission.
// */
//@Entity
//@Table(name = "permissions", uniqueConstraints = {
//    @UniqueConstraint(columnNames = {"document_id", "username", "permission"})
//})
//public class XPermission implements Serializable {
//
//    private static final long serialVersionUID = 1L;
//
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long id;
//
//    @ManyToOne(fetch = FetchType.EAGER)
//    @JoinColumn(name = "document_id", nullable = false)
//    @NotNull
//    private Document document;
//
//    @Column(nullable = false)
//    @NotBlank
//    private String username;
//
//    /**
//     * Permission type:
//     * 1 = READ
//     * 2 = WRITE
//     */
//    @Column(nullable = false)
//    private int permission;
//
//    // Default constructor
//    public XPermission() {
//    }
//
//    // Constructor with fields
//    public XPermission(Document document, String username, int permission) {
//        this.document = document;
//        this.username = username;
//        this.permission = permission;
//    }
//
//    // Constructor with all fields
//    public XPermission(Long id, Document document, String username, int permission) {
//        this.id = id;
//        this.document = document;
//        this.username = username;
//        this.permission = permission;
//    }
//
//    // Getters and Setters
//    public Long getId() {
//        return id;
//    }
//
//    public void setId(Long id) {
//        this.id = id;
//    }
//
//    public Document getDocument() {
//        return document;
//    }
//
//    public void setDocument(Document document) {
//        this.document = document;
//    }
//
//    public String getUsername() {
//        return username;
//    }
//
//    public void setUsername(String username) {
//        this.username = username;
//    }
//
//    public int getPermission() {
//        return permission;
//    }
//
//    public void setPermission(int permission) {
//        this.permission = permission;
//    }
//
//    @Override
//    public boolean equals(Object o) {
//        if (this == o) return true;
//        if (o == null || getClass() != o.getClass()) return false;
//        XPermission that = (XPermission) o;
//        return permission == that.permission &&
//               Objects.equals(document, that.document) &&
//               Objects.equals(username, that.username);
//    }
//
//    @Override
//    public int hashCode() {
//        return Objects.hash(document, username, permission);
//    }
//
//    @Override
//    public String toString() {
//        return "Permission{" +
//                "id=" + id +
//                ", document=" + (document != null ? document.getId() : null) +
//                ", username='" + username + '\'' +
//                ", permission=" + permission +
//                '}';
//    }
//}
