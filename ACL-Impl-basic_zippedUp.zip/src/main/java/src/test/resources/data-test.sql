-- Insert minimal test data

-- Insert users
INSERT INTO users (username, password, enabled) VALUES
('cybUser1', '$2a$10$8.UnVuG9HHgffUDAlk8qfOuVGkqRzgVymGe07xd00DMxs.AQubh4a', true),
('admin', '$2a$10$8.UnVuG9HHgffUDAlk8qfOuVGkqRzgVymGe07xd00DMxs.AQubh4a', true);

-- Insert authorities
INSERT INTO authorities (username, authority) VALUES
('cybUser1', 'ROLE_USER'),
('admin', 'ROLE_USER'),
('admin', 'ROLE_ADMIN');

-- Insert ACL classes
INSERT INTO acl_class (id, class) VALUES
(1, 'com.cybage.domain.Document');

-- Insert ACL SIDs (Security IDentities)
INSERT INTO acl_sid (id, principal, sid) VALUES
(1, true, 'admin'),
(2, true, 'cybUser1'),
(3, false, 'ROLE_ADMIN'),
(4, false, 'ROLE_USER');
