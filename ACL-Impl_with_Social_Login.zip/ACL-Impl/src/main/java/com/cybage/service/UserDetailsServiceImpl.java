package com.cybage.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cybage.domain.User;
import com.cybage.repository.UserRepository;

/**
 * Implementation of Spring Security's UserDetailsService
 * This service loads user-specific data for authentication..
 * It, Implements Spring Security's UserDetailsService interface to 
 * load user data for authentication
    Converts the application's User entity to Spring Security's UserDetails object
    Maps user roles to Spring Security authorities
    Handles account status flags (enabled, expired, locked)
    Provides additional utility methods for getting user details and updating login time
   Uses @Transactional annotations to ensure database consistency
 */
@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    private final UserRepository userRepository;

    public UserDetailsServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    /**
     * Loads a user by username for authentication
     * 
     * @param username the username to load
     * @return UserDetails object for Spring Security
     * @throws UsernameNotFoundException if user not found
     */
    @Override
    @Transactional(readOnly = true)
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Optional<User> userOpt = userRepository.findByUsername(username);
        
        if (!userOpt.isPresent()) {
            throw new UsernameNotFoundException("User not found with username: " + username);
        }
        
        User user = userOpt.get();
        
        return new org.springframework.security.core.userdetails.User(
            user.getUsername(),
            user.getPassword(),
            user.isEnabled(),
            !user.isAccountExpired(),
            !user.isCredentialsExpired(),
            !user.isAccountLocked(),
            getAuthorities(user)
        );
    }
    
    /**
     * Converts user roles to Spring Security authorities
     * 
     * @param user the user
     * @return collection of granted authorities
     */
    private Collection<? extends GrantedAuthority> getAuthorities(User user) {
        List<GrantedAuthority> authorities = new ArrayList<>();
        
        // Add the user's role as an authority
        if (user.getRole() != null && !user.getRole().isEmpty()) {
            // Check if the role already has the ROLE_ prefix
            String role = user.getRole();
            if (!role.startsWith("ROLE_")) {
                role = "ROLE_" + role;
            }
            authorities.add(new SimpleGrantedAuthority(role));
        }
        
        return authorities;
    }
    
    /**
     * Get the current user's details from the database
     * 
     * @param username the username
     * @return the user entity
     * @throws UsernameNotFoundException if user not found
     */
    @Transactional(readOnly = true)
    public User getUserDetails(String username) throws UsernameNotFoundException {
        Optional<User> userOpt = userRepository.findByUsername(username);
        
        if (!userOpt.isPresent()) {
            throw new UsernameNotFoundException("User not found with username: " + username);
        }
        
        return userOpt.get();
    }
    
    /**
     * Update the last login time for a user
     * 
     * @param username the username
     */
    @Transactional
    public void updateLastLogin(String username) {
        userRepository.updateLastLogin(username);
    }
}
