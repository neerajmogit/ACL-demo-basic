package com.cybage.service;

import com.cybage.domain.Document;
import java.util.List;
import java.util.Optional;

public interface DocumentService {
    Document createDocument(String name, String content);
    List<Document> findByOwner(String owner);
    Optional<Document> findById(Long id);

    List<Document> findAllDocuments();

    Document updateDocument(Document document);

    void deleteDocument(Long id);
}