//package com.cybage.service;
//
//import com.cybage.domain.Document;
//import com.cybage.domain.XAclEntry;
//
//import java.util.List;
//
//public interface XDocumentService {
//
//    void grantPermission(Document document, String principal, int permission);
//
//    void revokePermission(Document document, String principal, int permission);
//
//    void denyPermission(Document document, String principal, int permission);
//
//    boolean isPermissionGranted(Document document, String principal, int permission);
//
//    List<Integer> getPermissionsForDocument(Long documentId);
//
//    List<String> getPrincipalsWithPermission(Long documentId, int permission);
//
//    List<XAclEntry> getAclEntriesForDocument(Long documentId);
//
//    List<XAclEntry> getAclEntriesForPrincipal(String principal);
//}
//
//
////package com.cybage.service;
////
////import org.slf4j.Logger;
////import org.slf4j.LoggerFactory;
////import org.springframework.stereotype.Service;
////
////import com.cybage.domain.AclEntry;
////import com.cybage.domain.Document;
////import com.cybage.repository.AclEntryRepository;
////
////import java.util.List;
////import java.util.stream.Collectors;
////
////@Service
////public class AclService {
////
////    private static final Logger logger = LoggerFactory.getLogger(AclService.class);
////
////    private final AclEntryRepository aclEntryRepository;
////
////    public AclService(AclEntryRepository aclEntryRepository) {
////        this.aclEntryRepository = aclEntryRepository;
////    }
////
////    public boolean hasPermission(Document document, String username, int permissionCode) {
////        logger.info("Checking if user '{}' has permission '{}' on document with ID: {}", username, permissionCode, document.getId());
////        List<AclEntry> aclEntries = aclEntryRepository.findByDocumentIdAndPrincipalAndPermission(document.getId(), username, permissionCode);
////        return aclEntries.stream().anyMatch(AclEntry::isGranting);
////    }
////
////    public void grantPermission(Document document, String username, int permissionCode) {
////        logger.info("Granting permission '{}' to user '{}' on document with ID: {}", permissionCode, username, document.getId());
////        List<AclEntry> existingGrants = aclEntryRepository.findByDocumentIdAndPrincipalAndPermission(document.getId(), username, permissionCode)
////                                                      .stream()
////                                                      .filter(AclEntry::isGranting)
////                                                      .collect(Collectors.toList());
////        if (existingGrants.isEmpty()) {
////            AclEntry aclEntry = new AclEntry(document.getId(), username, permissionCode, true);
////            aclEntryRepository.save(aclEntry);
////            logger.info("Permission granted successfully.");
////        } else {
////            logger.warn("Permission already granted for user '{}' and permission '{}' on document with ID: {}", username, permissionCode, document.getId());
////        }
////
////        // Optionally revoke any explicit denials for the same permission
////        aclEntryRepository.findByDocumentIdAndPrincipalAndPermission(document.getId(), username, permissionCode)
////                          .stream()
////                          .filter(entry -> !entry.isGranting())
////                          .forEach(aclEntryRepository::delete);
////    }
////
////    public void revokePermission(Document document, String username, int permissionCode) {
////        logger.info("Revoking permission '{}' from user '{}' on document with ID: {}", permissionCode, username, document.getId());
////        aclEntryRepository.findByDocumentIdAndPrincipalAndPermission(document.getId(), username, permissionCode)
////                          .forEach(aclEntryRepository::delete);
////        logger.info("All matching permissions revoked.");
////    }
////
////    public void denyPermission(Document document, String username, int permissionCode) {
////        logger.info("Denying permission '{}' to user '{}' on document with ID: {}", permissionCode, username, document.getId());
////        List<AclEntry> existingDenials = aclEntryRepository.findByDocumentIdAndPrincipalAndPermission(document.getId(), username, permissionCode)
////                                                       .stream()
////                                                       .filter(entry -> !entry.isGranting())
////                                                       .collect(Collectors.toList());
////        if (existingDenials.isEmpty()) {
////            AclEntry aclEntry = new AclEntry(document.getId(), username, permissionCode, false);
////            aclEntryRepository.save(aclEntry);
////            logger.info("Permission denied successfully.");
////        } else {
////            logger.warn("Permission already denied for user '{}' and permission '{}' on document with ID: {}", username, permissionCode, document.getId());
////        }
////
////        // Optionally revoke any explicit grants for the same permission
////        aclEntryRepository.findByDocumentIdAndPrincipalAndPermission(document.getId(), username, permissionCode)
////                          .stream()
////                          .filter(AclEntry::isGranting)
////                          .forEach(aclEntryRepository::delete);
////    }
////
////    public List<AclEntry> getAclEntriesForDocument(Long documentId) {
////        logger.info("Getting all ACL entries for document with ID: {}", documentId);
////        return aclEntryRepository.findByDocumentId(documentId);
////    }
////
////    public List<AclEntry> getAclEntriesForPrincipal(String principal) {
////        logger.info("Getting all ACL entries for principal: {}", principal);
////        return aclEntryRepository.findByPrincipal(principal);
////    }
////
////    public List<String> getPrincipalsWithPermission(Long documentId, int permissionCode) {
////        logger.info("Getting principals with permission '{}' on document with ID: {}", permissionCode, documentId);
////        return aclEntryRepository.findByDocumentIdAndPermission(documentId, permissionCode)
////                                 .stream()
////                                 .filter(AclEntry::isGranting)
////                                 .map(AclEntry::getPrincipal)
////                                 .collect(Collectors.toList());
////    }
////}