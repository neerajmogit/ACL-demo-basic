//package com.cybage.controller;
//
//import java.util.List;
//
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.security.access.prepost.PreAuthorize;
//import org.springframework.security.core.Authentication;
//import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.web.bind.annotation.*;
//
//import com.cybage.domain.Document;
//import com.cybage.service.AclService;
//import com.cybage.service.DocumentService;
//
///**
// * REST controller for Document operations
// */
//@RestController
//@RequestMapping("/api")
//public class XDocumentController {
//
//    private final DocumentService documentService;
//    private final AclService aclService;
//    
//    public XDocumentController(DocumentService documentService, AclService aclService) {
//        this.documentService = documentService;
//        this.aclService = aclService;
//    }
//    
//    
//    @GetMapping
//    public ResponseEntity<String> test() {
//        return ResponseEntity.ok("Test endpoint is working");
//    }
//    
//    /**
//     * Public endpoint - accessible to all
//     */
//    @GetMapping("/public/x-hello")
//    public String publicHello() {
//        return "Hello, public user!";
//    }
//    
//    /**
//     * Secure endpoint - accessible to authenticated users
//     */
//    @GetMapping("/secure/x-hello")
//    public String secureHello() {
//        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
//        return "Hello, " + auth.getName() + "!";
//    }
//    
//    /**
//     * Get all documents
//     */
//    @GetMapping("/x-documents")
//    public List<Document> getAllDocuments() {
//        return documentService.findAll();
//    }
//    
//    /**
//     * Get document by ID
//     */
//    @GetMapping("/x-documents/{id}")
//    public ResponseEntity<Document> getDocument(@PathVariable Long id) {
//        Document document = documentService.findById(id);
//        
//        // Check if user has READ permission
//        String username = SecurityContextHolder.getContext().getAuthentication().getName();
//        if (!aclService.hasPermission(document, username, 1)) {
//            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
//        }
//        
//        return ResponseEntity.ok(document);
//    }
//    
//    /**
//     * Get documents by owner
//     */
//    @GetMapping("/documents/x-owner/{owner}")
//    public List<Document> getDocumentsByOwner(@PathVariable String owner) {
//        return documentService.findByOwner(owner);
//    }
//    
//    /**
//     * Get documents by name containing
//     */
//    @GetMapping("/documents/x-search")
//    public List<Document> searchDocuments(@RequestParam String name) {
//        return documentService.findByNameContaining(name);
//    }
//    
//    /**
//     * Get current user's documents
//     */
//    @GetMapping("/documents/x-my")
//    public List<Document> getMyDocuments() {
//        String username = SecurityContextHolder.getContext().getAuthentication().getName();
//        return documentService.findByOwner(username);
//    }
//    
//    /**
//     * Create a new document
//     */
//    @PostMapping
//    public ResponseEntity<Document> createDocument(@RequestBody Document document) {
//        Document createdDocument = documentService.createDocument(document.getName(), document.getContent());
//        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
//        if (authentication != null && authentication.getName() != null) {
//            aclService.grantPermission(createdDocument, authentication.getName(), 1); // Grant READ to creator
//            aclService.grantPermission(createdDocument, authentication.getName(), 2); // Grant WRITE to creator
//        }
//        return new ResponseEntity<>(createdDocument, HttpStatus.CREATED);
//    }
//    
//    /**
//     * Update an existing document
//     */
//    @PutMapping("/x-documents/{id}")
//    public ResponseEntity<Document> updateDocument(@PathVariable Long id, @RequestBody Document document) {
//        // Get existing document
//        Document existingDocument = documentService.findById(id);
//        
//        // Check if user has WRITE permission
//        String username = SecurityContextHolder.getContext().getAuthentication().getName();
//        if (!aclService.hasPermission(existingDocument, username, 2)) {
//            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
//        }
//        
//        // Update document
//        document.setId(id);
//        document.setOwner(existingDocument.getOwner()); // Preserve original owner
//        Document updatedDocument = documentService.updateDocument(document);
//        
//        return ResponseEntity.ok(updatedDocument);
//    }
//    
//    /**
//     * Delete a document
//     */
//    @DeleteMapping("/x-documents/{id}")
//    public ResponseEntity<Void> deleteDocument(@PathVariable Long id) {
//        // Get existing document
//        Document document = documentService.findById(id);
//        
//        // Check if user has WRITE permission (needed for delete)
//        String username = SecurityContextHolder.getContext().getAuthentication().getName();
//        if (!aclService.hasPermission(document, username, 2)) {
//            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
//        }
//        
//        // Delete document
//        documentService.deleteDocument(id);
//        
//        return ResponseEntity.noContent().build();
//    }
//    
//    /**
//     * Add permission for a user on a document
//     */
//    @PostMapping("/documents/{id}/x-permissions")
//    public ResponseEntity<String> addPermission(
//            @PathVariable Long id,
//            @RequestParam String username,
//            @RequestParam int permission) {
//        
//        // Get document
//        Document document = documentService.findById(id);
//        
//        // Only document owner can add permissions
//        String currentUser = SecurityContextHolder.getContext().getAuthentication().getName();
//        if (!document.getOwner().equals(currentUser)) {
//            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Only the document owner can manage permissions");
//        }
//        
//        // Add permission
//        aclService.addPermission(document, username, permission);
//        
//        return ResponseEntity.ok("Permission added successfully");
//    }
//    
//    /**
//     * Remove permission for a user on a document
//     */
//    @DeleteMapping("/documents/{id}/x-permissions")
//    public ResponseEntity<String> removePermission(
//            @PathVariable Long id,
//            @RequestParam String username,
//            @RequestParam int permission) {
//        
//        // Get document
//        Document document = documentService.findById(id);
//        
//        // Only document owner can remove permissions
//        String currentUser = SecurityContextHolder.getContext().getAuthentication().getName();
//        if (!document.getOwner().equals(currentUser)) {
//            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Only the document owner can manage permissions");
//        }
//        
//        // Remove permission
//        aclService.removePermission(document, username, permission);
//        
//        return ResponseEntity.ok("Permission removed successfully");
//    }
//    
//    /**
//     * Check if a user has a specific permission on a document
//     */
//    @GetMapping("/documents/{id}/check-permissions") 
//    public ResponseEntity<String> checkPermission(
//            @PathVariable Long id,
//            @RequestParam String username,
//            @RequestParam int permission) {
//        
//        // Get document
//        Document document = documentService.findById(id);
//        
//        // Check permission
//        boolean hasPermission = aclService.hasPermission(document, username, permission);
//        
//        if (hasPermission) {
//            return ResponseEntity.ok("User has the requested permission");
//        } else {
//            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("User does not have the requested permission");
//        }
//    }
//    
//    /**
//     * Clear document cache - admin only
//     */
//    @PostMapping("/documents/cache/x-clear")
//    @PreAuthorize("hasRole('ADMIN')")
//    public ResponseEntity<String> clearCache() {
//        documentService.clearCache();
//        return ResponseEntity.ok("Cache cleared successfully");
//    }
//}
