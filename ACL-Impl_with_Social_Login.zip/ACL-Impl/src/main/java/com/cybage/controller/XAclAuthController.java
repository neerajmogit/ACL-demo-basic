package com.cybage.controller;

import com.cybage.domain.Document;
import com.cybage.service.DocumentService; // Changed import
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/x-documents")
public class XAclAuthController {

    @Autowired
    private DocumentService documentAclService; // Changed type here

    @PostMapping("/cDoc")
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<Document> createDocument(@RequestParam String pName, @RequestParam String pContent) {
    	Document document = documentAclService.createDocument(pName, pContent);
        return new ResponseEntity<>(document, HttpStatus.CREATED);
    }

	@GetMapping("/documents/owner/{owner}")
    public ResponseEntity<List<Document>> getDocumentsByOwner(@PathVariable String owner) {
        List<Document> documents = documentAclService.findByOwner(owner);
        return new ResponseEntity<>(documents, HttpStatus.OK);
    }

    @GetMapping("/documents/{id}")
    public ResponseEntity<Document> getDocumentById(@PathVariable Long id) {
        Optional<Document> document = documentAclService.findById(id);
        return document.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @GetMapping("/documents")
    public ResponseEntity<List<Document>> getAllDocuments() {
        List<Document> documents = documentAclService.findAllDocuments();
        return new ResponseEntity<>(documents, HttpStatus.OK);
    }

    @PutMapping("/documents")
    public ResponseEntity<Document> updateDocument(@RequestBody Document document) {
        try {
            Document updatedDocument = documentAclService.updateDocument(document);
            return new ResponseEntity<>(updatedDocument, HttpStatus.OK);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Document not found or you don't have permission to update it", e);
        }
    }

    @DeleteMapping("/documents/{id}")
    public ResponseEntity<Void> deleteDocument(@PathVariable Long id) {
        try {
            documentAclService.deleteDocument(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Document not found or you don't have permission to delete it", e);
        }
    }

    // ACL related endpoints
    //These methods are not present in DocumentService interface.
/*
    @PostMapping("/permissions/grant")
    public ResponseEntity<Void> grantPermission(
            @RequestParam Long documentId,
            @RequestParam String principal,
            @RequestParam int permission) {
        Document document = documentAclService.findById(documentId).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Document not found"));
        documentAclService.grantPermission(document, principal, permission);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PostMapping("/permissions/revoke")
    public ResponseEntity<Void> revokePermission(
            @RequestParam Long documentId,
            @RequestParam String principal,
            @RequestParam int permission) {
        Document document = documentAclService.findById(documentId).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Document not found"));
        documentAclService.revokePermission(document, principal, permission);
        return new ResponseEntity<>(HttpStatus.OK);
    }

      @PostMapping("/permissions/deny")
    public ResponseEntity<Void> denyPermission(
            @RequestParam Long documentId,
            @RequestParam String principal,
            @RequestParam int permission) {
        Document document = documentAclService.findById(documentId).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Document not found"));
        documentAclService.denyPermission(document, principal, permission);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping("/permissions/check")
    public ResponseEntity<Boolean> checkPermission(
            @RequestParam Long documentId,
            @RequestParam String principal,
            @RequestParam int permission) {
        Document document = documentAclService.findById(documentId).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Document not found"));
        boolean isGranted = documentAclService.isPermissionGranted(document, principal, permission);
        return new ResponseEntity<>(isGranted, HttpStatus.OK);
    }

    @GetMapping("/permissions/{documentId}")
    public ResponseEntity<List<Integer>> getPermissionsForDocument(@PathVariable Long documentId) {
        List<Integer> permissions = documentAclService.getPermissionsForDocument(documentId);
        return new ResponseEntity<>(permissions, HttpStatus.OK);
    }

    @GetMapping("/permissions/principals/{documentId}/{permission}")
    public ResponseEntity<List<String>> getPrincipalsWithPermission(
            @PathVariable Long documentId,
            @PathVariable int permission) {
        List<String> principals = documentAclService.getPrincipalsWithPermission(documentId, permission);
        return new ResponseEntity<>(principals, HttpStatus.OK);
    }

    // Removed AclEntry and replaced it with generic return
    @GetMapping("/acl/entries/{documentId}")
     public ResponseEntity<List<Object>> getAclEntriesForDocument(@PathVariable Long documentId) {
        List<XAclEntry> aclEntries = documentAclService.getAclEntriesForDocument(documentId);
        List<Object> result = aclEntries.stream()
                .map(entry -> {
                    // Adapt this part based on how you want to represent XAclEntry
                    //  For example:
                    return new  AclEntryDTO(entry.getPrincipal(), entry.getPermission(), entry.isGranting());
                }).collect(Collectors.toList());
        return new ResponseEntity<>(result, HttpStatus.OK);
    }

    // Removed AclEntry and replaced it with generic return
    @GetMapping("/acl/entries/principal/{principal}")
    public ResponseEntity<List<Object>> getAclEntriesForPrincipal(@PathVariable String principal) {
       List<XAclEntry> aclEntries = documentAclService.getAclEntriesForPrincipal(principal);
       List<Object> result = aclEntries.stream()
                .map(entry -> {
                      return new  AclEntryDTO(entry.getPrincipal(), entry.getPermission(), entry.isGranting());
                }).collect(Collectors.toList());
        return new ResponseEntity<>(result, HttpStatus.OK);
    }
    //Inner class to represent Acl Entry
    private static class AclEntryDTO {
        private String principal;
        private int permission;
        private boolean isGranting;

        public AclEntryDTO(String principal, int permission, boolean isGranting) {
            this.principal = principal;
            this.permission = permission;
            this.isGranting = isGranting;
        }

        public String getPrincipal() {
            return principal;
        }

        public int getPermission() {
            return permission;
        }

        public boolean isGranting() {
            return isGranting;
        }
    }
*/
}

