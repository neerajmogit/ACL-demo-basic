package com.cybage.exception;

/**
 * Exception thrown when a document is not found in the system.
 * This is a runtime exception specifically for document not found scenarios.
 */
public class DocumentNotFoundException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    /**
     * Constructs a new DocumentNotFoundException with the specified detail message.
     *
     * @param message the detail message
     */
    public DocumentNotFoundException(String message) {
        super(message);
    }

    /**
     * Constructs a new DocumentNotFoundException with the specified detail message and cause.
     *
     * @param message the detail message
     * @param cause the cause of the exception
     */
    public DocumentNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Constructs a new DocumentNotFoundException for a specific document ID.
     *
     * @param id the ID of the document that was not found
     * @return a new DocumentNotFoundException with a message including the document ID
     */
    public static DocumentNotFoundException forId(Long id) {
        return new DocumentNotFoundException("Document not found with id: " + id);
    }

    /**
     * Constructs a new DocumentNotFoundException for a specific document owner.
     *
     * @param owner the owner of the documents that were not found
     * @return a new DocumentNotFoundException with a message including the owner
     */
    public static DocumentNotFoundException forOwner(String owner) {
        return new DocumentNotFoundException("No documents found for owner: " + owner);
    }

    /**
     * Constructs a new DocumentNotFoundException for a specific document name search.
     *
     * @param namePattern the name pattern that was searched for
     * @return a new DocumentNotFoundException with a message including the name pattern
     */
    public static DocumentNotFoundException forNamePattern(String namePattern) {
        return new DocumentNotFoundException("No documents found matching name pattern: " + namePattern);
    }
}
