//package com.cybage.repository;
//
//import com.cybage.domain.XAclEntry;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//
//import java.util.List;
//
//@Repository
//public interface XAclEntryRepository extends JpaRepository<XAclEntry, Long> {
//
//    List<XAclEntry> findByDocumentId(Long documentId);
//
//    List<XAclEntry> findByPrincipal(String principal);
//
//    List<XAclEntry> findByDocumentIdAndPermission(Long documentId, int permission);
//
//    List<XAclEntry> findByDocumentIdAndPrincipal(Long documentId, String principal);
//    XAclEntry findByDocumentIdAndPrincipalAndPermission(Long documentId, String principal, int permission);
//}