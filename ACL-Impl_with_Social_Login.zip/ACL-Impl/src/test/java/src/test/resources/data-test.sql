-- Insert test data for ACL classes
INSERT INTO acl_class (id, class) VALUES (1, 'com.cybage.domain.Document');

-- Insert test data for ACL SIDs (Security Identities)
INSERT INTO acl_sid (id, principal, sid) VALUES (1, true, 'testuser');
INSERT INTO acl_sid (id, principal, sid) VALUES (2, true, 'admin');
INSERT INTO acl_sid (id, principal, sid) VALUES (3, true, 'user1');

-- Insert test documents
INSERT INTO document (id, name, content, owner) VALUES (1, 'Test Document 1', 'This is test content 1', 'testuser');
INSERT INTO document (id, name, content, owner) VALUES (2, 'Test Document 2', 'This is test content 2', 'testuser');
INSERT INTO document (id, name, content, owner) VALUES (3, 'Admin Document', 'This is admin content', 'admin');
INSERT INTO document (id, name, content, owner) VALUES (4, 'User1 Document', 'This is user1 content', 'user1');

-- Insert ACL object identities
INSERT INTO acl_object_identity (id, object_id_class, object_id_identity, parent_object, owner_sid, entries_inheriting) 
VALUES (1, 1, 1, NULL, 1, false);
INSERT INTO acl_object_identity (id, object_id_class, object_id_identity, parent_object, owner_sid, entries_inheriting) 
VALUES (2, 1, 2, NULL, 1, false);
INSERT INTO acl_object_identity (id, object_id_class, object_id_identity, parent_object, owner_sid, entries_inheriting) 
VALUES (3, 1, 3, NULL, 2, false);
INSERT INTO acl_object_identity (id, object_id_class, object_id_identity, parent_object, owner_sid, entries_inheriting) 
VALUES (4, 1, 4, NULL, 3, false);

-- Insert ACL entries (permissions)
-- Document 1: testuser has READ, WRITE, DELETE
INSERT INTO acl_entry (id, acl_object_identity, ace_order, sid, mask, granting, audit_success, audit_failure) 
VALUES (1, 1, 1, 1, 1, true, true, true);  -- READ permission
INSERT INTO acl_entry (id, acl_object_identity, ace_order, sid, mask, granting, audit_success, audit_failure) 
VALUES (2, 1, 2, 1, 2, true, true, true);  -- WRITE permission
INSERT INTO acl_entry (id, acl_object_identity, ace_order, sid, mask, granting, audit_success, audit_failure) 
VALUES (3, 1, 3, 1, 8, true, true, true);  -- DELETE permission

-- Document 2: testuser has READ, WRITE, admin has READ
INSERT INTO acl_entry (id, acl_object_identity, ace_order, sid, mask, granting, audit_success, audit_failure) 
VALUES (4, 2, 1, 1, 1, true, true, true);  -- READ permission for testuser
INSERT INTO acl_entry (id, acl_object_identity, ace_order, sid, mask, granting, audit_success, audit_failure) 
VALUES (5, 2, 2, 1, 2, true, true, true);  -- WRITE permission for testuser
INSERT INTO acl_entry (id, acl_object_identity, ace_order, sid, mask, granting, audit_success, audit_failure) 
VALUES (6, 2, 3, 2, 1, true, true, true);  -- READ permission for admin

-- Document 3: admin has all permissions, testuser has READ
INSERT INTO acl_entry (id, acl_object_identity, ace_order, sid, mask, granting, audit_success, audit_failure) 
VALUES (7, 3, 1, 2, 1, true, true, true);  -- READ permission for admin
INSERT INTO acl_entry (id, acl_object_identity, ace_order, sid, mask, granting, audit_success, audit_failure) 
VALUES (8, 3, 2, 2, 2, true, true, true);  -- WRITE permission for admin
INSERT INTO acl_entry (id, acl_object_identity, ace_order, sid, mask, granting, audit_success, audit_failure) 
VALUES (9, 3, 3, 2, 8, true, true, true);  -- DELETE permission for admin
INSERT INTO acl_entry (id, acl_object_identity, ace_order, sid, mask, granting, audit_success, audit_failure) 
VALUES (10, 3, 4, 1, 1, true, true, true); -- READ permission for testuser

-- Document 4: user1 has all permissions, admin has READ
INSERT INTO acl_entry (id, acl_object_identity, ace_order, sid, mask, granting, audit_success, audit_failure) 
VALUES (11, 4, 1, 3, 1, true, true, true); -- READ permission for user1
INSERT INTO acl_entry (id, acl_object_identity, ace_order, sid, mask, granting, audit_success, audit_failure) 
VALUES (12, 4, 2, 3, 2, true, true, true); -- WRITE permission for user1
INSERT INTO acl_entry (id, acl_object_identity, ace_order, sid, mask, granting, audit_success, audit_failure) 
VALUES (13, 4, 3, 3, 8, true, true, true); -- DELETE permission for user1
INSERT INTO acl_entry (id, acl_object_identity, ace_order, sid, mask, granting, audit_success, audit_failure) 
VALUES (14, 4, 4, 2, 1, true, true, true); -- READ permission for admin
