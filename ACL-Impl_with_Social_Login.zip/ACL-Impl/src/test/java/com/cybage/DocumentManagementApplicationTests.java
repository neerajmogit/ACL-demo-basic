package com.cybage;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.cybage.config.TestConfig;
import com.cybage.config.XTestSecurityConfig;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
@Import(XTestSecurityConfig.class)
public class DocumentManagementApplicationTests {

    @LocalServerPort
    private int port;
    private MockMvc mockMvc;

    @Autowired
    private WebApplicationContext webApplicationContext;

    @BeforeEach
    void setup() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext)
        							.build();
    }

    @Test
    void contextLoads() {
    }

    @Test
    void testPublicEndpoint() throws Exception {
        try {
            // Try the public endpoint
            MvcResult result = mockMvc.perform(get("/api"))
                    .andReturn();
            
            System.out.println("\n******** Public endpoint status: " + result.getResponse().getStatus());
            System.out.println("\\n******** Public endpoint response: " + result.getResponse().getContentAsString());
            
            // Assert after printing debug info
            assertEquals(HttpStatus.OK.value(), result.getResponse().getStatus());
        } catch (Exception e) {
            System.err.println("Test failed with exception: " + e.getMessage());
            e.printStackTrace();
            throw e;
        }
        
					//        @Test
					//        void testPublicEndpoint() {
					//            ResponseEntity<String> response = restTemplate.getForEntity("/public", String.class);
					//            assertEquals(HttpStatus.OK, response.getStatusCode());
					//            assertEquals("This is a public endpoint that anyone can access", response.getBody());
					//        }
					//    }

    	}
	}
						//    @Autowired
						//    private TestRestTemplate restTemplate;
						//
						//    @Test
						//    public void contextLoads() {
						//        // This test verifies that the application context loads successfully
						//    }
						
						    
						//    @Test
						//    public void testPublicEndpoint() {
						//        ResponseEntity<String> response = restTemplate.getForEntity(
						//                "http://localhost:" + port + "/api/public/hello", String.class);
						//        
						//        assertEquals(HttpStatus.OK, response.getStatusCode());
						//        assertEquals("Hello, public user!", response.getBody());
				    	//    }
				

