package com.cybage.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import com.cybage.domain.Document;
import com.cybage.service.DocumentAclService;
import com.cybage.service.DocumentService;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class XDocumentControllerDirectTest {

    @Mock
    private DocumentService documentService;

    @Mock
    private DocumentAclService aclService;
    
    @Mock
    private SecurityContext securityContext;
    
    @Mock
    private Authentication authentication;

    @InjectMocks
    private XAclAuthController controller;

    private Document testDocument;

    @BeforeEach
    public void setup() {
        // Create test document
        testDocument = new Document();
        testDocument.setId(1L);
        testDocument.setName("Test Document");
        testDocument.setContent("Test Content");
        
        // Configure document service
        when(documentService.findById(1L)).thenReturn(testDocument);
        when(documentService.findById(999L)).thenThrow(new RuntimeException("Document not found"));
        
        // Setup security context mock
        when(securityContext.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(securityContext);
        when(authentication.getName()).thenReturn("testuser");
    }

    @Test
    public void testGetDocument_WithPermission_ShouldReturnDocument() {
        // Given
        when(aclService.hasPermission(any(Document.class), eq("testuser"), eq(1))).thenReturn(true);

        // When
        ResponseEntity<?> response = controller.getDocument(1L);

        // Then
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(testDocument, response.getBody());
        
        // Verify that the service methods were called with the correct parameters
        verify(documentService).findById(1L);
        verify(aclService).hasPermission(testDocument, "testuser", 1);
    }

    @Test
    public void testGetDocument_WithoutPermission_ShouldReturnForbidden() {
        // Given
        when(aclService.hasPermission(any(Document.class), eq("testuser"), eq(1))).thenReturn(false);

        // When
        ResponseEntity<?> response = controller.getDocument(1L);

        // Then
        assertEquals(HttpStatus.FORBIDDEN, response.getStatusCode());
        
        // Verify that the service methods were called with the correct parameters
        verify(documentService).findById(1L);
        verify(aclService).hasPermission(testDocument, "testuser", 1);
    }

    @Test
    public void testGetDocument_DocumentNotFound_ShouldHandleException() {
        // When & Then
        Exception exception = assertThrows(RuntimeException.class, () -> {
            controller.getDocument(999L);
        });
        
        assertEquals("Document not found", exception.getMessage());
        
        // Verify that the service method was called with the correct parameter
        verify(documentService).findById(999L);
    }
}
