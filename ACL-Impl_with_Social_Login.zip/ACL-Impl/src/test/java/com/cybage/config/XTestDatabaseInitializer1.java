//package com.cybage.config;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.TestComponent;
//import org.springframework.context.annotation.Profile;
//import org.springframework.core.io.ClassPathResource;
//import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
//import org.springframework.stereotype.Component;
//
//import javax.annotation.PostConstruct; // This wasn't resolved because of "non-reliance" on jakarata package. So a newer latest version file is created 
//import javax.sql.DataSource;
//
//@Component
//@Profile("test")
//public class TestDatabaseInitializer1 {
//
//    private final DataSource dataSource;
//
//    @Autowired
//    public TestDatabaseInitializer1(DataSource dataSource) {
//        this.dataSource = dataSource;
//    }
//
//    @PostConstruct
//    public void initialize() {
//        try {
//            // First execute schema script
//            ResourceDatabasePopulator schemaPopulator = new ResourceDatabasePopulator();
//            schemaPopulator.addScript(new ClassPathResource("schema-test.sql"));
//            schemaPopulator.execute(dataSource);
//            
//            // Then execute data script
//            ResourceDatabasePopulator dataPopulator = new ResourceDatabasePopulator();
//            dataPopulator.addScript(new ClassPathResource("data-test.sql"));
//            dataPopulator.execute(dataSource);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//}



