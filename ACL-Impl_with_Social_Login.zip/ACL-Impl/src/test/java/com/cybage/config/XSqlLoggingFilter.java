//--> Optional class for detailed logging

//package com.cybage.config;

//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.boot.test.context.TestConfiguration;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Profile;
//import org.springframework.jdbc.core.JdbcTemplate;
//
//import javax.sql.DataSource;
//import java.lang.reflect.InvocationHandler;
//import java.lang.reflect.Method;
//import java.lang.reflect.Proxy;
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.Statement;
//
//@TestConfiguration
//@Profile("test")
//public class SqlLoggingFilter {
//    private static final Logger log = LoggerFactory.getLogger(SqlLoggingFilter.class);
//
//    @Bean
//    public JdbcTemplate jdbcTemplate(DataSource dataSource) {
//        return new JdbcTemplate(createLoggingProxy(dataSource));
//    }
//
//    private DataSource createLoggingProxy(DataSource dataSource) {
//        return (DataSource) Proxy.newProxyInstance(
//            DataSource.class.getClassLoader(),
//            new Class<?>[] { DataSource.class },
//            new DataSourceInvocationHandler(dataSource)
//        );
//    }
//
//    private static class DataSourceInvocationHandler implements InvocationHandler {
//        private final DataSource target;
//
//        public DataSourceInvocationHandler(DataSource target) {
//            this.target = target;
//        }
//
//        @Override
//        public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
//            if ("getConnection".equals(method.getName())) {
//                Connection connection = (Connection) method.invoke(target, args);
//                return Proxy.newProxyInstance(
//                    Connection.class.getClassLoader(),
//                    new Class<?>[] { Connection.class },
//                    new ConnectionInvocationHandler(connection)
//                );
//            }
//            return method.invoke(target, args);
//        }
//    }
//
//    private static class ConnectionInvocationHandler implements InvocationHandler {
//        private final Connection target;
//
//        public ConnectionInvocationHandler(Connection target) {
//            this.target = target;
//        }
//
//        @Override
//        public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
//            if ("prepareStatement".equals(method.getName())) {
//                String sql = (String) args[0];
//                log.info("Preparing SQL: {}", sql);
//                PreparedStatement stmt = (PreparedStatement) method.invoke(target, args);
//                return Proxy.newProxyInstance(
//                    PreparedStatement.class.getClassLoader(),
//                    new Class<?>[] { PreparedStatement.class },
//                    new PreparedStatementInvocationHandler(stmt, sql)
//                );
//            }
//            return method.invoke(target, args);
//        }
//    }
//
//    private static class PreparedStatementInvocationHandler implements InvocationHandler {
//        private final PreparedStatement target;
//        private final String sql;
//        private final Object[] parameters = new Object[100];
//
//        public PreparedStatementInvocationHandler(PreparedStatement target, String sql) {
//            this.target = target;
//            this.sql = sql;
//        }
//
//        @Override
//        public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
//            if (method.getName().startsWith("set") && args != null && args.length == 2) {
//                if (args[0] instanceof Integer) {
//                    parameters[(Integer) args[0] - 1] = args[1];
//                }
//            } else if ("execute".equals(method.getName()) || "executeQuery".equals(method.getName()) || 
//                      "executeUpdate".equals(method.getName())) {
//                StringBuilder paramLog = new StringBuilder();
//                for (int i = 0; i < parameters.length; i++) {
//                    if (parameters[i] != null) {
//                        paramLog.append("Parameter ").append(i + 1).append(": ").append(parameters[i]).append(", ");
//                    }
//                }
//                log.info("Executing SQL: {} with parameters [{}]", sql, paramLog);
//            }
//            return method.invoke(target, args);
//        }
//    }
//}


