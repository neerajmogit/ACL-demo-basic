//package com.cybage.service;
//
//import com.cybage.domain.Document;
//import com.cybage.repository.DocumentRepository;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.security.access.AccessDeniedException;
//import org.springframework.security.acls.domain.BasePermission;
//import org.springframework.security.acls.domain.ObjectIdentityImpl;
//import org.springframework.security.acls.model.MutableAclService;
//import org.springframework.security.acls.model.ObjectIdentity;
//import org.springframework.security.test.context.support.WithMockUser;
//import org.springframework.test.context.ActiveProfiles;
//import org.springframework.transaction.annotation.Transactional;
//
//import java.util.List;
//import java.util.Optional;
//
//import static org.junit.jupiter.api.Assertions.*;
//
//@SpringBootTest
//@Transactional
//@ActiveProfiles("test")
//public class DocumentServiceImplTestOrig {
//
//    // Static final references
//    private static final String USER1 = "cybUser1";
//    private static final String USER2 = "cybUser2";
//    private static final String MANAGER = "cybManager1";
//    private static final String ADMIN = "admin";
//
//    @Autowired
//    private DocumentServiceImpl documentService;
//
//    @Autowired
//    private DocumentRepository documentRepository;
//
//    @Autowired
//    private MutableAclService mutableAclService;
//
//    private Document testDocument;
//
//    @BeforeEach
//    public void setUp() {
//        // Clean up any existing test documents
//        documentRepository.deleteAll();
//    }
//
//    @Test
//    @WithMockUser(username = USER1)
//    public void testCreateDocument() {
//        // Create a document as USER1
//        Document document = new Document("Test Document", "Test Content", USER1);
//        testDocument = documentService.createDocument(document);
//        
//        assertNotNull(testDocument.getId());
//        assertEquals("Test Document", testDocument.getName());
//        assertEquals("Test Content", testDocument.getContent());
//        assertEquals(USER1, testDocument.getOwner());
//        
//        // Verify ACL was created
//        ObjectIdentity objectIdentity = new ObjectIdentityImpl(Document.class, testDocument.getId());
//        assertNotNull(mutableAclService.readAclById(objectIdentity));
//    }
//
//    @Test
//    @WithMockUser(username = USER1)
//    public void testFindById_WithPermission() {
//        // Create a document as USER1
//        Document document = new Document("Test Document", "Test Content", USER1);
//        testDocument = documentService.createDocument(document);
//        
//        // USER1 should be able to read their own document
//        Optional<Document> foundDocument = documentService.findById(testDocument.getId());
//        assertTrue(foundDocument.isPresent());
//        assertEquals(testDocument.getId(), foundDocument.get().getId());
//    }
//
//    @Test
//    @WithMockUser(username = USER2)
//    public void testFindById_WithoutPermission() {
//        // Create a document as USER1 (done in setup)
//        Document document = new Document("User1's Document", "Private Content", USER1);
//        Document savedDocument = documentRepository.save(document);
//        
//        // Create ACL for USER1 only
//        ObjectIdentity objectIdentity = new ObjectIdentityImpl(Document.class, savedDocument.getId());
//        try {
//            mutableAclService.createAcl(objectIdentity);
//            
//            // USER2 should not be able to read USER1's document
//            assertThrows(AccessDeniedException.class, () -> {
//                documentService.findById(savedDocument.getId());
//            });
//        } catch (Exception e) {
//            fail("Failed to set up test: " + e.getMessage());
//        }
//    }
//
//    @Test
//    @WithMockUser(username = ADMIN, roles = {"ADMIN"})
//    public void testFindAll_Admin() {
//        // Admin should see all documents
//        Document doc1 = documentService.createDocument(new Document("Admin Doc", "Admin Content", ADMIN));
//        Document doc2 = documentService.createDocument(new Document("Another Admin Doc", "More Content", ADMIN));
//        
//        List<Document> documents = documentService.findAll();
//        assertTrue(documents.size() >= 2);
//        assertTrue(documents.stream().anyMatch(d -> d.getId().equals(doc1.getId())));
//        assertTrue(documents.stream().anyMatch(d -> d.getId().equals(doc2.getId())));
//    }
//
//    @Test
//    @WithMockUser(username = USER1)
//    public void testUpdateDocument_WithPermission() {
//        // Create a document as USER1
//        Document document = new Document("Original Title", "Original Content", USER1);
//        testDocument = documentService.createDocument(document);
//        
//        // Update the document
//        testDocument.setName("Updated Title");
//        testDocument.setContent("Updated Content");
//        Document updatedDocument = documentService.updateDocument(testDocument);
//        
//        assertEquals("Updated Title", updatedDocument.getName());
//        assertEquals("Updated Content", updatedDocument.getContent());
//    }
//
//    @Test
//    @WithMockUser(username = USER1)
//    public void testDeleteDocument_WithPermission() {
//        // Create a document as USER1
//        Document document = new Document("To Be Deleted", "Delete me", USER1);
//        testDocument = documentService.createDocument(document);
//        
//        // Delete the document
//        documentService.deleteDocument(testDocument.getId());
//        
//        // Verify it's gone
//        assertTrue(documentRepository.findById(testDocument.getId()).isEmpty());
//    }
//
////    @Test
////    @WithMockUser(username = USER1)
////    public void testAddAndRemovePermission() {
////        // Create a document as USER1
////        Document
//    
//    @Test
//    @WithMockUser(username = USER1)
//    public void testAddAndRemovePermission() {
//        // Create a document as USER1
//        Document document = new Document("Shared Document", "Content to share", USER1);
//        testDocument = documentService.createDocument(document);
//        
//        // Add READ permission for USER2
//        documentService.addPermission(testDocument, USER2, BasePermission.READ.getMask());
//        
//        // Switch to USER2 and verify they can read the document
//        // This is a simplified test - in a real scenario, you'd need to switch security context
//        try {
//            // Remove the permission
//            documentService.removePermission(testDocument, USER2, BasePermission.READ.getMask());
//            
//            // Verify permission was removed (would need proper security context switching)
//        } catch (Exception e) {
//            fail("Permission management failed: " + e.getMessage());
//        }
//    }
//    
//    @Test
//    @WithMockUser(username = MANAGER, roles = {"MANAGER"})
//    public void testFindByOwner() {
//        // Create documents with different owners
//        Document doc1 = documentService.createDocument(new Document("Manager Doc 1", "Content 1", MANAGER));
//        Document doc2 = documentService.createDocument(new Document("Manager Doc 2", "Content 2", MANAGER));
//        documentService.createDocument(new Document("User Doc", "User Content", USER1));
//        
//        // Find documents by owner
//        List<Document> managerDocs = documentService.findByOwner(MANAGER);
//        
//        assertEquals(2, managerDocs.size());
//        assertTrue(managerDocs.stream().anyMatch(d -> d.getId().equals(doc1.getId())));
//        assertTrue(managerDocs.stream().anyMatch(d -> d.getId().equals(doc2.getId())));
//    }
//}
package com;


