------------------
Proj-structure
-----------------

ACL-Impl/

├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/
│   │   │       └── cspl/
|     |    |             |-config
                         ├── ACLConfig
                         ├── SecurityConfig\
│   │   │           ├── domain/
│   │   │           │   ├── AclEntry.java
│   │   │           │   ├── Document.java
│   │   │           │   ├──Permission.java
│   │   │           ├── repository/
│   │   │           │   ├── AclEntryRepository.java
│   │   │           │   ├── DocumentRepository.java
│   │   │           │   ├── PermissionRepository.java
│   │   │           │   ├── UserRepository.java
│   │   │           ├── service/
│   │   │           │   ├── AclService.java
│   │   │           │   ├──AclServiceImpl.java
│   │   │           │   ├── DocumentService.java
│   │   │           │   ├── UserDetailsServiceImpl.java
│   │   │           │   ├── DocumentServiceImpl.java
│   │   │           ├── controller/
│   │   │           │   ├── XAclAuthController.java
│   │   │           ├── AclImplApplication.java
│   │   │           └── ... (other classes)
│   │   ├── resources/
│   │   │   ├── application.properties
│   │   │   ├── static/
│   │   │   │   ├── index.html
│   │   │   │   ├── document-list.html
│   │   │   │   ├── document-detail.html
│   │   │   │   ├── permission-management.html
│   │   │   └── ... (other resources)

│   ├── test/

│   │   └── ... (test classes - optional)

├── pom.xml(if using Maven)
└── build.gradle (if using Gradle)
[=---- Compilation, etc.STARTs ----=] 

	C:\Temp\ACL-Impl>"C:\Program Files\Maven\bin\mvn" spring-boot:run > C:\Temp\m2.txt
					 "C:\Program Files\Maven\bin\mvn" clean install -Dmaven.test.skip=true
	
    Execute the appln:
		"C:\Program Files\Maven\bin\mvn" clean install -DskipTests             This doesn't work
		"C:\Program Files\Maven\bin\mvn" clean install -Dmaven.test.skip=true  This did.
	Running the SB Appln without the Tests,
		"C:\Program Files\Maven\bin\mvn" clean spring-boot:run -Dmaven.test.skip=true
	On the URL enter 
		http://localhost:9192/
	Should redirect to a web page
	    http://localhost:9192/my_login.html
	Enter passwords configured in DatabseInitializer
		userReader1/userPass1
	Should redirect to a web page meant for Creating a Document, for users assigned with ROLE_ADMIN.
		http://localhost:9192/create-document.html
	Try Entering any Document name/content, and hit "Create" button
	   "MydocumentName1"/"Mydoccontent text"
	Should NOT redirect, instead throw an error message, in our GlobalExceptionHandler.	   
	 "Access denied: You don't haVE permiSSion to perFOrm this oPEration"  
	Now, click the link logout, to logout, or, enter URL 
		http://localhost:9192/logout
	Enter the Admin credentials userAdmin/adminPass1,  already configured in DatabseInitializer
 	Should redirect to a web page
		http://localhost:9192/create-document.html
	Try Entering any Document name/content, and hit "Create" button
	   "MydocumentName1"/"Mydoccontent text"
 	Should present a message 
 		"Success!"  --On the web page.
 	Verify the document creation on the  H2 console by entering URL
 	  	http://localhost:9192/h2-console
 	On the H2 console Try to connect the Database by entering the username "sa" and empty password on this interface
 	Verify that the JDBC_URL contains the ACL Database value, as configured in the application properties
 	  	spring.datasource.url=jdbc:h2:mem:acl_db;DB_CLOSE_DELAY=-1;
 	Execute the normal SQL containing the just created document
 		SELECT * FROM documents; 
 	Verify the content/name.
 	  	       		 
[=---- Compilation, etc.ENDs ----=]

	
Authorization related text STARTS: ------------------------
 Role of the Authorization Header.:
   In secure web applications, the Authorization header in an HTTP request is used to provide credentials
   that authenticate the user making the request. This allows the server to verify the identity of the user and determine 
   if they are allowed to perform the requested action.In the context of the createDocument example, the Authorization 
   header is crucial for the following reasons:Authentication: When a user attempts to create a document (or perform any 
   other protected action), the server needs to know who is making the request. The Authorization header carries the 
   information that identifies the user.Authorization: Once the server knows who the user is (authentication), it needs 
   to determine if that user has the necessary permissions to create a document. This is where your ACL (Access Control 
   List) comes in. The server checks the ACL to see if the user has the CREATE permission (or, in your modified case, the 
   permissions to create a document and then set its read permissions). 
  
 Common Authentication Schemes The Authorization header can use various authentication schemes. The most common one you'll 
   encounter in modern web applications is:Bearer Authentication: This scheme is often used with JWT (JSON Web Tokens). A
   JWT is a compact, URL-safe string that represents a set of claims. When a user logs in, the server generates a JWT and 
   sends it back to the client. The client then includes this JWT in the Authorization header of subsequent requests. In 
   the example: Authorization: 'Bearer YOUR_JWT_TOKEN'Bearer: This indicates the authentication scheme.YOUR_JWT_TOKEN: 
   This is the actual JWT token. It's a long string of characters. 
 
 How it Works in Your Example User Logs In (Not Directly at /index.html):  The user typically logs in through a separate 
   endpoint (e.g., /api/auth/login).  This login process (which you would have implemented) involves: The user provides 
   their credentials (e.g., username and password) to your application, usually through a form on a page other than 
   index.html. Your server verifies the credentials. If the credentials are valid, your server generates a JWT. The server 
   sends the JWT back to the client (e.g., the browser). The client (using JavaScript) then stores this JWT, often in 
   local storage or a cookie. 
 
 Accessing /index.html: When you access localhost:9192/index.html, you're loading the front-end part of your application 
   (the HTML, CSS, and JavaScript).  This is where the JavaScript code that interacts with your backend API resides.  
   The browser loads and executes this code. 
   
 Subsequent Requests from JavaScript:  After the index.html page loads, the JavaScript code within that page will make 
   requests to your backend API (e.g., to /x-documents to create a document).  
   It is at this point that the Authorization header comes into play.  The JavaScript code will:Retrieve the JWT from 
   where it was stored (local storage, cookie). Include the JWT in the Authorization header of the fetch request. Server 
   Authenticates and Authorizes: Your Spring Boot application's security filter intercepts the request, extracts the JWT 
   from the Authorization header, and:Authenticates the user by verifying the JWT's signature and claims. Authorizes the 
   user by checking if they have the necessary permissions to create a document (and set its ACL). Server Processes 
   Request: If the user is authenticated and authorized, your XAclAuthController.createDocument() method is executed. 
   In Summary The key is that authentication doesn't usually happen directly when you request index.html.  Instead:
   index.html is served (it's a static file). The JavaScript code in index.html then makes API calls to your backend.
   Those API calls (e.g., to create a document) include the Authorization header with the JWT. So, the login happens 
   before the user interacts with the document creation functionality, and the JWT is obtained and stored as a result 
   of that login process.

Authorization related text ENDs:----------------------	
	
	Running your Spring Boot application while ignoring tests:Build the Spring Boot application (excluding tests):Open a 
	terminal or command prompt.Navigate to the root directory of your Spring Boot project (where the pom.xml or build.gradle file is
	 located). 
	Use the following command to perform a clean build, skipping the tests:Maven:
	 mvn clean spring-boot:run -DskipTests
OR,  mvn clean spring-boot:run -Dmaven.test.skip=true
	 Gradle:gradle clean bootRun --exclude-task test
OR,  gradle clean bootRun -x test

 Access the application in your browser:Once the Spring Boot application has started (you'll see log messages in the console indicating it's
 running), open your web browser. Navigate to the following URL:http://localhost:8080/index.html
 This will display the index.html page.

ENHANCEMENT: For Social login STARTs

//Class SecurityConfig STARTs
package com.example.myaclapp.config; // Adjust package name as per your project

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.user.DefaultOAuth2User;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@Configuration
@EnableWebSecurity
@EnableMethodSecurity(prePostEnabled = true) // Keep this for @PreAuthorize
public class SecurityConfig {

    private static final Logger logger = LoggerFactory.getLogger(SecurityConfig.class);

    /**
     * Security filter chain configuration
     */
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

    	logger.debug("Configuring HttpSecurity");
        http
            .cors(cors -> cors.configurationSource(corsConfigurationSource()))
            .csrf(csrf -> csrf.disable()) // Keep disabled as per your config
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED)) // Keep IF_REQUIRED
            .authorizeHttpRequests(
            						auth ->  {
            				                    logger.debug("Configuring authorization rules");
            				                    auth
							            	        .requestMatchers("/index.html").permitAll()
							            	        .requestMatchers("/static/**").permitAll()
							            	        .requestMatchers("/my_login.html").permitAll()
							            	        .requestMatchers("/login").permitAll()
                                                    // **IMPORTANT: Add these for OAuth2 login flow**
							            	        .requestMatchers("/oauth2/**").permitAll() // For OAuth2 authorization endpoint
                                                    .requestMatchers("/login/oauth2/code/**").permitAll() // For OAuth2 redirect/callback URI
							            	        // End of OAuth2 specific additions
							            	        .requestMatchers("/x-documents/user").permitAll()
							            	        .requestMatchers("/create-document.html").permitAll()
							            	        .requestMatchers("/x-documents/cDoc").authenticated() // Remains authenticated
							            	        .requestMatchers("/document-list.html").permitAll()
							            	        .requestMatchers("/document-detail.html").permitAll()
							            	        .requestMatchers("/permission-management.html").permitAll()

							            	        .requestMatchers("/css/**").permitAll()
							            	        .requestMatchers("/js/**").permitAll()
							            	        .requestMatchers("/api/public/**").permitAll()
							            	        .requestMatchers("/api/auth/**").permitAll()
							            	        .requestMatchers("/h2-console/**").permitAll()
							            	        .anyRequest().authenticated();
            						})
                                    // --- Existing Form Login Configuration ---
									.formLogin( form -> {
									            		logger.debug("Configuring form login");
												        form
													            		.loginPage("/my_login.html")
													            		.loginProcessingUrl("/login")
													                    .defaultSuccessUrl("/create-document.html", true)
					                    								.permitAll();
									            })
                                    // --- NEW: Social Login (OAuth2) Configuration ---
                                    .oauth2Login(oauth2Login ->
                                        oauth2Login
                                            .loginPage("/my_login.html") // Use your existing custom login page to show social login buttons
                                            .defaultSuccessUrl("/create-document.html", true) // Same success URL as form login
                                            .failureUrl("/my_login.html?error") // Redirect to login page on failure
                                            .userInfoEndpoint(userInfo ->
                                                userInfo.oauth2UserService(this.oauth2UserService()) // Link to your custom service
                                            )
                                    )
                                    // --- Existing Logout Configuration ---
									.logout(logout -> logout
									                    .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
									                    .logoutSuccessUrl("/")
									                    .invalidateHttpSession(true)
									                    .clearAuthentication(true)
									                    .deleteCookies("JSESSIONID")
									            );
        // ------ For H2 Console (Keep existing config)
        http.headers(headers -> headers.frameOptions(frameOptions -> frameOptions.disable()));

        return http.build();
    }

    // --- CORS Configuration (Keep existing config) ---
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowCredentials(true);
        config.setAllowedOriginPatterns(Collections.singletonList("*")); // Be more specific in production
        config.setAllowedHeaders(Arrays.asList("Authorization", "Content-Type", "Accept"));
        config.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        source.registerCorsConfiguration("/**", config);
        return source;
    }

    // --- Custom OAuth2UserService for Role Mapping (As explained in previous answer) ---
    @Bean
    public OAuth2UserService<OAuth2UserRequest, OAuth2User> oauth2UserService() {
        final DefaultOAuth2UserService delegate = new DefaultOAuth2UserService();

        return (userRequest) -> {
            OAuth2User oauth2User = delegate.loadUser(userRequest);

            String email = oauth2User.getAttribute("email"); // Often available for Google, GitHub (if scope requested)
            String name = oauth2User.getAttribute("name");   // User's display name
            String sub = oauth2User.getName();             // Unique ID from the provider (e.g., Google's 'sub')

            logger.debug("OAuth2 Login: User {} ({}) from provider {}", name, email, userRequest.getClientRegistration().getRegistrationId());

            // --- IMPORTANT: Your ACL/Role Assignment Logic Goes Here ---
            Set<GrantedAuthority> authorities = new HashSet<>();
            authorities.add(new SimpleGrantedAuthority("ROLE_USER")); // Default role for all logged-in users

            // Example: Assign ROLE_ADMIN based on email or a specific user ID/policy
            if (email != null && email.equals("admin@example.com")) { // Replace with your actual admin email
                authorities.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
                logger.debug("User {} assigned ROLE_ADMIN", email);
            }
            // For a real application, you'd typically query your own database
            // to fetch or create a user profile and assign roles based on your application's
            // user management system.
            /*
			            Optional<com.example.myaclapp.model.User> appUserOptional = userRepository.findByProviderIdAndProvider(sub, userRequest.getClientRegistration().getRegistrationId());
			            com.example.myaclapp.model.User appUser;
			
			            if (appUserOptional.isEmpty()) {
			                // New user: Create a new user in your database
			                appUser = new com.example.myaclapp.model.User();
			                appUser.setEmail(email);
			                appUser.setName(name);
			                appUser.setProvider(userRequest.getClientRegistration().getRegistrationId());
			                appUser.setProviderId(sub);
			                appUser.setRoles(Collections.singleton(new com.example.myaclapp.model.Role("USER"))); // Default role for new users
			                userRepository.save(appUser);
			            } else {
			                appUser = appUserOptional.get();
			            }
			
			            // Map roles from your application's user model to Spring Security GrantedAuthorities
			            authorities.addAll(appUser.getRoles().stream()
			                .map(role -> new SimpleGrantedAuthority("ROLE_" + role.getName().toUpperCase()))
			                .collect(Collectors.toSet()));
            */

            // Return a new OAuth2User with the original attributes and your custom authorities
            return new DefaultOAuth2User(
                authorities,
                oauth2User.getAttributes(),
                userRequest.getClientRegistration().getProviderDetails().getUserInfoEndpoint().getUserNameAttributeName()
            );
        };
    }
} //Class SecurityConfig ENDs

ENHANCEMENT: For Social login ENDs


Prompt AI-ACL-2:

1. Environment: Java 21, Spring Boot version 3.4.4, Spring Security ACL library, Spring Security 6.0, Ecache 3.x version, JCache APIs
2. Show the project structure. show where is ehcache.xml placed in this structure. The develop the pom.xml. In the pom.xml file use the following tag for this project     <groupId>com.cybage</groupId>
    <artifactId>AI-ACL-2</artifactId>
    <version>0.0.1-SNAPSHOT</version>
    <name>SS-ACL02-proj</name>
    <description>SS ACL demo with EhCache 3.x and JCache APIs.</description>
3. Develop application.properties file, set up Tomcat server port  as 9991
4. Develop the relevant controllers like AclAuthController.java. Avoid deprecated methods like requestMatchers, etc.
5. Develop the Spring Security domain objects like Document.java. Use main features of Spring Security ACL library objects and Permissions, USE latest ECache 3.x and JCache APIs. Remember to Use JCacheManagerFactoryBean from JCache, instead of EhCacheFactoryBean. 
6. DO NOT use deprecated classes like WebSecurityConfigurerAdapter. Develop the Service layers like DomainServiceImplementaion.java, with fully developed methods.
7. In the test cases do initialize the static final references. The DocumentServiceImpl which implements the DocumentService interface, should have @Order(1) notation, so that it can be the first class to be initialized by Spring.
8. Develop the project  to implement fine-grained access control for domain objects using Spring Security ACL. 
9. Use all the following libraries and show their use in the methods in Security related ACLConfig.java file,
 	org.springframework.security.acls.AclPermissionEvaluator
 	org.springframework.security.acls.domain.*
	 org.springframework.security.acls.jdbc.BasicLookupStrategy
	 org.springframework.security.acls.jdbc.JdbcMutableAclService
 	org.springframework.security.acls.jdbc.LookupStrategy
 	org.springframework.security.acls.model.PermissionGrantingStrategy
 	org.springframework.security.core.authority.SimpleGrantedAuthority
10. Junit, etc. create Basic "Document" and "Permission" related test cases, and not comprehensive test case. Test cases should cover basic Permission level tests about Document and rights associated with it or them.
11. Mention "storage location" and the steps to run the Schema.sql file. Create data.sql file separately with basic users like cybUser1, cybUser2, and cybManager1, etc. The insert script should be initialized as Spring container boots the application.
12. Mention in details, the enumerated steps, to configure, and run, this application.



---------------------
  PROJECT STRUCTURE
---------------------
									AI-ACL-2/
									├── pom.xml
									├── src/
									│   ├── main/
									│   │   ├── java/
									│   │   │   └── com/
									│   │   │       └── cybage/
									│   │   │           ├── config/
									│   │   │           │   ├── JwtAuthenticationFilter.java
									│   │   │           │   └── SecurityConfig.java
									│   │   │           ├── controller/
									│   │   │           │   └── AclAuthController.java
									│   │   │           ├── domain/
									│   │   │           │   ├── AclClass.java
									│   │   │           │   ├── Document.java
									│   │   │           │   └── Permission.java
									│   │   │           ├── repository/
									│   │   │           │   ├── AclClassRepository.java
									│   │   │           │   ├── DocumentRepository.java
									│   │   │           │   └── PermissionRepository.java
									│   │   │           ├── service/
									│   │   │           │   ├── DocumentServiceImpl.java
									│   │   │           │   └── UserDetailsServiceImpl.java
									│   │   │           └── util/
									│   │   │               └── JwtUtils.java
									│   │   └── resources/
									│   │       ├── application.properties
									│   │       └── data.sql
									│   └── test/
									│       └── java/
									│           └── com/
									│               └── cybage/
									│                   └── service/
									│                       └── DocumentServiceImplTest.java
									└── target/
									    └── classes/
									        └── com/
									            └── cybage/
									                └── controller/
									                    └── AclAuthController.class








document-management-system/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/
│   │   │       └── cybage/
│   │   │           ├── DocumentManagementApplication.java
│   │   │           ├── config/
│   │   │           │   ├── CacheConfig.java
│   │   │           │   ├── JwtAuthenticationFilter.java
│   │   │           │   ├── JwtTokenProvider.java
│   │   │           │   └── SecurityConfig.java
│   │   │           ├── controller/
│   │   │           │   ├── AuthController.java
│   │   │           │   └── DocumentController.java
│   │   │           ├── domain/
│   │   │           │   ├── Document.java
│   │   │           │   ├── Permission.java
│   │   │           │   └── User.java
│   │   │           ├── dto/
│   │   │           │   ├── JwtResponse.java
│   │   │           │   └── LoginRequest.java
│   │   │           ├── exception/
│   │   │           │   ├── DocumentNotFoundException.java
│   │   │           │   ├── GlobalExceptionHandler.java
│   │   │           │   └── UnauthorizedException.java
│   │   │           ├── repository/
│   │   │           │   ├── DocumentRepository.java
│   │   │           │   ├── PermissionRepository.java
│   │   │           │   └── UserRepository.java
│   │   │           └── service/
│   │   │               ├── AclService.java
│   │   │               ├── AclServiceImpl.java
│   │   │               ├── DocumentService.java
│   │   │               ├── DocumentServiceImpl.java
│   │   │               ├── UserDetailsServiceImpl.java
│   │   │               └── UserService.java
│   │   └── resources/
│   │       ├── application.properties
│   │       ├── data.sql
│   │       └── schema.sql
│   └── test/
│       ├── java/
│       │   └── com/
│       │       └── cybage/
│       │           ├── DocumentManagementApplicationTests.java
│       │           ├── config/
│       │           │   └── TestConfig.java
│       │           ├── controller/
│       │           │   └── DocumentControllerTest.java
│       │           └── service/
│       │               ├── AclServiceImplTest.java
│       │               └── DocumentServiceImplTest.java
│       └── resources/
│           └── application-test.properties
├── pom.xml
└── README.md



Key Files and Their Purposes
----------------------------
Main Application
DocumentManagementApplication.java: The main Spring Boot application class with the @SpringBootApplication annotation.
Configuration
CacheConfig.java: Configuration for Redis caching.
JwtAuthenticationFilter.java: Filter to process JWT tokens for authentication.
JwtTokenProvider.java: Service to generate and validate JWT tokens.
SecurityConfig.java: Spring Security configuration.
Controllers
AuthController.java: Handles authentication requests (login, register).
DocumentController.java: REST API endpoints for document operations.
Domain Models
Document.java: Entity representing a document.
Permission.java: Entity representing access permissions.
User.java: Entity representing a user.
DTOs (Data Transfer Objects)
JwtResponse.java: Response containing JWT token after successful authentication.
LoginRequest.java: Request containing login credentials.
Exceptions
DocumentNotFoundException.java: Exception thrown when a document is not found.
GlobalExceptionHandler.java: Global exception handler for the application.
UnauthorizedException.java: Exception thrown for unauthorized access.
Repositories
DocumentRepository.java: JPA repository for Document entities.
PermissionRepository.java: JPA repository for Permission entities.
UserRepository.java: JPA repository for User entities.
Services
AclService.java: Interface for Access Control List operations.
AclServiceImpl.java: Implementation of the ACL service.
DocumentService.java: Interface for document operations.
DocumentServiceImpl.java: Implementation of the document service.
UserDetailsServiceImpl.java: Implementation of Spring Security's UserDetailsService.
UserService.java: Service for user operations.
Resources
application.properties: Main application configuration.
data.sql: SQL script to initialize data.
schema.sql: SQL script to initialize schema.
Tests
DocumentManagementApplicationTests.java: Integration tests for the application.
TestConfig.java: Test configuration.
DocumentControllerTest.java: Unit tests for DocumentController.
AclServiceImplTest.java: Unit tests for AclServiceImpl.
DocumentServiceImplTest.java: Unit tests for DocumentServiceImpl.
application-test.properties: Test-specific configuration.
This structure follows Spring Boot best practices with clear separation of concerns and a layered architecture (controller, service, repository).

src/
├── main/
│   ├── java/
│   │   └── com/
│   │       └── cybage/
│   │           ├── AiAcl2Application.java
│   │           ├── controller/
│   │           │   └── AclAuthController.java
│   │           ├── domain/
│   │           │   └── Document.java
│   │           ├── exception/
│   │           │   ├── DocumentNotFoundException.java
│   │           │   └── GlobalExceptionHandler.java
│   │           ├── repository/
│   │           │   └── DocumentRepository.java
│   │           ├── security/
│   │           │   ├── DocumentOwnershipEvaluator.java
│   │           │   └── PermissionConstants.java
│   │           └── service/
│   │               ├── AclService.java
│   │               ├── AclServiceImpl.java
│   │               ├── DocumentService.java
│   │               └── DocumentServiceImpl.java
│   └── resources/
│       ├── application.properties
│       ├── schema.sql
│       └── data.sql
└── test/
    ├── java/
    │   └── com/
    │       └── cybage/
    │           ├── controller/
    │           │   └── AclAuthControllerTest.java
    │           └── service/
    │               ├── AclServiceImplTest.java
    │               └── DocumentServiceImplTest.java
    └── resources/
        ├── application.properties
        ├── schema-test.sql
        └── data-test.sql




AI-ACL-2/
├── src/
│   ├── main/                           # Main source code
│   │   ├── java/
│   │   │   └── com/
│   │   │       └── cybage/
│   │   │           ├── config/         # Configuration classes
│   │   │           │   ├── ACLConfig.java
│   │   │           │   ├── CacheConfig.java
│   │   │           │   └── SecurityConfig.java
│   │   │           ├── controller/     # REST controllers
│   │   │           │   └── AclAuthController.java
│   │   │           ├── domain/         # Entity classes
│   │   │           │   └── Document.java
│   │   │           ├── repository/     # Data repositories
│   │   │           │   └── DocumentRepository.java
│   │   │           ├── service/        # Service interfaces and implementations
│   │   │           │   ├── DocumentService.java        # Interface
│   │   │           │   └── DocumentServiceImpl.java    # Implementation
│   │   │           └── AiAcl2Application.java          # Main application class
│   │   ├── resources/                  # Main resources
│   │   │   ├── ehcache.xml             # EhCache configuration
│   │   │   ├── application.properties  # Main application properties
│   │   │   ├── schema.sql              # Main database schema
│   │   │   └── data.sql                # Main database data
│   └── test/                           # Test source code
│       ├── java/
│       │   └── com/
│       │       └── cybage/
│       │           ├── config/         # Test configuration
│       │           │   └── TestConfig.java
│       │           ├── service/        # Service tests
│       │           │   └── DocumentServiceImplTest.java
│       │           └── AiAcl2ApplicationTests.java     # Main test class
│       └── resources/                  # Test resources
│           ├── application.properties  # Test application properties
│           ├── schema-test.sql         # Test database schema
│           └── data-test.sql           # Test database data
└── pom.xml                             # Maven configuration



Old Project Structure:
----------------
AI-ACL-2
AI-ACL-2/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/
│   │   │       └── cybage/
│   │   │           ├── config/
│   │   │           │   ├── ACLConfig.java
│   │   │           │   ├── CacheConfig.java
│   │   │           │   └── SecurityConfig.java
│   │   │           ├── controller/
│   │   │           │   └── AclAuthController.java
│   │   │           ├── domain/
│   │   │           │   └── Document.java
│   │   │           ├── repository/
│   │   │           │   └── DocumentRepository.java
│   │   │           ├── service/
│   │   │           │   ├── DocumentService.java
│   │   │           │   └── DocumentServiceImpl.java
│   │   │           └── AiAcl2Application.java
│   │   ├── resources/
│   │   │   ├── ehcache.xml
│   │   │   ├── application.properties
│   │   │   ├── schema.sql
│   │   │   └── data.sql
│   └── test/
│       └── java/
│           └── com/
│               └── cybage/
│                   ├── service/
│                   │   └── DocumentServiceImplTest.java
│                   └── AiAcl2ApplicationTests.java
└── pom.xml


pom.xml
application.properties
Ecache config
Acl2Application.java
Document.java
DocumentRepository.java
.java
.java
.java
.java
.java
.java
.java
.sql
.sql

:Steps to Configure and Run the Application
 -----------------------------------------
Here are the detailed steps to configure and run this Spring Security ACL application:

1. Project Setup
Create a new Spring Boot project with the structure shown above.
Add all the necessary dependencies in the pom.xml file.
Place the configuration files (application.properties, ehcache.xml) in the src/main/resources directory.

2. Database Setup
The schema.sql file will be automatically executed when the application starts due to the configuration in application.properties:
spring.sql.init.mode=always
spring.sql.init.schema-locations=classpath:schema.sql
spring.sql.init.data-locations=classpath:data.sql

This will create all necessary tables for ACL functionality and populate them with initial data.
The H2 in-memory database is used for this example, so no external database setup is required.

3. Build the Project
mvn clean install

Send command to Terminal

4. Run the Application
 mvn spring-boot:run

Send command to Terminal
Or run the JAR file directly:
java -jar target/AI-ACL-2-0.0.1-SNAPSHOT.jar

Send command to Terminal

5. Access the Application
The application will be running on port 9991 as configured in application.properties:

H2 Console: http://localhost:9991/h2-console

JDBC URL: jdbc:h2:mem:acldb
Username: sa
Password: (empty)
API Endpoints:

GET /api/documents - List all documents (filtered by ACL permissions)
GET /api/documents/{id} - Get a specific document (if permitted)
POST /api/documents - Create a new document
PUT /api/documents/{id} - Update a document (if permitted)
DELETE /api/documents/{id} - Delete a document (if permitted)
GET /api/documents/owner/{owner} - Get documents by owner (filtered by ACL permissions)
POST /api/documents/{id}/permissions - Add permission for a user on a document
DELETE /api/documents/{id}/permissions - Remove permission for a user on a document

6. Testing the ACL Functionality
 6a. Use Basic Authentication with the predefined users:
	cybUser1/password
	cybUser2/password
	cybManager1/password
	admin/admin
 6b. Create a document as one user, then try to access it as another user to verify ACL restrictions.
 6c. Add permissions for other users on your documents and verify they can access them.
 6d. Run the test cases to verify ACL functionality:
   mvn test
 Send command to Terminal

7. Understanding the ACL Implementation
   The ACL implementation uses the following key components:
   7a. ACL Tables: The schema.sql file creates the necessary tables for ACL functionality:

    acl_sid: Security identities (users and roles)
    acl_class: Domain object classes
    acl_object_identity: Object instances
    acl_entry: Permissions for objects
   7b. Caching: EhCache 3.x with JCache API is used to cache ACL data for better performance.
   7c. Permission Evaluation: The AclPermissionEvaluator is used to evaluate permissions in method security expressions.
   7d. Method Security: @PreAuthorize, @PostAuthorize, and @PostFilter annotations are used to secure service methods.
   7e. ACL Service: JdbcMutableAclService is used to manage ACL entries in the database.

8. Troubleshooting
   If you encounter database errors, check the H2 console to verify that tables were created correctly.
   For permission issues, enable DEBUG logging for Spring Security:

	logging.level.org.springframework.security=DEBUG

   If caching issues occur, verify the ehcache.xml configuration and ensure the cache is properly initialized.
==============
   "Summary"
==============
  This Spring Security ACL implementation provides fine-grained access control for domain objects, allowing you to control who can access, modify, or delete specific documents based on user permissions.

